﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	[AddComponentMenu("ORK Framework/Player Control/Top Down 2D Controller")]
	public class TopDown2DPlayerController : MonoBehaviour, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public TopDown2DPlayerControlSettings settings = new TopDown2DPlayerControlSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// in-game
		protected float currentSprintEnergy = 0;

		protected float currentMaxSprintEnergy = 0;

		protected Rigidbody2D rigidbodyComp;

		protected Vector2 moveDirection = Vector2.zero;

		protected float verticalSpeed = 0.0f;

		protected float moveSpeed = 0.0f;

		protected float lastMoveSpeed = 0.0f;

		protected Combatant combatant = null;

		protected virtual void Start()
		{
			this.rigidbodyComp = this.GetComponent<Rigidbody2D>();
			this.moveDirection = Vector2.zero;

			this.combatant = ORKComponentHelper.GetCombatant(this.transform.root.gameObject);
			if(this.combatant != null &&
				this.settings.useSprint &&
				this.settings.useEnergy)
			{
				this.currentMaxSprintEnergy = this.settings.maxEnergy.GetValue(this.combatant.Call);
				this.currentSprintEnergy = this.currentMaxSprintEnergy;
			}
		}

		protected int InputID
		{
			get { return this.combatant != null ? this.combatant.InputID : Maki.Control.InputID; }
		}

		protected virtual void OnDisable()
		{
			if(this.rigidbodyComp != null)
			{
				this.rigidbodyComp.velocity = Vector2.zero;
			}
		}

		protected virtual void Update()
		{
			this.UpdateSmoothedMovementDirection();
		}

		protected virtual void FixedUpdate()
		{
			if(this.rigidbodyComp != null)
			{
				this.rigidbodyComp.velocity = this.moveDirection * this.moveSpeed;
			}
		}

		protected void UpdateSmoothedMovementDirection()
		{
			float delta = ORK.Game.DeltaMovementTime;
			float runSpeed = ORK.GameControls.playerControl.runSpeed;
			this.moveDirection = Vector2.zero;
			float speedMod = 1;

			if(this.combatant == null ||
				((ORK.GameControls.playerControl.moveDead ||
					!this.combatant.Status.IsDead) &&
				!this.combatant.Status.Effects.StopMovement))
			{
				int inputID = this.InputID;
				this.moveDirection.y = InputKey.GetAxis(this.settings.verticalAxis, inputID);
				this.moveDirection.x = InputKey.GetAxis(this.settings.horizontalAxis, inputID);
				if(this.settings.noDiagonalMovement)
				{
					if(this.moveDirection.x != 0)
					{
						this.moveDirection.y = 0;
					}
				}

				if(ORK.GameControls.playerControl.useSpeed &&
					this.combatant != null)
				{
					runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Run);
				}

				if(this.combatant != null)
				{
					// sprint
					if(this.settings.useSprint &&
						this.combatant.Object.Component != null &&
						!this.combatant.Object.Component.InAir &&
						InputKey.GetButton(this.settings.sprintKey.StoredAsset, inputID))
					{
						if(this.EnergyHandling(true))
						{
							speedMod = this.settings.sprintFactor;
						}
					}
					else
					{
						this.EnergyHandling(false);
					}
				}
			}

			float curSmooth = ORK.GameControls.playerControl.speedSmoothing * delta;
			float targetSpeed = Mathf.Min(this.moveDirection.magnitude, 1.0f);
			if(targetSpeed < 0.2)
			{
				targetSpeed = 0;
			}
			else
			{
				targetSpeed *= runSpeed * speedMod;

				if(this.settings.horizontalFlip)
				{
					if(this.moveDirection.x < -this.settings.flipInputIgnore &&
						(this.settings.horizontalFlipNegate ?
							this.transform.localScale.x < 0 :
							this.transform.localScale.x > 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.x = -scale.x;
						this.transform.localScale = scale;
					}
					else if(this.moveDirection.x > this.settings.flipInputIgnore &&
						(this.settings.horizontalFlipNegate ?
							this.transform.localScale.x > 0 :
							this.transform.localScale.x < 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.x = -scale.x;
						this.transform.localScale = scale;
					}
				}
				if(this.settings.verticalFlip)
				{
					if(this.moveDirection.y < -this.settings.flipInputIgnore &&
						(this.settings.verticalFlipNegate ?
							this.transform.localScale.y < 0 :
							this.transform.localScale.y > 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.y = -scale.y;
						this.transform.localScale = scale;
					}
					else if(this.moveDirection.y > this.settings.flipInputIgnore &&
						(this.settings.verticalFlipNegate ?
							this.transform.localScale.y > 0 :
							this.transform.localScale.y < 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.y = -scale.y;
						this.transform.localScale = scale;
					}
				}
			}
			this.moveSpeed = Mathf.Lerp(this.moveSpeed, targetSpeed, curSmooth);
			this.moveDirection = this.moveDirection.normalized;

			if(this.settings.rotateZAxis &&
				targetSpeed > 0)
			{
				Vector3 rotation = this.transform.eulerAngles;
				rotation.z = VectorHelper.DirectionToAngle(this.moveDirection, Maki.GameSettings.horizontalPlane);
				this.transform.eulerAngles = rotation;
			}
		}

		protected bool EnergyHandling(bool use)
		{
			bool ok = true;
			if(this.settings.useSprint &&
				this.settings.useEnergy)
			{
				DataCall call = this.combatant.Call;
				float t = ORK.Game.DeltaMovementTime;
				// set max
				this.currentMaxSprintEnergy = this.settings.maxEnergy.GetValue(call);
				// regenerate
				this.currentSprintEnergy += this.settings.energyRegeneration.GetValue(call) * t;
				// use
				if(use)
				{
					float tmp = this.settings.energyConsume.GetValue(call) * t;
					if(tmp > this.currentSprintEnergy)
						ok = false;
					else
						this.currentSprintEnergy -= tmp;
				}
				// max bounds
				if(this.currentSprintEnergy < 0)
				{
					this.currentSprintEnergy = 0;
				}
				else if(this.currentSprintEnergy > this.currentMaxSprintEnergy)
				{
					this.currentSprintEnergy = this.currentMaxSprintEnergy;
				}
			}
			return ok;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
