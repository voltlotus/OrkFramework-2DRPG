
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Random Battle Area")]
	public class RandomBattleArea : BaseConditionComponent, ISchematicStarter, ISerializationCallbackReceiver
	{
		// settings
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isInTrigger = false;


		// battle positions
		protected Vector3 lastPosition = Vector3.zero;

		protected float timeout = 0;

		protected float movedDistance = 0;

		protected float battleDistance = 0;


		// battle component
		protected BattleComponent usedBattleComponent;

		protected bool destroyComponent = false;


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if(other.gameObject == player &&
				this.CheckConditions(player, false))
			{
				this.isInTrigger = true;
				this.InitInterval(other.transform.position);
			}
		}

		protected virtual void OnTriggerStay(Collider other)
		{
			if(this.isInTrigger &&
				!ORK.Control.InBattle &&
				!Maki.Control.ChangingScene &&
				!Maki.Control.Blocked &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.CheckInterval(this.settings.checkLocalPosition ?
						other.transform.localPosition :
						other.transform.position,
					other.transform.eulerAngles);
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(this.isInTrigger &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.isInTrigger = false;
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if(other.gameObject == player &&
				this.CheckConditions(player, false))
			{
				this.isInTrigger = true;
				this.InitInterval(other.transform.position);
			}
		}

		protected virtual void OnTriggerStay2D(Collider2D other)
		{
			if(this.isInTrigger && !ORK.Control.InBattle &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.CheckInterval(this.settings.checkLocalPosition ?
						other.transform.localPosition :
						other.transform.position,
					other.transform.eulerAngles);
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(this.isInTrigger &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.isInTrigger = false;
			}
		}


		/*
		============================================================================
		Interval functions
		============================================================================
		*/
		protected virtual void InitInterval(Vector3 position)
		{
			this.timeout = 0;
			this.movedDistance = 0;
			this.battleDistance = 0;
			this.lastPosition = position;
		}

		protected virtual void CheckInterval(Vector3 position, Vector3 rotation)
		{
			this.timeout += ORK.Game.DeltaMovementTime;

			float distance = VectorHelper.Distance(this.lastPosition, position, this.settings.ignoreDistance);
			this.movedDistance += distance;
			this.battleDistance += distance;
			this.lastPosition = position;

			if(this.movedDistance >= this.settings.minMoveCheckDistance &&
				this.timeout >= this.settings.checkInterval)
			{
				this.timeout -= this.settings.checkInterval;
				this.movedDistance = 0;

				float rnd = (this.settings.battleChance * ORK.Game.RandomBattleFactor) * ORK.Game.RandomBattleChance / 100.0f;
				if(rnd > 0 &&
					(this.battleDistance >= this.settings.maxBattleDistance ||
						(this.battleDistance >= this.settings.minBattleDistance &&
							Maki.GameSettings.CheckRandom(rnd))))
				{
					this.battleDistance = 0;

					int index = -1;
					float random = Maki.GameSettings.GetRandom();
					float tmpChance = 0;

					for(int i = 0; i < this.settings.combatant.Length; i++)
					{
						if(random >= tmpChance && random <= tmpChance + this.settings.combatant[i].chance)
						{
							index = i;
							break;
						}
						else
						{
							tmpChance += this.settings.combatant[i].chance;
						}
					}

					if(index >= 0 && index < this.settings.combatant.Length)
					{
						this.StartBattle(index, position, rotation);
					}
				}
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public virtual void StartBattle(int index, Vector3 position, Vector3 rotation)
		{
			if(ORK.Access.Combatant.HasSpawnCreationAuthority)
			{
				this.usedBattleComponent = null;
				if(this.settings.battleArena.battleComponent != null)
				{
					this.usedBattleComponent = this.settings.battleArena.battleComponent;
					if(this.settings.battleArena.setPosition &&
						this.settings.battleArena.setRotation)
					{
						this.usedBattleComponent.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
					}
					else
					{
						if(this.settings.battleArena.setPosition)
						{
							this.usedBattleComponent.transform.position = position;
						}
						if(this.settings.battleArena.setRotation)
						{
							this.usedBattleComponent.transform.eulerAngles = rotation;
						}
					}
				}
				if(this.usedBattleComponent == null && this.settings.battleArena.useNearest)
				{
					this.usedBattleComponent = ComponentHelper.GetNearest<BattleComponent>(position, this.settings.battleArena.nearestRange);
				}
				if(this.usedBattleComponent == null)
				{
					this.usedBattleComponent = new GameObject("_RandomBattle").AddComponent<BattleComponent>();
					if(this.settings.battleArena.setRotation)
					{
						this.usedBattleComponent.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
					}
					else
					{
						this.usedBattleComponent.transform.position = position;
					}
					this.destroyComponent = true;
				}

				this.usedBattleComponent.UseSceneID = false;
				this.usedBattleComponent.SetBattleSystem(this.settings.battleArena.battleSystem.GetBattleSystem());
				Group group = this.settings.combatant[index].GetGroup(true, this.usedBattleComponent.transform.position);
				if(group != null)
				{
					this.usedBattleComponent.StartGroup(group, this);
				}
				else
				{
					this.SchematicFinished(null);
				}
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			if(this.destroyComponent)
			{
				UnityWrapper.Destroy(this.usedBattleComponent.gameObject);
				this.usedBattleComponent = null;
				this.destroyComponent = false;
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/RandomBattleArea Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// battle arena
			[EditorFoldout("Random Battle Settings", "Define the battle system and chances a battle occurs.")]
			public BattleArenaSettings battleArena = new BattleArenaSettings();

			// random battle interval
			[EditorHelp("Battle Chance (%)", "The chance a battle will start.")]
			[EditorSeparator]
			[EditorTitleLabel("Random Chance Settings")]
			public float battleChance = 10.0f;

			[EditorHelp("Check Interval (s)", "The interval between chance checks.")]
			public float checkInterval = 0.5f;

			// distance settings
			[EditorHelp("Minimum Move Distance", "The minimum distance the player has to move between checks.")]
			[EditorSeparator]
			public float minMoveCheckDistance = 0.1f;

			[EditorHelp("Minimum Distance", "The minimum distance the player has to move since the last battle before the next battle can start.")]
			public float minBattleDistance = 5.0f;

			[EditorHelp("Maximum Distance", "The maximum distance the player can move before the next battle is forced.")]
			public float maxBattleDistance = 15.0f;

			[EditorHelp("Check Local Position", "Check the local position of the player.\n" +
				"E.g. use this when the player is mounted on a moving platform.\n" +
				"If the player isn't mounted, the local position will be the world position.")]
			public bool checkLocalPosition = false;

			[EditorHelp("Ignore Distance", "Enable the axes that will be ignored for the distance check.")]
			[EditorEndFoldout]
			public AxisBool ignoreDistance = new AxisBool();


			// combatant settings
			[EditorFoldout("Combatant Settings", "Define the combatants that will be used.")]
			[EditorEndFoldout]
			[EditorArray("Add Combatant/Group", "Adds a combatant or group.", "",
				"Remove", "Removes this combatant/group.", "", noRemoveCount = 1,
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Combatant", "Define the combatant or group that will be used.", ""
				})]
			public ChanceBattleCombatant[] combatant = new ChanceBattleCombatant[] { new ChanceBattleCombatant() };


			public Settings()
			{

			}
		}
	}
}
