
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	public abstract class BaseBattleComponent : BaseInteractionComponent, IGlobalSceneID
	{
		protected string sceneName = "";

		protected virtual void Awake()
		{
			this.sceneName = SceneManager.GetActiveScene().name;
		}

		public abstract bool UseSceneID
		{
			get;
			set;
		}

		public abstract bool IsGlobalSceneID
		{
			get;
			set;
		}

		public abstract int SceneID
		{
			get;
			set;
		}

		public virtual bool IsSceneIDSet()
		{
			return this.UseSceneID &&
				ORK.Game.Scene.IsBattleFinished(this.IsGlobalSceneID ? null : this.sceneName, this.SceneID);
		}

		public virtual void SetSceneID(bool finished)
		{
			if(this.UseSceneID)
			{
				ORK.Game.Scene.BattleFinished(this.IsGlobalSceneID ? null : this.sceneName, this.SceneID, finished);
			}
		}

		public override bool CanInteract(GameObject startingObject)
		{
			return base.CanInteract(startingObject) && !this.IsSceneIDSet();
		}
	}
}
