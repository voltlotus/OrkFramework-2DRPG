
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Add Combatant")]
	public class AddCombatant : BaseConditionComponent, IGlobalSceneGUID, ISerializationCallbackReceiver
	{
		// waypoints
		public GameObject[] waypoints = new GameObject[0];


		// settings
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// in-game
		protected string sceneName = "";

		protected Combatant combatant;

		public virtual bool UseSceneGUID
		{
			get { return this.settings.rememberCombatant; }
			set { this.settings.rememberCombatant = value; }
		}

		public virtual bool IsGlobalSceneGUID
		{
			get { return this.settings.rememberGlobal; }
			set { this.settings.rememberGlobal = value; }
		}

		public virtual string SceneGUID
		{
			get { return this.settings.spawnerID; }
			set { this.settings.spawnerID = value; }
		}

		protected override void Start()
		{
			if(ORK.Access.Combatant.HasSpawnCreationAuthority &&
				!this.CheckAutoDestroy() &&
				this.CheckConditions(ORK.Game.GetPlayer(), false))
			{
				this.sceneName = SceneManager.GetActiveScene().name;

				if(this.GetComponent<CombatantComponent>() == null)
				{
					if(this.settings.rememberCombatant && this.settings.spawnerID != "")
					{
						DataObject data = ORK.Game.Scene.GetSpawnerData(
							this.settings.rememberGlobal ? null : this.sceneName, 
							this.settings.spawnerID);
						if(data != null)
						{
							this.combatant = new Combatant(data, false, new Group(FactionSetting.Get(this.settings.faction)));
							this.combatant.GameObject = this.gameObject;
							this.combatant.Object.LoadPosition(data);
						}
						else
						{
							this.combatant = this.settings.combatantSetting.Create(
								new Group(FactionSetting.Get(this.settings.faction)),
								true, this.transform.position);
							if(this.combatant != null)
							{
								this.combatant.GameObject = this.gameObject;
							}
						}
						if(this.combatant != null)
						{
							this.combatant.Object.RememberPosition = true;
						}
					}
					else
					{
						this.combatant = this.settings.combatantSetting.Create(
							new Group(FactionSetting.Get(this.settings.faction)),
							true, this.transform.position);
						if(this.combatant != null)
						{
							this.combatant.GameObject = this.gameObject;
						}
					}

					if(this.combatant != null)
					{
						this.combatant.Group.BattleSystem = this.settings.battleArena.battleSystem.GetBattleSystem();

						if(this.waypoints.Length > 0 && this.combatant.Object.MoveAI != null)
						{
							this.combatant.Object.MoveAI.SetWaypoints(this.waypoints, this.settings.randomWaypointOrder);
						}
						if(this.combatant.Object.Component != null)
						{
							this.combatant.Object.Component.AddCombatantComponent = this;
						}
					}
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual BattleComponent GetBattleComponent(Vector3 position, Vector3 rotation, AutoStartBattleSettings autoStart)
		{
			BattleComponent battle = null;
			if(this.settings.battleArena.battleComponent != null)
			{
				battle = this.settings.battleArena.battleComponent;
				if(this.settings.battleArena.setPosition &&
					this.settings.battleArena.setRotation)
				{
					battle.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
				}
				else
				{
					if(this.settings.battleArena.setPosition)
					{
						battle.transform.position = position;
					}
					if(this.settings.battleArena.setRotation)
					{
						battle.transform.eulerAngles = rotation;
					}
				}
			}
			if(battle == null && this.settings.battleArena.useNearest)
			{
				battle = ComponentHelper.GetNearest<BattleComponent>(position, this.settings.battleArena.nearestRange);
			}
			if(battle == null &&
				autoStart != null &&
				autoStart.useNearestArena)
			{
				battle = ComponentHelper.GetNearest<BattleComponent>(position, autoStart.arenaRange);
			}
			if(battle == null)
			{
				battle = new GameObject("_Battle").AddComponent<BattleComponent>();
				if(this.settings.battleArena.setRotation)
				{
					battle.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
				}
				else
				{
					battle.transform.position = position;
				}
			}
			battle.SetBattleSystem(this.settings.battleArena.battleSystem.GetBattleSystem());
			battle.UseSceneID = false;
			battle.SceneID = -1;
			return battle;
		}


		/*
		============================================================================
		Remember functions
		============================================================================
		*/
		public virtual void StoreSpawned()
		{
			if(this.settings.rememberCombatant &&
				this.settings.spawnerID != "" &&
				this.combatant != null)
			{
				ORK.Game.Scene.SetSpawnerData(
					this.settings.rememberGlobal ? null : this.sceneName,
					this.settings.spawnerID, this.combatant.SaveGame());
			}
		}

		protected virtual void OnDestroy()
		{
			if(Maki.SaveGame != null &&
				!Maki.SaveGame.IsLoading)
			{
				this.StoreSpawned();
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/AddCombatant Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// remember combatant
			[EditorHide]
			public bool rememberCombatant = false;

			[EditorHide]
			public bool rememberGlobal = false;

			[EditorHide]
			public string spawnerID = "";


			// combatant
			[EditorHelp("Faction", "Select the faction the combatant will be part of.", "")]
			[EditorFoldout("Combatant Settings", "Define the combatant that will be used.")]
			public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();

			public CombatantInit combatantSetting = new CombatantInit();


			// move AI
			[EditorHelp("Block Move AI", "Block the combatant's move AI.")]
			[EditorSeparator]
			[EditorTitleLabel("Move AI Settings")]
			public bool blockMoveAI = false;

			[EditorHelp("Own Move AI", "Define a different move AI the combatant will use.")]
			[EditorCondition("blockMoveAI", false)]
			public bool ownMoveAI = false;

			[EditorHelp("Move AI", "Select the move AI the combatant will use.")]
			[EditorCondition("ownMoveAI", true)]
			[EditorEndCondition(2)]
			public AssetSelection<MoveAIAsset> moveAI = new AssetSelection<MoveAIAsset>();

			[EditorHelp("Move AI Range", "Optionally use a 'Move AI Range' component to set a move AI range.\n" +
				"When the combatant exits the trigger of an attached collider, the combatant will return to it's original position.")]
			[EditorInfo(allowSceneObjects = true)]
			public MoveAIRangeComponent moveAIRange;


			// battle arena
			[EditorSeparator]
			[EditorTitleLabel("Battle Settings")]
			[EditorEndFoldout]
			public BattleArenaSettings battleArena = new BattleArenaSettings();


			// waypoint settings
			[EditorHide]
			public bool randomWaypointOrder = false;

			public Settings()
			{

			}
		}
	}
}
