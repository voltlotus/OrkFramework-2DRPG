
using UnityEngine;
using UnityEngine.AI;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using System.Collections.Generic;
using System.Collections;
using System.Reflection;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("")]
	public class MoveAIComponent : MonoBehaviour, ISchematicStarter, IMoveToInteraction
	{
		protected Combatant combatant;

		protected bool isInFormation = false;

		public MoveAISetting originalSettings;

		public MoveAISetting settings;

		protected MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public MoveAIMode mode = MoveAIMode.Idle;

		protected bool blocked = false;

		public Vector3 startPosition = Vector3.zero;

		protected MoveAIRangeComponent moveRangeComponent;


		// timeouts 
		public float detectionTimeout = -1;

		public bool firstDetection = true;

		public float targetPosTimeout = -1;

		public float targetLostTimeout = -1;

		public float fleeTimeout = -1;

		protected bool inSchematic = false;


		// waypoint
		protected List<Vector3> waypoint = new List<Vector3>();

		protected int waypointIndex = 0;

		protected bool useRandomWaypoints = true;

		protected bool waypointRandomOrder = false;


		// idle
		protected int idleSchematicIndex = -1;

		protected Schematic idleSchematic;


		// target
		protected GameObject targetObject;

		protected Combatant targetCombatant;

		protected List<Combatant> detectableCombatants = new List<Combatant>();

		protected List<Combatant> detectedTargets = new List<Combatant>();

		protected Combatant followLeaderCombatant;

		protected Combatant protectedCombatant;


		// points of interest
		protected List<PointOfInterest> detectedPOIs = new List<PointOfInterest>();

		protected PointOfInterest pointOfInterest;

		protected HashSet<PointOfInterest> visitedPOIs = new HashSet<PointOfInterest>();

		protected List<PointOfInterest.Revisit> revisitPOIs = new List<PointOfInterest.Revisit>();


		// remember last target on stop
		protected GameObject lastTarget;

		protected Combatant lastCombatant;

		public MoveAIMode lastMode = MoveAIMode.Idle;


		// moving
		public Vector3 movePosition = Vector3.zero;

		protected MoveSpeed<GameObjectSelection> speed;

		protected bool isMoving = false;

		protected float stopTime = -1;


		// move into action range
		protected IRange actionUseRange;

		protected bool actionUseStopAngle = false;

		protected MoveAIStopAngle customStopAngle;


		// movement stuck
		protected Vector3 lastPosition = Vector3.zero;

		protected Vector3 lastStuckPosition = Vector3.zero;

		protected float stuckTime = 1;

		protected float lastStuckAngle = 0;

		protected bool fleeAngleSide = false;

		protected float fleeAngle = 0;

		protected bool lockFleeDirection = false;

		protected Vector3 fleeDirection = Vector3.zero;

		protected virtual void OnDrawGizmosSelected()
		{
			Color tmpColor = Gizmos.color;

			Gizmos.color = Color.white;
			Gizmos.DrawLine(this.transform.position, this.movePosition);

			if(this.targetObject != null)
			{
				Gizmos.color = Color.red;
				Gizmos.DrawWireCube(this.targetObject.transform.position, Vector3.one);
			}
			Gizmos.color = Color.yellow;
			for(int i = 0; i < this.detectedTargets.Count; i++)
			{
				if(this.detectedTargets[i] != null &&
					this.detectedTargets[i].GameObject != null &&
					this.detectedTargets[i] != this.targetCombatant)
				{
					Gizmos.DrawWireCube(this.detectedTargets[i].GameObject.transform.position, Vector3.one);
				}
			}
			Gizmos.color = tmpColor;
		}

		public virtual MoveAIUseMode UseMode
		{
			get { return this.useMode; }
			set
			{
				if(this.useMode != value)
				{
					this.useMode = value;
					this.ClearTarget(false);
				}
			}
		}

		public virtual bool Blocked
		{
			get { return this.blocked; }
			set
			{
				if(this.blocked != value)
				{
					this.blocked = value;
					if(this.blocked)
					{
						this.Stop();
					}
				}
			}
		}

		protected virtual void Start()
		{
			this.startPosition = this.transform.position;
			this.lastPosition = this.transform.position;
		}

		/// <summary>
		/// Changes the used move AI.
		/// </summary>
		/// <param name="moveAI">The move AI that will be used.</param>
		public virtual void ChangeMoveAI(MoveAISetting moveAI)
		{
			if(this.settings != moveAI)
			{
				this.settings = moveAI;
			}
		}

		/// <summary>
		/// Checks if the move AI can be used.
		/// </summary>
		/// <returns><c>true</c> if the move AI can be used, otherwise <c>false</c>.</returns>
		public virtual bool CanUse()
		{
			return !this.inSchematic &&
				ORK.Access.Combatant.HasMoveAIAuthority &&
				!ORK.Control.MoveAIBlocked && !this.blocked &&
				this.combatant != ORK.Game.ActiveGroup.Leader &&
				!this.combatant.Object.IsInputIDPlayerControls &&
				ORK.Battle.CanUseMoveAI(this.combatant);
		}

		public virtual Combatant Combatant
		{
			get { return this.combatant; }
			set
			{
				if(this.combatant != value)
				{
					if(this.combatant != null)
					{
						this.combatant.Events.GroupChanged -= this.GroupChanged;
					}
					this.combatant = value;
					if(this.combatant != null)
					{
						this.combatant.Events.GroupChanged += this.GroupChanged;
					}
				}
			}
		}

		protected virtual void OnDestroy()
		{
			if(this.combatant != null)
			{
				this.combatant.Events.GroupChanged -= this.GroupChanged;
			}
		}

		protected virtual void Update()
		{
			if(this.CanUse())
			{
				// POI revisit tick
				for(int i = 0; i < this.revisitPOIs.Count; i++)
				{
					this.revisitPOIs[i].time -= ORK.Game.DeltaMovementTime;
					if(this.revisitPOIs[i].time <= 0)
					{
						this.visitedPOIs.Remove(this.revisitPOIs[i].poi);
						this.revisitPOIs.RemoveAt(i--);
					}
				}

				// update detected in any case
				if(this.settings.IsDetectionEnabled())
				{
					// timeout running
					if(this.detectionTimeout > 0)
					{
						this.detectionTimeout -= ORK.Game.DeltaMovementTime;
					}
					// detection
					else
					{
						if(this.firstDetection)
						{
							this.firstDetection = false;
							this.detectionTimeout = Random.Range(0, this.settings.detectionTimeout);
						}
						else
						{
							this.detectionTimeout = this.settings.detectionTimeout;
						}

						this.detectedTargets.Clear();
						this.settings.DetectTargets(this.combatant, ref this.detectedTargets, ref this.detectableCombatants);
						this.settings.UseGroupDetection(this.combatant, ref this.detectedTargets, ref this.detectableCombatants);
						this.detectedTargets.Sort(new CombatantPositionDistanceSorter(
							this.combatant.GameObject.transform.position, this.settings.IgnoreHeight, false));

						if(MoveAIMode.Waypoint == this.mode &&
							this.pointOfInterest == null)
						{
							this.pointOfInterest = this.settings.GetNearestPointOfInterest(
								this.combatant, ref this.detectedPOIs, ref this.visitedPOIs);
							if(this.pointOfInterest != null)
							{
								this.SetTarget(this.pointOfInterest.gameObject, MoveAIMode.Waypoint);
							}
						}
					}

					if(this.settings.caution.enabled &&
						this.settings.caution.criticalAlwaysCheck)
					{
						this.settings.caution.CheckCritical(this);
					}
				}

				// move AI logic
				if(!this.combatant.Status.IsDead &&
					!this.combatant.Status.Effects.StopMovement &&
					(CombatantActionState.Available == this.combatant.Actions.ActionState ||
						(CombatantActionState.Casting == this.combatant.Actions.ActionState ?
							this.combatant.Actions.CanCastMove() :
							this.settings.allowDuringActions)))
				{
					if(this.lastTarget != null)
					{
						this.targetObject = this.lastTarget;
						this.targetCombatant = this.lastCombatant;
						this.mode = this.lastMode;
						this.lastTarget = null;
						this.lastCombatant = null;
					}

					// stop when not getting closer
					if(this.idleSchematic == null &&
						this.isMoving && this.settings.autoStop)
					{
						if(Vector3.Distance(this.lastPosition, this.transform.position) < this.settings.stopDistance)
						{
							if(this.stopTime == -1)
							{
								this.stopTime = Time.time + this.settings.stopTime;
							}
							else if(this.stopTime < Time.time)
							{
								this.Stop();
								this.stopTime = -1;
								this.lastPosition = this.transform.position;
								if(this.settings.stopClear)
								{
									this.ClearTarget(false);
								}
							}
						}
						else
						{
							this.stopTime = -1;
							this.lastPosition = this.transform.position;
						}
					}

					// out of move range
					if(this.IsOutOfMoveRange())
					{
						this.SetOutOfMoveRange();
					}
					// check mode conditions for detected targets
					else if(this.settings.IsDetectionEnabled() &&
						MoveAIUseMode.Idle != this.useMode &&
						MoveAIMode.Hunt != this.mode &&
						MoveAIMode.CautionHunt != this.mode &&
						MoveAIMode.CautionFlee != this.mode &&
						MoveAIMode.Protect != this.mode)
					{
						bool canUseHunting = (!this.settings.leaderStopHunt || this.combatant.IsLeader) &&
							(MoveAIUseMode.Auto == this.useMode || MoveAIUseMode.Hunt == this.useMode) &&
							this.settings.hunting.enabled &&
							this.settings.hunting.IsInRange(this.startPosition, this.combatant);
						bool canUseFlee = (MoveAIUseMode.Auto == this.useMode ||
								MoveAIUseMode.Flee == this.useMode) &&
							this.settings.flee.enabled &&
							this.settings.flee.IsInRange(this.startPosition, this.combatant);
						bool canUseCaution = (MoveAIUseMode.Auto == this.useMode ||
								MoveAIUseMode.Caution == this.useMode) &&
							this.settings.caution.enabled &&
							this.settings.caution.IsInRange(this.startPosition, this.combatant);
						bool canUseProtection = (MoveAIUseMode.Auto == this.useMode ||
								MoveAIUseMode.Protect == this.useMode) &&
							this.settings.protection.enabled &&
							this.settings.protection.IsInRange(this.startPosition, this.combatant);
						if(canUseProtection)
						{
							this.protectedCombatant = this.settings.protection.GetProtectedMember(this);
						}

						for(int i = 0; i < this.detectedTargets.Count; i++)
						{
							// flee
							if(canUseFlee &&
								this.settings.flee.IsFlee(this.combatant, this.detectedTargets[i]))
							{
								this.SetDetectedTarget(this.detectedTargets[i], MoveAIMode.Flee,
									this.settings.flee.detectionSchematic, this.settings.flee.detectionWaitForSchematic);
								break;
							}
							// caution
							else if(canUseCaution &&
								this.settings.caution.IsCautious(this.combatant, this.detectedTargets[i]))
							{
								this.SetDetectedTarget(this.detectedTargets[i], MoveAIMode.CautionHunt,
									this.settings.caution.detectionSchematic, this.settings.caution.detectionWaitForSchematic);
								break;
							}
							// protect
							else if(canUseProtection &&
								this.protectedCombatant != null &&
								this.settings.protection.CheckProtectFrom(this.combatant, this.detectedTargets[i]))
							{
								this.SetDetectedTarget(this.detectedTargets[i], MoveAIMode.Protect,
									this.settings.protection.detectionSchematic, this.settings.protection.detectionWaitForSchematic);
								break;
							}
							// hunt
							else if(canUseHunting &&
								this.settings.hunting.IsHunting(this.combatant, this.detectedTargets[i]))
							{
								this.SetDetectedTarget(this.detectedTargets[i], MoveAIMode.Hunt,
									this.settings.hunting.detectionSchematic, this.settings.hunting.detectionWaitForSchematic);
								break;
							}
						}
						if(this.inSchematic)
						{
							return;
						}
					}

					// movement to target
					if(this.targetObject != null && this.idleSchematic == null)
					{
						// update the target position
						if(this.targetPosTimeout >= 0)
						{
							this.targetPosTimeout -= ORK.Game.DeltaMovementTime;
							if(this.targetPosTimeout < 0)
							{
								this.UpdateTargetPosition(false);
							}
						}

						if(this.settings.followLeader &&
							this.settings.leaderPriority &&
							!this.combatant.IsLeader &&
							this.FollowLeaderCombatant != this.targetCombatant &&
							this.settings.leaderPriorityRange.OutOfRange(this.combatant.GameObject, this.FollowLeaderCombatant.GameObject))
						{
							if(this.CheckFollowLeader())
							{
								return;
							}
						}

						if(this.targetCombatant != null)
						{
							// following leader
							if(this.FollowLeaderCombatant == this.targetCombatant)
							{
								if(MoveAIMode.Follow == this.mode &&
									this.settings.followLeaderRange.InRange(this.combatant.GameObject, this.targetCombatant.GameObject))
								{
									this.ClearTarget(false);
								}
								else if(this.settings.autoRespawn &&
									this.settings.autoRespawnRange.OutOfRange(this.combatant.GameObject, this.combatant.Group.Leader.GameObject))
								{
									this.combatant.Object.RespawnFlag = true;
									this.combatant.Group.RespawnGroup();
								}
								else if(MoveAIMode.GiveWay == this.mode && this.settings.giveWay &&
									this.settings.giveWayRange.OutOfRange(this.combatant.GameObject, this.combatant.Group.Leader.GameObject))
								{
									this.ClearTarget(false);
								}
							}
							// flee checks
							else if(MoveAIMode.Flee == this.mode)
							{
								this.settings.flee.Use(this);
							}
							// caution checks
							else if(MoveAIMode.CautionHunt == this.mode ||
								MoveAIMode.CautionFlee == this.mode)
							{
								this.settings.caution.Use(this);
							}
							// hunt checks
							else if(MoveAIMode.Hunt == this.mode)
							{
								this.settings.hunting.Use(this);
							}
							// protect checks
							else if(MoveAIMode.Protect == this.mode)
							{
								this.settings.protection.Use(this);
							}
						}
						else if(MoveAIMode.Waypoint == this.mode &&
							this.pointOfInterest != null &&
							this.targetObject == this.pointOfInterest.gameObject)
						{
							if(this.pointOfInterest.settings.stopRange.InRange(
								this.pointOfInterest.transform.position, this.combatant.GameObject))
							{
								this.ClearTarget(false);
								if(this.pointOfInterest.settings.schematicAsset.StoredAsset != null)
								{
									Schematic schematic = new Schematic(this.pointOfInterest.settings.schematicAsset.StoredAsset);
									if(this.pointOfInterest.settings.waitForSchematic)
									{
										this.inSchematic = true;
										schematic.Notify(delegate ()
										{
											this.inSchematic = false;
											this.VisitedPOI();
										});
										schematic.PlaySchematic(this, null, this.combatant, this.pointOfInterest.gameObject,
											false, MachineUpdateType.Update, this.combatant.InputID);
									}
									else
									{
										schematic.PlaySchematic(this, null, this.combatant, this.pointOfInterest.gameObject,
											false, MachineUpdateType.Update, this.combatant.InputID);
										this.VisitedPOI();
									}
								}
								else
								{
									this.VisitedPOI();
								}
							}
						}
					}
					// no target
					else if(this.targetObject == null)
					{
						// follow leader
						this.CheckFollowLeader();

						// waypoints
						if(this.targetObject == null &&
							this.idleSchematic == null &&
							MoveAIMode.Waypoint == this.mode &&
							(!this.settings.followLeader ||
								!this.settings.leaderNoWaypoint ||
								this.combatant.IsLeader))
						{
							this.CheckNextWaypoint();
						}
						// perform idle schematic if nothing to do
						else if(MoveAIMode.Idle == this.mode)
						{
							if(this.idleSchematic == null)
							{
								this.PerformIdle();
							}
						}
						// if not idle and no target object > clear target, returns to idle/waypoint mode
						else if(this.targetObject == null)
						{
							this.ClearTarget(false);
						}
					}
				}
				// move AI blocked by cast > check caution critical cancel
				else if(!this.combatant.Status.IsDead &&
					this.targetCombatant != null &&
					this.settings.caution.enabled &&
					this.settings.caution.criticalCancelCasting &&
					this.combatant.Actions.CanCancelCast())
				{
					this.settings.caution.CheckCritical(this);
				}
				else if(MoveAIMode.Idle != this.mode)
				{
					this.ClearTarget(true);
				}
			}
			else if(!this.inSchematic &&
				MoveAIMode.Idle != this.mode)
			{
				this.ClearTarget(true);
			}
		}

		protected virtual void SetDetectedTarget(Combatant target, MoveAIMode mode, MakinomSchematicAsset schematicAsset, bool waitForSchematic)
		{
			this.pointOfInterest = null;
			if(schematicAsset != null &&
				(this.mode != mode ||
					this.targetCombatant != target))
			{
				this.ClearTarget(false);
				Schematic schematic = new Schematic(schematicAsset);
				if(waitForSchematic)
				{
					this.inSchematic = true;
					schematic.Notify(delegate ()
						{
							this.inSchematic = false;
							this.SetTarget(target, mode);
						});
					schematic.PlaySchematic(this, null, this.combatant, target,
						false, MachineUpdateType.Update, this.combatant.InputID);
				}
				else
				{
					schematic.PlaySchematic(this, null, this.combatant, target,
						false, MachineUpdateType.Update, this.combatant.InputID);
					this.SetTarget(target, mode);
				}
			}
			else
			{
				this.SetTarget(target, mode);
			}
		}

		protected virtual bool CheckFollowLeader()
		{
			if(this.settings.followLeader && !this.combatant.IsLeader)
			{
				if(this.settings.autoRespawn &&
					this.settings.autoRespawnRange.OutOfRange(this.combatant.GameObject, this.combatant.Group.Leader.GameObject))
				{
					this.combatant.Object.RespawnFlag = true;
					this.combatant.Group.RespawnGroup();
					return true;
				}
				else if(this.FollowLeaderCombatant != null)
				{
					if(this.settings.followLeaderRange.OutOfRange(this.combatant.GameObject, this.FollowLeaderCombatant.GameObject))
					{
						this.SetTarget(this.FollowLeaderCombatant, MoveAIMode.Follow);
						return true;
					}
					else if(this.settings.giveWay && this.settings.giveWayRange.InRange(this.combatant.GameObject, this.combatant.Group.Leader.GameObject))
					{
						this.SetTarget(this.FollowLeaderCombatant, MoveAIMode.GiveWay);
						return true;
					}
				}
			}
			return false;
		}

		public virtual void GroupChanged(Combatant combatant)
		{
			this.followLeaderCombatant = null;
			this.UpdateFormation();
		}

		public virtual Combatant FollowLeaderCombatant
		{
			get
			{
				if(this.settings.followNextInLine &&
					!this.isInFormation)
				{
					if(this.followLeaderCombatant == null)
					{
						this.followLeaderCombatant = this.combatant.Group.GetNextInLine(this.combatant, -1, true);
					}
					return this.followLeaderCombatant;
				}
				return this.combatant.Group.Leader;
			}
			set { this.followLeaderCombatant = value; }
		}

		public virtual void LeaderChanged(Combatant oldLeader, Combatant newLeader)
		{
			if((MoveAIMode.Follow == this.mode ||
					MoveAIMode.GiveWay == this.mode) &&
				this.targetCombatant == oldLeader)
			{
				this.SetTarget(newLeader, MoveAIMode.Follow);
			}
			else if(MoveAIMode.Waypoint == this.mode &&
				this.combatant == oldLeader)
			{
				this.SetMode(MoveAIMode.Waypoint);
				if(this.waypoint.Count > 0 &&
					this.waypointIndex < this.waypoint.Count)
				{
					this.SetMovePosition(this.waypoint[this.waypointIndex]);
				}
				else
				{
					this.SetMovePosition(this.movePosition);
				}
			}
		}

		public virtual Combatant ProtectedCombatant
		{
			get { return this.protectedCombatant; }
		}

		public virtual bool IsTargetLost()
		{
			if(this.targetCombatant != null)
			{
				if(this.targetLostTimeout > 0)
				{
					this.targetLostTimeout -= ORK.Game.DeltaMovementTime;

					// found again, stop interval
					if(this.settings.useDetection &&
						this.settings.Detect(this.combatant, this.targetCombatant))
					{
						this.targetLostTimeout = -1;
					}
					// interval ended, target lost
					else if(this.targetLostTimeout <= 0)
					{
						this.targetLostTimeout = -1;
						this.ClearTarget(false);
					}
					return true;
				}
				// target left the detection area
				else if(!this.settings.Detect(this.combatant, this.targetCombatant) &&
					!this.settings.IsSelectedTarget(this.combatant, this.targetCombatant))
				{
					// no interval, target lost
					if(this.settings.targetPositionCheck.targetLostInterval <= 0)
					{
						this.ClearTarget(false);
					}
					// set target lost interval
					else
					{
						this.targetLostTimeout = this.settings.targetPositionCheck.targetLostInterval;
					}
					return true;
				}
			}
			return false;
		}

		public virtual bool IsOutOfMoveRange()
		{
			return this.moveRangeComponent != null && this.moveRangeComponent.limitMoveRange ?
				!this.moveRangeComponent.Contains(this.combatant) :
				this.settings.useMoveRange &&
					this.settings.moveRange != null &&
					this.settings.moveRange.OutOfRange(this.startPosition, this.combatant.GameObject);
		}

		public virtual void SetOutOfMoveRange()
		{
			this.targetLostTimeout = -1;
			this.fleeTimeout = -1;
			this.ClearTarget(false);

			this.SetMode(MoveAIMode.Waypoint);
			this.SetMovePosition(this.startPosition);
		}

		public virtual void SetMoveAIRange(MoveAIRangeComponent moveRange)
		{
			this.moveRangeComponent = moveRange;
		}

		public virtual void UpdateFormation()
		{
			if(this.combatant != null)
			{
				this.isInFormation = this.combatant.Group.IsInFormation(this.combatant);
				if(this.CanUse())
				{
					this.CheckFollowLeader();
					if(MoveAIMode.Follow == this.mode)
					{
						this.UpdateTargetPosition(true);
					}
				}
			}
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public virtual void SetMode(MoveAIMode mode)
		{
			this.StopIdle();

			if(this.mode != mode &&
				(MoveAIMode.Flee == mode ||
				MoveAIMode.CautionFlee == mode))
			{
				this.lockFleeDirection = false;
				this.fleeAngle = 0;
				this.fleeAngleSide = UnityWrapper.Range(0, 2) == 1;
				this.stuckTime = 1;
				this.lastStuckAngle = this.targetObject != null ?
					VectorHelper.HorizontalAngleGlobal(this.transform,
						this.targetObject.transform.position, this.settings.horizontalPlane) :
					0;
				this.lastStuckPosition = this.transform.position;
			}

			this.mode = mode;
			this.targetLostTimeout = -1;
			this.fleeTimeout = -1;

			if(MoveAIMode.Follow == this.mode)
			{
				this.speed = this.settings.followSpeed;
			}
			else if(MoveAIMode.GiveWay == this.mode)
			{
				this.speed = this.settings.giveWaySpeed;
			}
			else if(MoveAIMode.Hunt == this.mode ||
				MoveAIMode.CautionHunt == this.mode)
			{
				this.speed = this.settings.huntingSpeed;
			}
			else if(MoveAIMode.Flee == this.mode)
			{
				this.speed = this.settings.fleeSpeed;
				this.fleeTimeout = this.settings.flee.fleeTime;
			}
			else if(MoveAIMode.Protect == this.mode)
			{
				this.speed = this.settings.protectionSpeed;
			}
			else if(MoveAIMode.Waypoint == this.mode)
			{
				this.speed = this.pointOfInterest != null ?
					this.pointOfInterest.settings.ownMoveSpeed ?
						this.pointOfInterest.settings.moveSpeed :
						this.settings.pointOfInterestSpeed :
					this.settings.waypointSpeed;
			}
			else if(MoveAIMode.CautionFlee == this.mode)
			{
				this.speed = this.settings.fleeSpeed;
			}

			if(MoveAIMode.Idle == this.mode)
			{
				this.ClearTarget(false);
				this.PerformIdle();
			}
			else
			{
				this.UpdateTargetPosition(true);
			}
		}

		public virtual MoveAIStopAngle StopAngle
		{
			get { return this.customStopAngle; }
			set { this.customStopAngle = value; }
		}

		public virtual bool HasActionRange
		{
			get { return this.actionUseRange != null; }
		}

		public virtual IRange HuntStopRange
		{
			get
			{
				if(this.actionUseRange != null)
				{
					return this.actionUseRange;
				}
				return this.settings.hunting.stopRange;
			}
		}

		public virtual IRange CautionStopRange
		{
			get
			{
				if(this.actionUseRange != null)
				{
					return this.actionUseRange;
				}
				return this.settings.caution.stopRange;
			}
		}

		public virtual IRange ProtectStopRange
		{
			get
			{
				if(this.actionUseRange != null)
				{
					return this.actionUseRange;
				}
				return this.settings.protection.stopRange;
			}
		}

		public virtual bool SetActionTarget(BaseAction action)
		{
			this.actionUseRange = null;
			this.actionUseStopAngle = false;

			if(action != null)
			{
				Combatant nearest = action.GetNearestTarget();

				if(nearest != null &&
					action.InBattleRange())
				{
					bool moveIntoRange = false;
					MoveAIMode nextMode = MoveAIMode.Hunt;
					if(this.combatant.IsEnemy(nearest))
					{
						if(MoveAIUseMode.Caution == this.useMode ||
							(MoveAIUseMode.Auto == this.useMode &&
								this.settings.caution.IsCautious(this.combatant, nearest)))
						{
							nextMode = MoveAIMode.CautionHunt;
						}
						else if(MoveAIUseMode.Protect == this.useMode ||
							(MoveAIUseMode.Auto == this.useMode &&
								this.settings.protection.CheckProtectFrom(this.combatant, nearest)))
						{
							this.protectedCombatant = this.settings.protection.GetProtectedMember(this);
							if(this.protectedCombatant != null)
							{
								nextMode = MoveAIMode.Protect;
							}
						}
					}

					TargetSelectionSettings targetSettings = TargetSelectionSettings.Get(action);
					if(targetSettings != null)
					{
						targetSettings.MoveIntoUseRange(this.combatant,
							action.Shortcut as IVariableSource,
							ref moveIntoRange, ref this.actionUseStopAngle);

						if((MoveAIMode.Hunt == nextMode &&
								this.settings.hunting.enabled &&
								this.settings.hunting.useActionStopRange) ||
							(MoveAIMode.CautionHunt == nextMode &&
								this.settings.caution.enabled &&
								this.settings.caution.useActionStopRange) ||
							(MoveAIMode.Protect == nextMode &&
								this.settings.protection.enabled &&
								this.settings.protection.useActionStopRange))
						{
							this.actionUseRange = targetSettings.GetMoveAIUseRange(
								this.combatant, action.Shortcut as IVariableSource);
						}
					}

					if(moveIntoRange)
					{
						this.SetTarget(nearest, nextMode);
						return true;
					}
				}
			}
			return false;
		}

		public virtual bool ReachedActionTarget()
		{
			// or only check the angle, since distance would be handled by inrange?
			if(MoveAIMode.Hunt == this.mode)
			{
				return !this.actionUseStopAngle || this.settings.hunting.ReachedTarget(this);
			}
			else if(MoveAIMode.CautionHunt == this.mode)
			{
				return !this.actionUseStopAngle || this.settings.caution.ReachedTarget(this);
			}
			return true;
		}

		public virtual void ActionFinished(List<Combatant> targets)
		{
			this.actionUseRange = null;
			this.actionUseStopAngle = false;

			if(targets != null)
			{
				List<Combatant> filteredTargets = new List<Combatant>();
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null &&
						this.combatant.IsEnemy(targets[i]))
					{
						if(this.settings.targetPositionCheck.targetLostInterval > 0 ||
							this.settings.Detect(this.combatant, targets[i]))
						{
							filteredTargets.Add(targets[i]);
						}
					}
				}

				if(filteredTargets.Count > 0)
				{
					Combatant nearest = TargetHelper.GetNearestTarget(this.combatant, filteredTargets, Consider.No);
					if(nearest != null)
					{
						this.ReactTo(nearest);
					}
					return;
				}
			}
			if(MoveAIMode.Waypoint != this.mode &&
				MoveAIMode.Hunt != this.mode &&
				MoveAIMode.CautionHunt != this.mode &&
				MoveAIMode.Flee != this.mode &&
				MoveAIMode.CautionFlee != this.mode &&
				MoveAIMode.Protect != this.mode)
			{
				this.PerformIdle();
			}
		}

		protected virtual void ReactTo(Combatant combatant)
		{
			if(MoveAIUseMode.Caution == this.useMode ||
				(MoveAIUseMode.Auto == this.useMode &&
					this.settings.caution.IsCautious(this.combatant, combatant)))
			{
				this.SetTarget(combatant, MoveAIMode.CautionHunt);
			}
			else if(MoveAIUseMode.Flee == this.useMode ||
				(MoveAIUseMode.Auto == this.useMode &&
					this.settings.flee.IsFlee(this.combatant, combatant)))
			{
				this.SetTarget(combatant, MoveAIMode.Flee);
			}
			else if(MoveAIUseMode.Protect == this.useMode ||
				(MoveAIUseMode.Auto == this.useMode &&
					this.settings.protection.CheckProtectFrom(this.combatant, combatant)))
			{
				this.protectedCombatant = this.settings.protection.GetProtectedMember(this);
				if(this.protectedCombatant != null)
				{
					this.SetTarget(combatant, MoveAIMode.Protect);
				}
				else
				{
					this.SetTarget(combatant, MoveAIMode.Hunt);
				}
			}
			else if(MoveAIUseMode.Idle != this.useMode)
			{
				this.SetTarget(combatant, MoveAIMode.Hunt);
			}
		}

		public virtual void AggressionBy(Combatant combatant)
		{
			if(this.settings.useDetection &&
				this.settings.detectOnAggression &&
				this.targetCombatant != combatant)
			{
				this.ReactTo(combatant);
			}
		}

		public virtual void DamagedBy(Combatant combatant)
		{
			if(this.settings.useDetection &&
				this.settings.detectOnDamage &&
				this.targetCombatant != combatant)
			{
				this.ReactTo(combatant);
			}
		}

		public virtual bool IsTarget(Combatant target)
		{
			return this.targetCombatant == target;
		}

		public virtual GameObject TargetObject
		{
			get { return this.targetObject; }
		}

		public virtual Combatant TargetCombatant
		{
			get { return this.targetCombatant; }
		}

		public virtual List<Combatant> DetectedTargets
		{
			get { return this.detectedTargets; }
		}

		public virtual void GetDetectedTargets(ref List<Combatant> list)
		{
			for(int i = 0; i < this.detectedTargets.Count; i++)
			{
				if(!list.Contains(this.detectedTargets[i]))
				{
					list.Add(this.detectedTargets[i]);
				}
			}
		}

		public virtual void SetTarget(Combatant target, MoveAIMode mode)
		{
			if(this.combatant == target)
			{
				this.targetCombatant = null;
				this.targetObject = null;
				this.Stop();
			}
			else
			{
				this.targetCombatant = target;
				this.targetObject = target != null ? target.GameObject : null;
				this.SetMode(mode);
			}
		}

		public virtual void SetTarget(GameObject target, MoveAIMode mode)
		{
			if(this.combatant.GameObject == target)
			{
				this.targetCombatant = null;
				this.targetObject = null;
				this.Stop();
			}
			else
			{
				this.targetCombatant = null;
				this.targetObject = target;
				this.SetMode(mode);
			}
		}

		public virtual void ClearTarget(bool remember)
		{
			if(MoveAIMode.Waypoint != this.mode)
			{
				this.Stop();
				this.StopIdle();
			}

			// remember last target and mode
			if(remember)
			{
				this.lastCombatant = this.targetCombatant;
				this.lastTarget = this.targetObject;
				this.lastMode = this.mode;
			}
			else
			{
				this.lastCombatant = null;
				this.lastTarget = null;
			}

			// reset target and mode
			this.targetCombatant = null;
			this.targetObject = null;
			this.mode = MoveAIMode.Idle;
		}


		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public virtual void UpdateTargetPosition(bool force)
		{
			if(this.targetObject != null &&
				(force || this.targetPosTimeout < 0 ||
					this.movePosition != this.targetObject.transform.position) &&
				((MoveAIMode.Hunt != this.mode && MoveAIMode.CautionHunt != this.mode) ||
					this.targetLostTimeout <= 0 || this.settings.targetPositionCheck.lostPositionCheck))
			{
				if(MoveAIMode.Hunt == this.mode &&
					this.targetCombatant != null)
				{
					this.SetMovePosition(this.settings.hunting.GetTargetPosition(this));
				}
				else if(MoveAIMode.CautionHunt == this.mode &&
					this.targetCombatant != null)
				{
					this.SetMovePosition(this.settings.caution.GetTargetPosition(this));
				}
				else if(MoveAIMode.Protect == this.mode &&
					this.targetCombatant != null &&
					this.protectedCombatant != null)
				{
					this.SetMovePosition(this.settings.protection.GetTargetPosition(this));
				}
				else if(MoveAIMode.Follow == this.mode)
				{
					Vector3 tmpPosition = Vector3.zero;
					if(this.combatant.Group.GetFormationPosition(this.combatant, out tmpPosition))
					{
						this.SetMovePosition(tmpPosition);
					}
					else if(!this.settings.followLeaderPosition &&
						this.FollowLeaderCombatant == this.targetCombatant &&
						this.targetCombatant.GameObject != null)
					{
						this.SetMovePosition(Vector3.MoveTowards(
							this.targetCombatant.GameObject.transform.position,
							this.combatant.GameObject.transform.position,
							this.settings.followLeaderRange.GetInRangeDistance(
								this.combatant.GameObject, this.targetCombatant.GameObject)));
					}
					else
					{
						this.SetMovePosition(this.targetObject.transform.position);
					}
				}
				else
				{
					this.SetMovePosition(this.targetObject.transform.position);
				}

				if(this.targetCombatant != null)
				{
					this.targetPosTimeout = this.settings.targetPositionCheck.GetTargetCheckInterval(
						this.combatant, this.targetCombatant, this.settings.horizontalPlane);
				}
				else
				{
					this.targetPosTimeout = this.settings.targetPositionCheck.GetTargetCheckInterval(
						this.combatant.GameObject, this.targetObject, this.settings.horizontalPlane);
				}
			}
		}

		public virtual void SetMovePosition(Vector3 position)
		{
			this.isMoving = true;
			float speed = this.speed.GetCombatantSpeed(this.combatant);

			if(MoveAIMode.Flee == this.mode ||
				MoveAIMode.GiveWay == this.mode ||
				MoveAIMode.CautionFlee == this.mode)
			{
				if(this.lockFleeDirection)
				{
					this.movePosition = this.transform.position + this.fleeDirection * speed;
				}
				else
				{
					this.movePosition = this.transform.position +
						(this.transform.position - position).normalized * speed;
				}
			}
			else
			{
				this.movePosition = position;
			}

			ORK.Game.Scene.GetPointWithinMoveAIArea(this.combatant,
				ref this.movePosition, this.transform.position);

			if(this.combatant.Object.MovementComponent != null)
			{
				this.combatant.Object.MovementComponent.MoveTo(ref this.movePosition, speed);
			}
		}

		public virtual void Stop()
		{
			if(this.targetCombatant != null)
			{
				if((MoveAIMode.Hunt == this.mode &&
						this.settings.hunting.stoppedLookAtTarget) ||
					(MoveAIMode.Flee == this.mode &&
						this.settings.flee.stoppedLookAtTarget) ||
					((MoveAIMode.CautionHunt == this.mode || MoveAIMode.CautionFlee == this.mode) &&
						this.settings.caution.stoppedLookAtTarget) ||
					(MoveAIMode.Protect == this.mode &&
						this.settings.protection.stoppedLookAtTarget))
				{
					this.combatant.Object.LookAt(this.targetCombatant);
				}
			}
			if(this.isMoving)
			{
				this.isMoving = false;
				if(this.combatant.Object.MovementComponent != null)
				{
					this.combatant.Object.MovementComponent.Stop();
				}
			}
		}

		public virtual void CheckStuck()
		{
			if(this.stuckTime > 0)
			{
				this.stuckTime -= ORK.Game.DeltaMovementTime;
			}
			else
			{
				this.stuckTime = 0.2f;
				if(Vector3.Distance(this.lastStuckPosition, this.transform.position) < 0.05f)
				{
					if(fleeAngleSide)
					{
						if(this.fleeAngle < 90)
						{
							this.fleeAngle = 90;
						}
						else
						{
							this.fleeAngle += 5;
						}
					}
					else
					{
						if(this.fleeAngle > -90)
						{
							this.fleeAngle = -90;
						}
						else
						{
							this.fleeAngle -= 5;
						}
					}
					if(this.fleeAngle < -360 ||
						this.fleeAngle > 360)
					{
						this.fleeAngle = 0;
					}

					this.lastStuckAngle = VectorHelper.HorizontalAngleGlobal(this.transform,
						this.targetObject.transform.position, this.settings.horizontalPlane);
					ValueHelper.ToAngle(ref this.lastStuckAngle);

					if(this.settings.horizontalPlane.IsXZ)
					{
						this.fleeDirection = Quaternion.Euler(0, this.fleeAngle, 0) *
							(this.transform.position - this.targetObject.transform.position).normalized;
					}
					else if(this.settings.horizontalPlane.IsXY)
					{
						this.fleeDirection = Quaternion.Euler(0, 0, -this.fleeAngle) *
							(this.transform.position - this.targetObject.transform.position).normalized;
					}

					this.lockFleeDirection = true;
				}
				else
				{
					float newAngle = VectorHelper.HorizontalAngleGlobal(this.transform,
						  this.targetObject.transform.position, this.settings.horizontalPlane);
					ValueHelper.ToAngle(ref newAngle);
					if(Mathf.Abs(this.lastStuckAngle - newAngle) > 90)
					{
						this.fleeAngle = 0;
						this.lockFleeDirection = false;
						this.fleeAngleSide = UnityWrapper.Range(0, 2) == 1;
					}
				}
				this.lastStuckPosition = this.transform.position;
			}
		}


		/*
		============================================================================
		Idle functions
		============================================================================
		*/
		protected virtual void PerformIdle()
		{
			this.Stop();
			this.mode = MoveAIMode.Idle;
			MakinomSchematicAsset schematicAsset = this.settings.GetIdleSchematic(this.combatant, ref this.idleSchematicIndex);
			if(schematicAsset != null)
			{
				this.idleSchematic = new Schematic(schematicAsset);
				this.idleSchematic.PlaySchematic(this, this, this.combatant.GameObject, this.combatant.GameObject,
							false, MachineUpdateType.Update, this.combatant.InputID);
			}
			else
			{
				this.idleSchematic = null;
				this.NextWaypoint();
			}
		}

		protected virtual void StopIdle()
		{
			if(this.idleSchematic != null && !this.idleSchematic.Stopping)
			{
				Schematic tmp = this.idleSchematic;
				this.idleSchematic = null;
				tmp.Stop();
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			if(this.idleSchematic != null &&
				this.idleSchematic == schematic)
			{
				this.idleSchematic = null;
				this.NextWaypoint();
			}
		}


		/*
		============================================================================
		POI functions
		============================================================================
		*/
		public virtual PointOfInterest PointOfInterest
		{
			get { return this.pointOfInterest; }
		}

		public virtual void SetPointOfInterest(PointOfInterest poi)
		{
			if(poi != null)
			{
				this.pointOfInterest = poi;
				this.SetTarget(this.pointOfInterest.gameObject, MoveAIMode.Waypoint);
			}
			else
			{
				this.pointOfInterest = null;
				this.targetObject = null;
				this.CheckNextWaypoint();
			}
		}

		public virtual void VisitedPOI()
		{
			if(this.pointOfInterest != null)
			{
				this.visitedPOIs.Add(this.pointOfInterest);
				if(!this.pointOfInterest.settings.visitOnce)
				{
					this.revisitPOIs.Add(this.pointOfInterest.CreateRevisit());
				}
				this.pointOfInterest = null;
				this.targetObject = null;
				this.CheckNextWaypoint();
			}
		}


		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public virtual void SetWaypoints(GameObject[] wp, bool randomOrder)
		{
			this.waypoint.Clear();
			for(int i = 0; i < wp.Length; i++)
			{
				if(wp[i] != null)
				{
					this.waypoint.Add(wp[i].transform.position);
				}
			}
			this.waypointIndex = -1;
			this.useRandomWaypoints = false;
			this.waypointRandomOrder = randomOrder;

			this.NextWaypoint();
		}

		public virtual void SetWaypoints(List<GameObject> wp, bool randomOrder)
		{
			this.waypoint.Clear();
			for(int i = 0; i < wp.Count; i++)
			{
				if(wp[i] != null)
				{
					this.waypoint.Add(wp[i].transform.position);
				}
			}
			this.waypointIndex = -1;
			this.useRandomWaypoints = false;
			this.waypointRandomOrder = randomOrder;

			this.NextWaypoint();
		}

		public virtual void SetWaypoints(List<Vector3> wp, bool randomOrder)
		{
			this.waypoint.Clear();
			this.waypoint.AddRange(wp);
			this.waypointIndex = -1;
			this.useRandomWaypoints = false;
			this.waypointRandomOrder = randomOrder;

			this.NextWaypoint();
		}

		public virtual void ClearWaypoints()
		{
			this.waypointIndex = -1;
			this.useRandomWaypoints = true;
			this.waypoint.Clear();
		}

		protected virtual void CheckNextWaypoint()
		{
			if(this.waypoint.Count > 0)
			{
				if(VectorHelper.Distance(this.gameObject, this.waypoint[this.waypointIndex],
						this.settings.IgnoreHeight, this.settings.waypointIgnoreRadius) <= this.settings.waypointStopDistance ||
					this.combatant.Object.Component.LastMoveTime + this.settings.waypointResetTime < Time.time)
				{
					this.PerformIdle();
				}
			}
			else if(this.settings.randomPatrol)
			{
				this.useRandomWaypoints = true;
				this.NextWaypoint();
			}
		}

		protected virtual void NextWaypoint()
		{
			if(this.isActiveAndEnabled &&
				(!this.settings.followLeader ||
					!this.settings.leaderNoWaypoint ||
					this.combatant.IsLeader))
			{
				if(this.useRandomWaypoints && this.settings.randomPatrol)
				{
					Maki.StartCoroutine(this.RandomWaypoint());
				}
				else if(this.waypointRandomOrder)
				{
					this.waypointIndex = UnityWrapper.Range(0, this.waypoint.Count);
				}
				else
				{
					this.waypointIndex++;
				}

				if(this.waypointIndex >= this.waypoint.Count ||
					this.waypointIndex < 0)
				{
					this.waypointIndex = 0;
				}

				if(this.waypoint.Count > 0)
				{
					this.SetMode(MoveAIMode.Waypoint);
					this.SetMovePosition(this.waypoint[this.waypointIndex]);
					this.combatant.Object.Component.LastMoveTime = Time.time;
				}
			}
		}

		protected virtual IEnumerator RandomWaypoint()
		{
			this.useRandomWaypoints = true;

			int count = 0;
			while(this.gameObject.activeInHierarchy &&
				this.enabled)
			{
				Vector3 next = this.settings.patrolFromCurrent ? this.transform.position : this.startPosition;
				next.x += UnityWrapper.Range(-this.settings.patrolRadius, this.settings.patrolRadius);

				if(this.settings.horizontalPlane.IsXY)
				{
					next.y += UnityWrapper.Range(-this.settings.patrolRadius, this.settings.patrolRadius);
				}
				else if(this.settings.horizontalPlane.IsXZ)
				{
					next.z += UnityWrapper.Range(-this.settings.patrolRadius, this.settings.patrolRadius);
				}

				if((this.moveRangeComponent == null ||
						!this.moveRangeComponent.limitRandomPatrol ||
						this.moveRangeComponent.IsWithin(next)) &&
					!ORK.Game.Scene.WithinNoRandomPatrol(next) &&
					!this.CheckRandomPatrolRaycast(next))
				{
					this.SetWaypoint(next);
					break;
				}
				else
				{
					count++;
					if(count > 10)
					{
						count = 0;
						yield return null;
					}
				}
			}
		}

		public virtual void SetWaypoint(Vector3 position)
		{
			this.waypoint.Clear();
			this.waypoint.Add(position);
			this.waypointIndex = 0;
		}

		protected virtual bool CheckRandomPatrolRaycast(Vector3 position)
		{
			if(this.settings.patrolUseRaycast)
			{
				Vector3 down = this.settings.horizontalPlane.IsXZ ? Vector3.down : Vector3.forward;
				RaycastOutput hit;
				if(RaycastHelper.Raycast(position + down * -this.settings.raycastHeightOffset, down, out hit,
					this.settings.raycastDistance + 1, this.settings.layerMask))
				{
					return RaycastColliderZone.CheckHit<NoRandomPatrol>(hit.transform.gameObject);
				}
			}
			return false;
		}

		public virtual void MoveToWaypoint(Vector3 position)
		{
			this.SetMode(MoveAIMode.Waypoint);
			this.SetWaypoint(position);
			this.stopTime = -1;
			this.lastPosition = this.transform.position;
			this.SetMovePosition(position);
		}


		/*
		============================================================================
		Move to interaction functions
		============================================================================
		*/
		public virtual void MoveToInteractionStarted(IInteractionBehaviour interaction)
		{
			this.Blocked = true;
		}

		public virtual void MoveToInteractionStopped(IInteractionBehaviour interaction)
		{
			this.Blocked = false;
		}
	}
}
