
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleEndSettings : BaseSettings
	{
		// general settings
		// experience
		[EditorHelp("Experience For Killer", "The experience points of a killed enemy will go to the (player) combatant that killed it.\n" +
			"If disabled, the whole group or battle group will get the experience points.", "")]
		[EditorFoldout("Base Settings", "Define the experience and normal status value gain options.", "")]
		[EditorTitleLabel("Experience Reward Settings")]
		public bool expForKiller = false;

		[EditorHelp("Split Experience Rewards", "The experience points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the experience.", "")]
		[EditorCondition("expForKiller", false)]
		public bool splitExp = false;

		[EditorHelp("Whole Party", "The whole (active) group will receive experience.\n" +
			"If the experience is splitted, it will be splitted by all (active) group members.", "")]
		[EditorEndCondition]
		public bool wholePartyExp = false;

		[EditorHelp("Dead Receive Exp.", "Dead group members will also receive experience.\n" +
			"If disabled, only group members who are alive will receive experience.", "")]
		public bool deadExp = false;

		// normal
		[EditorHelp("Split Normal Rewards", "The 'Normal' status value points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the 'Normal' status value reward.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Normal Status Value Reward Settings")]
		public bool splitNormalSV = false;

		[EditorHelp("Whole Party", "The whole (active) group will receive 'Normal' status value rewards.\n" +
			"If the 'Normal' status value rewards are splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyNormalSV = false;

		[EditorHelp("Dead Receive Normal", "Dead group members will also receive 'Normal' status value rewards.\n" +
			"If disabled, only group members who are alive will receive 'Normal' status value rewards.", "")]
		public bool deadNormalSV = false;

		// default battle gains collection
		[EditorFoldout("Battle Gains Collection", "Select if battle gains (loot, experience) are collected immediately " +
			"after an enemy has been defeated or at the end of the battle.\n" +
			"When collecting immediately, items and currency can also be dropped into the game world.\n" +
			"Battle systems can override the default battle gains collection.")]
		[EditorEndFoldout(2)]
		public BattleGainsCollection gainsCollection = new BattleGainsCollection();


		// loot dialogue
		[EditorArray("Add Loot Dialogue", "Adds a loot dialogue setting.\n" +
			"You can set up different loot dialogues for different battle outcomes (e.g. victory and defeat).", "",
			"Remove", "Removes this loot dialogue setting.", "",
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Loot Dialogue", "Select which loot dialogue should be used in which battle outcomes.", ""
		})]
		public LootDialogueSettings[] loot = new LootDialogueSettings[]
		{
			new LootDialogueSettings()
		};


		// level up
		[EditorFoldout("Level Up Texts", "The texts used by level up notifications to show a combatant's status changes.\n" +
			"The order of the single texts can be changed by changing the total level up text.\n" +
			"All texts will be displayed in one message.", "")]
		[EditorEndFoldout]
		public LevelUpText levelUp = new LevelUpText();

		[EditorFoldout("Standalone Level Up Dialogue", "Optionally display a level up dialogue when a combatant's level increases outside of a loot dialogue.", "")]
		[EditorEndFoldout]
		public LevelUpDialogueControl levelUpDialogue = new LevelUpDialogueControl();

		public BattleEndSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle End"; }
		}


		/*
		============================================================================
		Loot dialogue functions
		============================================================================
		*/
		/// <summary>
		/// Collects the current battle loot.
		/// </summary>
		/// <param name="collectLoot">Loot will be collected (e.g. items, equipment, etc.).</param>
		/// <param name="collectExp">Experience and 'Normal' type status value rewards will be collected.</param>
		/// <param name="showGains">The loot dialogue will be displayed.</param>
		/// <param name="autoClose">The auto close time for the loot dialoge, use a value below 0 to not use auto closing.</param>
		/// <param name="autoCloseControlable"><c>true</c> if auto close loot dialogues can still be accepted to close them sooner.</param>
		/// <param name="useItemBox">Store the loot into an item box.</param>
		/// <param name="itemBoxAddType">Use the item stacking options when storing loot in an item box.</param>
		/// <param name="itemBoxID">The box ID of the item box.</param>
		/// <param name="notifyFinished">Delegate to call when the collection finished.</param>
		/// <param name="immediateCollection"><c>true</c> if this loot collection is an immediate collection (i.e. not at the end of the battle).</param>
		public virtual void CollectGains(bool collectLoot, bool collectExp,
			bool showGains, float autoClose, bool autoCloseControlable,
			bool useItemBox, bool itemBoxAddType, string itemBoxID,
			Notify notifyFinished, bool immediateCollection)
		{
			for(int i = 0; i < this.loot.Length; i++)
			{
				if(this.loot[i].CheckOutcome(immediateCollection))
				{
					this.loot[i].settings.CollectGains(collectLoot, collectExp,
						showGains, autoClose, autoCloseControlable,
						useItemBox, itemBoxAddType, itemBoxID,
						notifyFinished);
					break;
				}
			}
		}

		public virtual void CloseLootDialogues()
		{
			for(int i = 0; i < this.loot.Length; i++)
			{
				this.loot[i].settings.Close();
			}
		}
	}
}
