
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ORKGameSettings : BaseSettings
	{
		// base settings
		// access functionality
		[EditorHelp("Access Type", "Select which type of access handler is used.\n" +
			"The access handler is used to funnel some of ORK's functionality through overridable functions. " +
			"This allows you to interject custom functionality when e.g. creating a combatant, adding an item to an inventory and many other things.\n\n" +
			"You can create custom handlers by extending the 'AccessHandler' classes and overriding the functions you want to replace.", "")]
		[EditorFoldout("ORK Game Settings", "Game settings for ORK Framework.", "")]
		[EditorInfo(settingBaseType=typeof(AccessHandler), settingAutoSetup="accessHandler")]
		public string accessHandlerType = typeof(AccessHandler).ToString();

		public AccessHandler accessHandler = new AccessHandler();


		// player group
		[EditorFoldout("Player/Group Settings", "Player group spawn and player components.", "")]
		[EditorEndFoldout]
		public PlayerGroupSettings playerGroup = new PlayerGroupSettings();


		// statistics
		[EditorFoldout("Statistic Settings", "Select which statistics the game will keep.", "")]
		[EditorEndFoldout]
		public GameStatistic statistic = new GameStatistic();


		// bestiary
		[EditorFoldout("Bestiary Settings", "Define if the bestiary is used and how information on enemies is learned.\n" +
			"The bestiary provides information about encountered enemy combatants, e.g. status values and attack/defence modifiers.", "")]
		[EditorEndFoldout]
		public BestiarySettings bestiary = new BestiarySettings();


		// game over
		[EditorFoldout("Game Over Settings", "Game over scene and retry/load choice.", "")]
		[EditorEndFoldout(2)]
		public GameOverControl gameOver = new GameOverControl();

		public ORKGameSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "ORK Game Settings"; }
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(this.accessHandler == null ||
				!this.accessHandler.IsType(this.accessHandlerType))
			{
				DataObject data = this.accessHandler != null ?
					this.accessHandler.GetData() : null;
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.accessHandlerType, typeof(AccessHandler));
				if(tmpSettings is AccessHandler)
				{
					this.accessHandler = (AccessHandler)tmpSettings;
					this.accessHandler.SetData(data);
				}
				else
				{
					this.accessHandler = new AccessHandler();
					this.accessHandler.SetData(data);
					this.accessHandlerType = this.accessHandler.GetType().ToString();
				}
			}
		}
	}
}
