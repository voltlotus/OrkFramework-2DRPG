
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class DifficultiesSettings : GenericAssetListSettings<DifficultyAsset, Difficulty>
	{
		public DifficultiesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Difficulties"; }
		}


		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public void SetStatusValueType(StatusValueSetting statusValue, StatusValueType type)
		{
			if(StatusValueType.Consumable == type)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					for(int j = 0; j < this.assets[i].Settings.faction.Length; j++)
					{
						for(int k = 0; i < this.assets[i].Settings.faction[j].statusMultiplier.Length; k++)
						{
							this.assets[i].Settings.faction[j].statusMultiplier[k].status.Is(statusValue);
							ArrayHelper.RemoveAt(ref this.assets[i].Settings.faction[j].statusMultiplier, k--);
						}
					}
				}
			}
		}
	}
}

