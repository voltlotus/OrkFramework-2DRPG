﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public abstract class BaseSubTypeData<T, V> : BaseLanguageData where T : MakinomGenericAsset<V> where V : BaseSubTypeData<T, V>, new()
	{
		// parent type
		[EditorHelp("Is Sub Type", "This type is a sub type of another type.")]
		[EditorFoldout("Base Settings", "Define the base settings of this type.")]
		public bool isSubType = false;

		[EditorHelp("Parent Type", "Select the type that is the parent type of this type.\n" +
			"Selecting the this type as parent type will result in this type not being a sub type.")]
		[EditorCondition("isSubType", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public AssetSelection<T> parentType;

		// hidden
		[EditorHelp("Hidden", "This type is hidden and will not be displayed in menus or shops.\n" +
			"E.g. use hidden types in combination with secondary types for background mechanics, type checks, etc.")]
		[EditorSeparator]
		[EditorEndFoldout]
		public bool hidden = false;

		public BaseSubTypeData()
		{

		}

		public BaseSubTypeData(string name) : base(name)
		{

		}


		/*
		============================================================================
		Parent type functions
		============================================================================
		*/
		public virtual V ParentType
		{
			get
			{
				if(this.isSubType &&
					this.parentType.StoredAsset != null &&
					this.parentType.StoredAsset.Settings != this)
				{
					return this.parentType.StoredAsset.Settings;
				}
				return null;
			}
		}

		public virtual V RootType
		{
			get
			{
				V type = this.ParentType;
				if(type != null)
				{
					return type.RootType;
				}
				return this as V;
			}
		}

		public abstract bool HasSubTypes();

		public virtual bool IsType(V type, bool checkParent)
		{
			return this == type ||
				(checkParent &&
					this.IsSubTypeOf(type));
		}

		public virtual bool IsSubTypeOf(V parentType)
		{
			V type = this.ParentType;
			if(type != null)
			{
				if(type == parentType)
				{
					return true;
				}
				else
				{
					return type.IsSubTypeOf(parentType);
				}
			}
			return false;
		}

		public virtual V GetParentTypeAfter(V parentType)
		{
			V type = this.ParentType;
			if(type != null)
			{
				if(type == parentType)
				{
					return this as V;
				}
				else
				{
					return type.GetParentTypeAfter(parentType);
				}
			}
			return parentType == null ? this as V : null;
		}

		public virtual void AddTypeToList(V parentType, ref List<V> list)
		{
			V tmpThis = this as V;
			if(this == parentType || this.ParentType == parentType)
			{
				if(!list.Contains(tmpThis))
				{
					list.Add(tmpThis);
				}
			}
			else if(parentType == null || this.IsSubTypeOf(parentType))
			{
				V tmpType = this.GetParentTypeAfter(parentType);
				if(tmpType != null &&
					!list.Contains(tmpType))
				{
					list.Add(tmpType);
				}
			}
		}

		public virtual List<V> GetTypePath()
		{
			List<V> list = new List<V>();
			this.AddTypePath(ref list);
			return list;
		}

		protected virtual void AddTypePath(ref List<V> list)
		{
			list.Insert(0, this as V);
			V type = this.ParentType;
			if(type != null && !list.Contains(type))
			{
				type.AddTypePath(ref list);
			}
		}
	}
}
