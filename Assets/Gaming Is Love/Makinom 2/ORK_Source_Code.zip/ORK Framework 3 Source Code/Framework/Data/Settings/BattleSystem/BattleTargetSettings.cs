﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Combatants;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleTargetSettings : BaseSettings
	{
		// target selection
		// target menu
		[EditorHelp("Default Target Selection", "Select the default target selection template " +
			"that will be used by abilities or items using the 'Default' target selection type.", "")]
		[EditorFoldout("Target Selection", "The settings for the target selection.\n" +
			"The target selection is used when selecting the target for a base attack, ability or item.\n" +
			"You can combine the different target selections.", "",
			"Target Menu", "Use a menu to select targets.\n" +
			"The used UI box is defined by the battle menu.", "")]
		[EditorEndFoldout]
		public TargetMenuSettings targetMenu = new TargetMenuSettings();

		// default target selections
		[EditorFoldout("Default Target Selections", "Define the default target selections that can be used by abilities and items.")]
		[EditorEndFoldout]
		public DefaultTargetSelections defaultTargetSelections = new DefaultTargetSelections();

		// target keys
		[EditorFoldout("Target Change Keys", "Define input keys that can be used to switch between available targets.\n" +
			"These keys are used during the target selection (e.g. when the target menu would be displayed).", "",
			"Next Target Key", "The key to select the next target.\n" +
			"This will move the selection down in the target menu.", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetNextKey = new AudioInputSelection();

		[EditorFoldout("Previous Target Key", "The key to select the previous target.\n" +
			"This will move the selection up in the target menu.", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetPreviousKey = new AudioInputSelection();

		[EditorFoldout("Nearest Target Key", "The key to select the target closest to the user.", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetNearestKey = new AudioInputSelection();

		// target range toggle
		[EditorFoldout("Target Range Key", "The key to toggle between 'Single' and 'Group' target range " +
			"for abilities/items that allow changing the target range.\n" +
			"This input key can be used during target selections (e.g. in the battle menu or menu screens).", "")]
		public AudioInputSelection targetRangeKey = new AudioInputSelection();

		[EditorHelp("Reset Target Range Toggle", "The target range toggle is reset after target selection ended (selecting a target or canceling).")]
		[EditorEndFoldout]
		public bool resetTargetRangeToggle = false;

		// target type toggle
		[EditorFoldout("Target Type Key", "The key to toggle between 'Enemy' and 'Ally' target type " +
			"for abilities/items that allow changing the target type.\n" +
			"This input key can be used during target selections (e.g. in the battle menu).", "")]
		public AudioInputSelection targetTypeKey = new AudioInputSelection();

		[EditorHelp("Reset Target Type Toggle", "The target type toggle is reset after target selection ended (selecting a target or canceling).")]
		[EditorEndFoldout]
		public bool resetTargetTypeToggle = false;

		// directional keys
		[EditorHelp("Use Directional Selection", "Use directional keys (up, down, left, right, or horizontal and vertical axes) " +
			"to select targets based on screen-space directions from the current target " +
			"(e.g. pressing up selects the nearest target above the current one, in screen space).\n" +
			"If no target is selected, the selection is done based on the screen center.", "")]
		[EditorFoldout("Directional Selection", "Optionally use directional keys (up, down, left, right, or horizontal and vertical axes) " +
			"to select targets based on screen-space directions from the current target.", "")]
		public bool useDirectionalSelection = false;

		[EditorHelp("Block UI Box Input", "Block the target selection from the battle menu's UI box, " +
			"i.e. horizontal and vertical menu input isn't used during target selections.", "")]
		[EditorCondition("useDirectionalSelection", true)]
		public bool directionalSelectionBlockUIBoxInput = true;

		[EditorEndFoldout(2)]
		[EditorEndCondition]
		[EditorAutoInit]
		public DirectionalTargetSelection directionalSelection;

		// highlight target
		[EditorFoldout("Target Highlight", "Optionally highlight a targeted combatant.")]
		[EditorEndFoldout]
		public HighlightCombatantSetting targetHighlight = new HighlightCombatantSetting();

		// highlight target
		[EditorFoldout("Affected Target Highlight", "Optionally highlight combatants within affect range of a targeted combatant.")]
		[EditorEndFoldout]
		public HighlightCombatantSetting affectedTargetHighlight = new HighlightCombatantSetting();

		// available targets
		[EditorHelp("In Action Selection", "The available targets of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the available target cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		[EditorFoldout("Available Target Highlight", "Optionally highlight available targets during action or target selection.")]
		public bool availableTargetActionSelection = false;

		[EditorHelp("In Target Selection", "The available targets of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the available target cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool availableTargetTargetSelection = false;

		[EditorFoldout("Available Target (Player)", "The available player target highlight is used to display " +
			"the available targets that are members of the player group during target selection (or same group as the user).")]
		[EditorEndFoldout]
		public HighlightCombatantSetting availableTargetPlayerHighlight = new HighlightCombatantSetting();

		[EditorFoldout("Available Target (Ally)", "The available ally target highlight is used to display " +
			"the available targets that are allies of the player during target selection (or ally of the user).")]
		[EditorEndFoldout]
		public HighlightCombatantSetting availableTargetAllyHighlight = new HighlightCombatantSetting();

		[EditorFoldout("Available Target (Enemy)", "The available enemy target highlight is used to display " +
			"the available targets that are enemies of the player during target selection (or enemy of the user.")]
		[EditorEndFoldout(2)]
		public HighlightCombatantSetting availableTargetEnemyHighlight = new HighlightCombatantSetting();

		// click combatant
		// raycast settings
		[EditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		[EditorFoldout("Mouse/Touch Control", "Input settings for mouse and touch control.\n" +
			"A click/touch will use a raycast on that position to find a combatant.", "")]
		[EditorTitleLabel("Raycast Settings")]
		public LayerMask targetLayerMask = -1;

		[EditorHelp("Distance", "The distance the raycast will use (from the camera).", "")]
		public float targetRayDistance = 100.0f;

		[EditorHelp("Accept Only Selected", "Mouse/touch input can only accept already selected combatants.\n" +
			"E.g. first click will select, 2nd click (on selected combatant) will accept the combatant.", "")]
		public bool targetAcceptOnlySelected = false;

		[EditorHelp("Use Grid Cell", "Selection also works on the grid cells of combatants in grid battles.", "")]
		public bool targetUseGridCell = false;

		[EditorHelp("Cursor Over Selection", "Targets can be selected by hovering the cursor over the target's game object.", "")]
		public bool targetCursorOverSelection = false;

		[EditorHelp("Cursor Move Only", "Only check for hover selection when the cursor has actually been moved.\n" +
			"If disabled, hover selection is checked at all times.", "")]
		[EditorCondition("targetCursorOverSelection", true)]
		[EditorEndCondition]
		public bool targetCursorOverMouseMoveOnly = false;

		[EditorEndFoldout()]
		[EditorSeparator]
		public MouseTouchControl targetMouseTouch = new MouseTouchControl();

		[EditorFoldout("Default Target Raycast Settings", "Abilities and items with a 'None' target range " +
			"can optionally use raycast target selection to set a target (position).\n" +
			"This can e.g. be used for area of effect type of abilities.\n" +
			"Individual abilities and items can replace the default raycast settings.", "")]
		[EditorEndFoldout(2)]
		public TargetRaycastSetting defaultTargetRaycast = new TargetRaycastSetting();


		// group targets
		[EditorFoldout("Group Target Settings", "Group targets are available to all combatants of a group.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public SelectedTargetsSettings[] groupTargetSelection = new SelectedTargetsSettings[0];


		// individual targets
		[EditorFoldout("Individual Target Settings", "Individual targets are only available to the combatant who selected them.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public SelectedTargetsSettings[] individualTargetSelection = new SelectedTargetsSettings[0];


		// target dialogues
		// target information dialogue
		[EditorFoldout("Target Dialogues", "Define optional target information or confirmation dialogues.", "",
			"Target Information Dialogue", "Optionally display status changes that " +
			"will happen to the user and targets of an ability/item.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Target Information", "Adds a target information dialogue.", "",
			"Remove", "Removes this target information dialogue.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Target Information", "Displays status changes that will happen to the user and targets of an ability/item.", ""
		})]
		public TargetInformationControl[] targetInformation = new TargetInformationControl[0];


		// target confirmation dialogue
		[EditorHelp("Show Target Confirmation", "Show a target confirmation dialogue after " +
			"selecting a target for an ability or item.\n" +
			"The ability/item will only be used when the target confirmation dialogue is accepted, " +
			"otherwise the target selection is resumed.", "")]
		[EditorFoldout("Target Confirmation Dialogue", "Optionally display a target confirmation dialogue " +
			"showing status changes that will happen to the user and targets of an ability/item.", "")]
		public bool showTargetConfirmation = false;

		[EditorSeparator]
		[EditorEndFoldout]
		[EditorCondition("showTargetConfirmation", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public TargetConfirmationControl targetConfirmation;


		// target info display
		[EditorFoldout("Target Information Layout", "Define how status change information on the " +
			"user and targets of an ability or item will be displayed.\n" +
			"This is used by the 'Target Information Dialogue' and 'Target Confirmation Dialogue' " +
			"and can optionally be overridden there.", "",
			initialState = false)]
		[EditorEndFoldout(2)]
		public TargetInformationLayout targetInformationLayout = new TargetInformationLayout();


		// in-game
		protected bool targetRangeToggle = false;

		protected bool targetTypeToggle = false;

		public BattleTargetSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useTargetMenu"))
			{
				this.targetMenu.SetData(data);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Target Settings"; }
		}


		/*
		============================================================================
		Target information functions
		============================================================================
		*/
		public virtual void ShowTargetInformation(Combatant user, List<Combatant> targets, IShortcut shortcut)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Show(user, targets, shortcut);
			}
		}

		public virtual void CursorOverTargetInformation(Combatant combatant, bool changed)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].CombatantCursorOver(combatant, changed);
			}
		}

		public virtual void CloseTargetInformation()
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Close();
			}
		}


		/*
		============================================================================
		Target toggle functions
		============================================================================
		*/
		public virtual bool TargetRangeToggle
		{
			get { return this.targetRangeToggle; }
			set { this.targetRangeToggle = value; }
		}

		public virtual void ToggleTargetRange()
		{
			this.targetRangeToggle = !this.targetRangeToggle;
		}

		public virtual bool TargetTypeToggle
		{
			get { return this.targetTypeToggle; }
			set { this.targetTypeToggle = value; }
		}

		public virtual void ToggleTargetType()
		{
			this.targetTypeToggle = !this.targetTypeToggle;
		}

		public virtual void TargetSelectionEnded()
		{
			if(this.resetTargetRangeToggle)
			{
				this.targetRangeToggle = false;
			}
			if(this.resetTargetTypeToggle)
			{
				this.targetTypeToggle = false;
			}
		}
	}
}
