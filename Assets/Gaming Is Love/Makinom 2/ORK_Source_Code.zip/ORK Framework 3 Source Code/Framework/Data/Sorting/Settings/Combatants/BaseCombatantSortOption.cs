﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public abstract class BaseCombatantSortOption : BaseTypeData
	{
		public abstract void Sort(List<Combatant> list, IDataCall call);
	}

	public abstract class BaseCombatantSortOption<T> : BaseCombatantSortOption where T : IObjectSelection, new()
	{

	}
}
