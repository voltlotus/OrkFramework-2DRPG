﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantPositionDistanceSorter : IComparer<Combatant>
	{
		private Vector3 position;

		private AxisBool ignoreDistance;

		private bool inverse = false;

		public CombatantPositionDistanceSorter(Vector3 position, AxisBool ignoreDistance, bool inverse)
		{
			this.position = position;
			this.ignoreDistance = ignoreDistance;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return 1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return -1;
				}
				else
				{
					return VectorHelper.Distance(this.position, y.GameObject.transform.position, this.ignoreDistance).CompareTo(
						VectorHelper.Distance(this.position, x.GameObject.transform.position, this.ignoreDistance));
				}
			}
			else
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return -1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return 1;
				}
				else
				{
					return VectorHelper.Distance(this.position, x.GameObject.transform.position, this.ignoreDistance).CompareTo(
						VectorHelper.Distance(this.position, y.GameObject.transform.position, this.ignoreDistance));
				}
			}
		}
	}
}
