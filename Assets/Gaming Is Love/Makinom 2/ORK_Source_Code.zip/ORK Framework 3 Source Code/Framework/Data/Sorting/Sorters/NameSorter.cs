
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public delegate string GetName(int index);
	
	public class NameSorter : IComparer<int>
	{
		private GetName GetName;
		
		private bool invert = false;
		
		public NameSorter(GetName getName, bool invert)
		{
			this.GetName = getName;
			this.invert = invert;
		}
		
		public int Compare(int x , int y)
		{
			if(this.invert)
			{
				return this.GetName(y).CompareTo(this.GetName(x));
			}
			else
			{
				return this.GetName(x).CompareTo(this.GetName(y));
			}
		}
	}
}
