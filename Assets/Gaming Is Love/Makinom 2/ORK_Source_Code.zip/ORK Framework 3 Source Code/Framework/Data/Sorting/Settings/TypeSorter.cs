
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class TypeSorter : BaseData
	{
		public enum Type { None, Name, ID }

		[EditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data are sorted by name.\n" +
			"- ID: The data are sorted by ID (i.e. the index of the data).", "")]
		public Type sorting = Type.Name;

		[EditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;

		public TypeSorter()
		{

		}

		public TypeSorter(Type sorting)
		{
			this.sorting = sorting;
		}

		public void Sort<T>(ref List<T> list) where T : IContent
		{
			if(Type.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(Type.Name == this.sorting)
			{
				list.Sort(new NameContentSorter<T>(this.invert));
			}
			else if(Type.ID == this.sorting)
			{
				list.Sort(new IDContentSorter<T>(this.invert));
			}
		}
	}
}
