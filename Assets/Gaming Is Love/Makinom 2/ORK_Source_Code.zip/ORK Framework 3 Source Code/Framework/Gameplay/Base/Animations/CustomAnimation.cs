
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class CustomAnimation : BaseData, IFoldoutInfo
	{
		[EditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		public AssetSelection<AnimationTypeAsset> type = new AssetSelection<AnimationTypeAsset>();

		[EditorArray("Add Animation", "Adds an animation - one of the added animations will be played randomly.\n", "",
			"Remove", "Remove this animation.", "",
			isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Animation", "Define the custom animation setup that will be used.\n" +
				"One of the added animations will be played randomly for the defined animation type.", ""
			})]
		public CustomAnimationBase[] animation = new CustomAnimationBase[] { new CustomAnimationBase() };

		public CustomAnimation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("playMethod"))
			{
				this.animation[0].SetData(data);
			}
		}

		public virtual string GetFoldoutInfo()
		{
			return this.type.ToString();
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public virtual float Play(Combatant combatant, Component behaviour)
		{
			return this.animation[Random.Range(0, this.animation.Length)].Play(combatant, behaviour);
		}

		public virtual void Stop(Combatant combatant, Component behaviour)
		{
			for(int i = 0; i < this.animation.Length; i++)
			{
				this.animation[i].Stop(combatant, behaviour);
			}
		}
	}
}
