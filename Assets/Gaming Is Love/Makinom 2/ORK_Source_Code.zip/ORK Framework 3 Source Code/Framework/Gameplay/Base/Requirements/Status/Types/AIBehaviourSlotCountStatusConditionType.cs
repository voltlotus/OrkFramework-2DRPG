﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("AI Behaviour Slot Count", "The combatant's number of AI behaviour slots will be compared to a defined value.")]
	public class AIBehaviourSlotCountStatusConditionType : BaseStatusConditionType
	{
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public AIBehaviourSlotCountStatusConditionType()
		{

		}

		public override string ToString()
		{
			return "AI Behaviour Slot Count " + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(combatant.AI.AIBehaviourSlot.Length, combatant.Call);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AIChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AIChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.AIChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.AIChangedSimple -= notify;
		}
	}
}
