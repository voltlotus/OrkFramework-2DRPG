﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface IStatusBonus
	{
		/// <summary>
		/// Gets the blank bonus provided by the status bonus.
		/// </summary>
		/// <returns>Status bonus information.</returns>
		StatusPreviewInformation GetStatusBonus();

		/// <summary>
		/// Adds the bonus provided by the status bonus to existing status bonus information.
		/// </summary>
		/// <param name="info">Status bonus information.</param>
		void GetStatusBonus(ref StatusPreviewInformation info);
	}
}
