
using UnityEngine;
using UnityEngine.AI;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum PlayerControlType { None, Button, Mouse, TopDown2D };

	public class PlayerControlSettings : BaseData
	{
		[EditorHelp("Player Control Type", "Select the player control type:\n" +
			"- None: No control is added, you have to add your own components to the player prefab.\n" +
			"- Button: Keyboard/joystick controls are used to move the player, using a 'Character Controller' component.\n" +
			"- Mouse: Mouse/touch controls are used to move the player.\n\n" +
			"Depending on your control type selection you'll have different settings available.\n\n" +
			"The 'Mouse' control uses raycasting to set the move target.\n" +
			"You can set up areas that block clicks/touches for player movement - " +
			"add a NoClickMove component to a game object with a collider. " +
			"The bounds are used to check if the clicked/touched position is a valid move position. " +
			"The Y-position of the game object is ignored for the check.\n" +
			"- Top Down 2D: Simple top down controls for 2D, moving on X/Y axis using a 'Rigidbody 2D' component.", "")]
		public PlayerControlType type = PlayerControlType.Button;


		// overall controls
		[EditorHelp("SC Destroy Player", "Destroy the player's game object before changing scenes.\n" +
			"Enabling this option can help with some custom player controls setting that set the player's game object to don't destroy on load.", "")]
		[EditorSeparator]
		public bool sceneChangeDestroyPlayer = false;

		[EditorHelp("Move Dead", "You can control the player, even when the player combatant is dead.", "")]
		public bool moveDead = true;

		[EditorHelp("Use Combatant Speed", "The speed of the player combatant according to its move speed settings is used.", "")]
		public bool useSpeed = true;

		[EditorHelp("Speed", "The speed in world units per second the player will move at.", "")]
		[EditorCondition("useSpeed", false)]
		[EditorEndCondition]
		[EditorLimit(0.1f, false)]
		public float runSpeed = 8.0f;

		[EditorHelp("Gravity", "The gravity used when moving.\n" +
			"Use negative numbers.", "")]
		public float gravity = Physics.gravity.y;

		[EditorHelp("Speed Smoothing", "Used to have a smooth transition between no movement and full move speed.", "")]
		public float speedSmoothing = 10.0f;


		// button controller
		[EditorSeparator]
		[EditorCondition("type", PlayerControlType.Button)]
		[EditorEndCondition]
		public ButtonPlayerControlSettings buttonController = new ButtonPlayerControlSettings();


		// mouse controller
		[EditorSeparator]
		[EditorCondition("type", PlayerControlType.Mouse)]
		[EditorEndCondition]
		public MousePlayerControlSettings mouseController = new MousePlayerControlSettings();


		// top down 2D
		[EditorSeparator]
		[EditorCondition("type", PlayerControlType.TopDown2D)]
		[EditorEndCondition]
		public TopDown2DPlayerControlSettings topDown2DController = new TopDown2DPlayerControlSettings();

		public PlayerControlSettings()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsButtonControl()
		{
			return PlayerControlType.Button == ORK.Control.PlayerControlType;
		}

		public bool IsMouseControl()
		{
			return PlayerControlType.Mouse == ORK.Control.PlayerControlType;
		}

		public bool IsTopDown2DControl()
		{
			return PlayerControlType.TopDown2D == ORK.Control.PlayerControlType;
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			if(!Maki.GameControls.interaction.IsSelectedObject)
			{
				Maki.GameControls.interaction.interactionController.AddInteractionController(player);
			}
			this.AddControlComponent(player);
		}

		public void AddControlComponent(GameObject player)
		{
			NoPlayerControl check = player.GetComponent<NoPlayerControl>();
			if(check == null)
			{
				if(this.IsButtonControl())
				{
					this.buttonController.AddPlayerControl(player);
				}
				else if(this.IsMouseControl())
				{
					this.mouseController.AddPlayerControl(player);
				}
				else if(this.IsTopDown2DControl())
				{
					this.topDown2DController.AddPlayerControl(player);
				}
			}
		}

		public void RemovePlayerControl(GameObject player)
		{
			this.RemoveControlComponent(player);
		}

		public void RemoveControlComponent(GameObject player)
		{
			NoPlayerControl check = player.GetComponent<NoPlayerControl>();
			if(check == null)
			{
				if(this.IsButtonControl())
				{
					this.buttonController.RemovePlayerControl(player);
				}
				else if(this.IsMouseControl())
				{
					this.mouseController.RemovePlayerControl(player);
				}
				else if(this.IsTopDown2DControl())
				{
					this.topDown2DController.RemovePlayerControl(player);
				}
			}
		}
	}
}
