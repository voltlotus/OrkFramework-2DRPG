﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class EquipmentPrefab : BaseData
	{
		// prefab
		public ItemPrefab itemPrefab = new ItemPrefab();

		[EditorHelp("Prefab View Prefab ", "The prefab used to display this equipment in prefab view portraits.\n" +
			"Select none to use the 'Equipment Prefab' in prefab view portraits.", "")]
		public AssetSource<GameObject> prefabViewPrefab = new AssetSource<GameObject>();


		// equipment viewer prefab
		[EditorHelp("Viewer Prefab ", "The prefab used by 'Equipment Viewers'.\n" +
			"'Equipment Viewers' can display currently equipped equipment on the scene object of a combatant.\n" +
			"Select none to not display this equipment in 'Equipment Viewers'.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Equipment Viewer Prefab")]
		public AssetSource<GameObject> viewerPrefab = new AssetSource<GameObject>();

		[EditorHelp("Viewer Prefab View Prefab", "The prefab used by 'Equipment Viewers' when displayed in prefab view portraits.\n" +
			"Select none to use the 'Viewer Prefab' in prefab view portraits.", "")]
		public AssetSource<GameObject> prefabViewViewerPrefab = new AssetSource<GameObject>();

		[EditorHelp("Viewer Name", "Define the name used for the spawned viewer prefab.\n" +
			"Leave empty to not name the prefab (i.e. the default name for spawned objects " +
			"will be used, e.g. 'Prefab(Clone)').", "")]
		[EditorWidth(true)]
		[EditorCondition("viewerPrefab", null)]
		[EditorElseCondition]
		[EditorDefaultValue("")]
		public string viewerName = "";

		[EditorHelp("Position Offset", "Offset (in local space) added to the position of the equipment viewer.\n" +
			"The offset is also added to the default prefab, if no viewer prefab is used.", "")]
		public Vector3 viewerPosOff = Vector3.zero;

		[EditorHelp("Rotation Offset", "Offset added to the rotation of the equipment viewer.\n" +
			"The offset is also added to the default prefab, if no viewer prefab is used.", "")]
		public Vector3 viewerRotOff = Vector3.zero;

		[EditorHelp("Local Rotation", "Use the rotation offset as local rotation of the prefab.", "")]
		[EditorEndCondition]
		public bool viewerLocalRotation = false;


		// viewer material
		[EditorHelp("Viewer Material", "'Equipment Viewers' can change the material used " +
			"by a renderer attached to the same game object or a child object specified in the equipment viewer.\n" +
			"Select none to not change the renderer's material.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Equipment Viewer Material")]
		public AssetSource<Material> viewerMaterial = new AssetSource<Material>();

		[EditorHelp("Prefab View Material", "The material used by 'Equipment Viewers' when displayed in prefab view portraits.\n" +
			"Select none to use the 'Viewer Material' in prefab view portraits.", "")]
		public AssetSource<Material> prefabViewMaterial = new AssetSource<Material>();


		// enable child objects
		[EditorHelp("Enable Child Object", "The path to the combatant's child object (from the root of the combatant) that will be enabled.\n" +
			"Paths in game object hierarchies are defined like this: 'path/to/child'")]
		[EditorSeparator]
		[EditorTitleLabel("Enable Child Objects")]
		[EditorArray("Add Enable Child Object", "Enable a child object on the combatant's game object.", "",
			"Remove", "Remove this child object.", "", isHorizontal = true)]
		[EditorWidth(400)]
		public string[] enableChildObject = new string[0];


		// disable child objects
		[EditorHelp("Disable Child Object", "The path to the combatant's child object (from the root of the combatant) that will be disabled.\n" +
			"Paths in game object hierarchies are defined like this: 'path/to/child'")]
		[EditorSeparator]
		[EditorTitleLabel("Disable Child Objects")]
		[EditorArray("Add Disable Child Object", "Disable a child object on the combatant's game object.", "",
			"Remove", "Remove this child object.", "", isHorizontal = true)]
		[EditorWidth(400)]
		public string[] disableChildObject = new string[0];

		public EquipmentPrefab()
		{

		}

		public virtual GameObject CreateViewerPrefab(Transform parent, bool isPrefabView)
		{
			GameObject prefab = null;
			if(isPrefabView)
			{
				prefab = this.prefabViewViewerPrefab.StoredAsset;
			}
			if(prefab == null)
			{
				prefab = this.viewerPrefab.StoredAsset;
			}
			if(prefab != null)
			{
				GameObject instance = UnityWrapper.Instantiate(prefab);

				if(parent != null)
				{
					if(this.viewerLocalRotation)
					{
						instance.transform.position = parent.TransformPoint(this.viewerPosOff);
						instance.transform.SetParent(parent);
						instance.transform.localEulerAngles = this.viewerRotOff;
					}
					else
					{
						instance.transform.SetPositionAndRotation(
							parent.TransformPoint(this.viewerPosOff),
							Quaternion.Euler(parent.eulerAngles + this.viewerRotOff));
						instance.transform.SetParent(parent);
					}
				}

				if(this.viewerName != "")
				{
					instance.name = this.viewerName;
				}
				return instance;
			}
			return null;
		}

		public virtual Material GetViewerMaterial(bool isPrefabView)
		{
			Material material = null;
			if(isPrefabView &&
				material == null)
			{
				material = this.prefabViewMaterial.StoredAsset;
			}
			if(material == null)
			{
				material = this.viewerMaterial.StoredAsset;
			}
			return material;
		}

		public virtual void UseChildObjects(Transform transform, bool activate)
		{
			// enable child objects
			for(int i = 0; i < this.enableChildObject.Length; i++)
			{
				if(!string.IsNullOrEmpty(this.enableChildObject[i]))
				{
					Transform child = transform.Find(this.enableChildObject[i]);
					if(child != null)
					{
						child.gameObject.SetActive(activate);
					}
				}
			}
			// disable child objects
			for(int i = 0; i < this.disableChildObject.Length; i++)
			{
				if(!string.IsNullOrEmpty(this.disableChildObject[i]))
				{
					Transform child = transform.Find(this.disableChildObject[i]);
					if(child != null)
					{
						child.gameObject.SetActive(!activate);
					}
				}
			}
		}
	}
}
