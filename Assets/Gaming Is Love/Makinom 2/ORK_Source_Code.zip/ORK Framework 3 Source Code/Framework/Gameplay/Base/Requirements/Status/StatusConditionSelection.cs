﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	public class StatusConditionSelection : BaseData
	{
		[EditorHelp("Status Needed", "Select which type of status will be checked:", "")]
		[EditorInfo(settingBaseType=typeof(BaseStatusConditionType), settingAutoSetup="settings")]
		public string type = typeof(StatusValueStatusConditionType).ToString();

		[EditorSeparator]
		public BaseStatusConditionType settings = new StatusValueStatusConditionType();

		public StatusConditionSelection()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(this.settings == null ||
				!this.settings.IsType(this.type))
			{
				DataObject data = this.settings != null ?
					this.settings.GetData() : null;
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.type, typeof(BaseStatusConditionType));
				if(tmpSettings is BaseStatusConditionType)
				{
					this.settings = (BaseStatusConditionType)tmpSettings;
					this.settings.SetData(data);
				}
				else
				{
					this.settings = new StatusValueStatusConditionType();
					this.settings.SetData(data);
					this.type = this.settings.GetType().ToString();
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}
	}
}
