﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.ORKFramework.Animations;

namespace GamingIsLove.ORKFramework
{
	public class CombatantPrefab : BaseData
	{
		[EditorHelp("Prefab", "Select the prefab of this combatant.\n" +
			"The prefab is used to spawn the combatant in the field and in battle.", "")]
		public AssetSource<GameObject> prefab = new AssetSource<GameObject>();

		[EditorHelp("Child as Root", "The defined child object of the game object (selected prefab) will be used as root object.\n" +
			"This can be used e.g. if the prefab root isn't the moving object.", "")]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Spawn Offset", "Offset added to the combatants game object position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;

		public ObjectChanges.Settings changesSettings = new ObjectChanges.Settings();

		[EditorHelp("Fallback Radius", "The radius of the combatant that will be used if no 'Radius' component is found on the combatant's game object.")]
		[EditorLimit(0)]
		public float fallbackRadius = 0;


		// animation system
		[EditorHelp("Own Animation System", "Override the combatant's or default animation system (defined in the general settings).")]
		[EditorSeparator]
		public bool ownAnimationSystem = false;

		[EditorCondition("ownAnimationSystem", true)]
		[EditorAutoInit]
		public CombatantAnimationSystem animationSystem;


		// animations
		[EditorHelp("Replace Default Animations", "Replace the default animations defined in the general settings.\n" +
			"Otherwise these animations will be used in addition (overriding the same animation types).")]
		[EditorSeparator]
		public bool replaceDefaultAnimations = false;

		[EditorEndCondition]
		[EditorAutoInit]
		public AnimationsFieldBattle animations;

		public CombatantPrefab()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "prefabRoot");
		}
	}
}
