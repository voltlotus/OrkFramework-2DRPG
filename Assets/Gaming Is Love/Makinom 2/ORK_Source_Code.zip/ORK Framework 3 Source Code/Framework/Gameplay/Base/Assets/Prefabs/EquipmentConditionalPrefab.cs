﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class EquipmentConditionalPrefab : BaseData, IFoldoutInfo
	{
		public EquipmentPrefab prefab = new EquipmentPrefab();


		// variable conditions
		[EditorSeparator]
		[EditorTitleLabel("Variable Conditions")]
		[EditorLabel("The equipment's variables are available as 'Local' origin.")]
		public VariableCondition<GameObjectSelection> condition = new VariableCondition<GameObjectSelection>();

		public EquipmentConditionalPrefab()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.prefab.itemPrefab.prefab.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool Check(Combatant combatant, IVariableSource variableSource)
		{
			if(this.condition.Has)
			{
				return this.condition.CheckVariables(
					new DataCall(combatant != null ? combatant : ORK.Game.ActiveGroup.Leader,
						variableSource != null && variableSource.HasVariables ? variableSource.Variables : null, null));
			}
			return true;
		}
	}
}
