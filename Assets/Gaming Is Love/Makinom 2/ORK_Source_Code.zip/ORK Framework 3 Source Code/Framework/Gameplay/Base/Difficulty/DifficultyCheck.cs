﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class DifficultyCheck : BaseData
	{
		[EditorHelp("Check Type", "The difficulty (level) is determined by the ID of the difficulty, e.g. ID 0 is less than ID 1, ID 3 is greater than ID 2.\n" +
			"Checks if the game's difficulty is equal, not equal, less or greater than the defined difficulty.\n" +
			"Range inclusive checks if the game's difficulty is between two defined difficulties, including them.\n" +
			"Range exclusive checks if the game's difficulty is between two defined difficulties, excluding them.\n" +
			"Approximately checks if the difficulty is equal to the defined difficulty.", "")]
		public ValueCheckType type = ValueCheckType.IsEqual;

		[EditorHelp("Difficulty", "Select the difficulty to check for.", "")]
		public AssetSelection<DifficultyAsset> difficulty = new AssetSelection<DifficultyAsset>();

		[EditorHelp("Difficulty 2", "Select the difficulty to check for (upper limit).", "")]
		[EditorCondition("type", ValueCheckType.RangeInclusive)]
		[EditorCondition("type", ValueCheckType.RangeExclusive)]
		[EditorEndCondition]
		public AssetSelection<DifficultyAsset> difficulty2 = new AssetSelection<DifficultyAsset>();

		public DifficultyCheck()
		{

		}

		public bool Check()
		{
			DifficultyAsset tmp = this.difficulty;
			DifficultyAsset tmp2 = this.difficulty2;
			return ValueHelper.CheckValue(ORK.Game.Difficulty.ID,
				tmp != null ? tmp.Settings.ID : -1,
				tmp2 != null ? tmp2.Settings.ID : -1, this.type);
		}

		public override string ToString()
		{
			return this.type.ToString() + " " + this.difficulty +
				(ValueCheckType.RangeInclusive == this.type || ValueCheckType.RangeExclusive == this.type ?
					" ~ " + this.difficulty2 : "");
		}
	}
}
