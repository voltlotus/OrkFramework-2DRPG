﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.UI
{
	public enum ORKSlotContentLayoutType { Text, Icon, TextAndIcon, SlotText, SlotIcon, SlotTextAndIcon, Custom, Info, LevelUpCost, None }

	public class ORKSlotContentLayout : BaseData, IContentLayout
	{
		[EditorHelp("Content Type", "Select the content type:\n" +
			"- Text: Only texts of the content will be displayed.\n" +
			"- Icon: Only icons of the content will be displayed.\n" +
			"- Text And Icon: Text and icons of the content will be displayed.\n" +
			"- Slot Text: Only texts of the slot will be displayed.\n" +
			"- Slot Icon: Only icons of the slot will be displayed.\n" +
			"- Slot Text And Icon: Text and icons of the slot will be displayed.\n" +
			"- Custom: Define the layout in a text area using text codes.\n" +
			"- Info: The default info of the displayed content (same as '<info>' text code).\n" +
			"- Level Up Cost: The level up costs of the displayed content (same as '<levelupcost> text code).\n" +
			"- None: Nothing (e.g. only show HUD content).")]
		public ORKSlotContentLayoutType type = ORKSlotContentLayoutType.TextAndIcon;

		[EditorHelp("Use Content Variables", "Variable text codes use the variables of the displayed content.\n" +
			"If the content doesn't have variables, the variable text codes will be replaced by default values (e.g. int/float '0', bool 'false', etc.).")]
		public bool useContentVariables = false;


		// HUD
		[EditorSeparator]
		public AddUIKeyHUD addHUD = new AddUIKeyHUD();


		// custom
		[EditorHelp("Add Icon", "Add the content's icon, i.e. like 'Text And Icon' with custom text.")]
		[EditorSeparator]
		[EditorCondition("type", ORKSlotContentLayoutType.Custom)]
		public bool customAddIcon = false;

		[EditorHelp("Slot Icon", "Use the icon of the slot.")]
		[EditorIndent]
		[EditorCondition("customAddIcon", true)]
		[EditorEndCondition]
		public bool customSlotIcon = false;

		[EditorHelp("Remove Empty Lines", "Remove empty lines from the text.")]
		public bool removeEmptyLines = false;

		[EditorHelp("Content Text", "The text used to display the content.")]
		[EditorLabel("Slot Content:\n" +
			"<slotname> = name, <slotshortname> = short name, <slotdescription> = description, <sloticon> = icon, <slotcustomcontent=KEY> = custom content 'KEY'\n" +
			"Content (e.g. equipment, AI behaviour/ruleset):\n" +
			"<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<level> = ability level, equipment level, combatant level (combatant, bestiary)\n" +
			"<classlevel> = class level (combatant, bestiary)\n" +
			"<quantity> = quantity, <quantityinventory> = quantity in inventory, <quantitymax> = max allowed quantity, <levelupcost> = level up costs\n" +
			"<buyprice> = buy price (x1), <totalbuyprice> = total buy price (x quantity)\n" +
			"<sellprice> = sell price (x1), <totalsellprice> = total sell price (x quantity)\n" +
			"<usecost> = use cost text\n" +
			"<reuse> = reuse time/turns, <reuse1> = with 1 decimal (0.0), <reuse2> = with 2 decimal (0.00)\n" +
			"<info> = default info, e.g. quantity, use costs, level (bestiary, combatant)")]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("CustomContentLayout")]
		public LanguageData<TextContent> customContent;

		public ORKSlotContentLayout()
		{

		}

		public ORKSlotContentLayout(ORKSlotContentLayoutType type)
		{
			this.type = type;
			if(ORKSlotContentLayoutType.Custom == this.type)
			{
				this.customContent = new LanguageData<TextContent>();
			}
		}

		public ORKSlotContentLayout(string customContent)
		{
			this.type = ORKSlotContentLayoutType.Custom;
			this.customContent = new LanguageData<TextContent>(customContent);
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool Contains(string text)
		{
			return ORKSlotContentLayoutType.Custom == this.type &&
				this.customContent.Current.text.Contains(text);
		}

		protected virtual void FinalSetup(UIText text, IVariableSource variables)
		{
			if(this.useContentVariables)
			{
				text.ReplaceVariables(variables != null && variables.HasVariables ? variables.Variables : null);
			}
		}


		/*
		============================================================================
		Text functions
		============================================================================
		*/
		protected virtual UIText GetCustomText(string name, IContent slotContent, Sprite iconSprite, Texture iconTexture)
		{
			UIText text = this.customContent.Current;
			if(this.customAddIcon)
			{
				if(this.customSlotIcon)
				{
					if(slotContent != null)
					{
						text.sprite = slotContent.GetIconSprite();
						text.texture = slotContent.GetIconTexture();
					}
				}
				else
				{
					text.sprite = iconSprite;
					text.texture = iconTexture;
				}
			}
			if(text.Contains("<"))
			{
				text.ReplaceContent(slotContent,
					"<slotname>", "<slotshortname>", "<slotdescription>", "<sloticon>", "<slotcustomcontent=",
					"", "", "", "", "");

				text.Replace("<reuse2>", "");
				text.Replace("<reuse1>", "");
				text.Replace("<reuse>", "");

				text.Replace("<name>", name);
				text.Replace("<shortname>", name);
				text.ReplaceContent(null);
				text.Replace("<level>", "");
				text.Replace("<classlevel>", "");
				text.Replace("<quantity>", "");
				text.Replace("<quantityinventory>", "");
				text.Replace("<quantitymax>", "");
				text.Replace("<totalbuyprice>", "");
				text.Replace("<buyprice>", "");
				text.Replace("<totalsellprice>", "");
				text.Replace("<sellprice>", "");
				text.Replace("<usecost>", "");
				text.Replace("<levelupcost>", "");
				text.Replace("<info>", "");

				ResearchItem.ReplaceProgressCountsEmpty(text);
			}
			if(this.removeEmptyLines)
			{
				text.RemoveEmptyLines();
			}
			return text;
		}

		protected virtual UIText GetCustomText(Combatant combatant, object content,
			IContent slotContent, IContent contentInfo, IContent typeContentInfo,
			string quantity, string inventoryQuantity, string quantityMax, string buyPrice, string sellPrice,
			string totalBuyPrice, string totalSellPrice,
			string level, string classLevel, string levelUpCost, string useCost, string info)
		{
			UIText text = this.customContent.Current;
			this.GetText(text,
				combatant, content, slotContent, contentInfo, typeContentInfo,
				quantity, inventoryQuantity, quantityMax, buyPrice, sellPrice,
				totalBuyPrice, totalSellPrice,
				level, classLevel, levelUpCost, useCost, info);
			return text;
		}

		protected virtual void GetText(UIText text, Combatant combatant, object content,
			IContent slotContent, IContent contentInfo, IContent typeContentInfo,
			string quantity, string inventoryQuantity, string quantityMax, string buyPrice, string sellPrice,
			string totalBuyPrice, string totalSellPrice,
			string level, string classLevel, string levelUpCost, string useCost, string info)
		{
			if(this.customAddIcon)
			{
				if(this.customSlotIcon)
				{
					text.sprite = slotContent.GetIconSprite();
					text.texture = slotContent.GetIconTexture();
				}
				else
				{
					text.sprite = contentInfo.GetIconSprite();
					text.texture = contentInfo.GetIconTexture();
				}
			}
			if(text.Contains("<"))
			{
				IReuseTime reuseTime = content as IReuseTime;
				if(reuseTime != null &&
					combatant != null)
				{
					text.Replace("<reuse2>", reuseTime.GetReuseTimeText(combatant, 2));
					text.Replace("<reuse1>", reuseTime.GetReuseTimeText(combatant, 1));
					text.Replace("<reuse>", reuseTime.GetReuseTimeText(combatant, 0));
				}
				else
				{
					text.Replace("<reuse2>", "");
					text.Replace("<reuse1>", "");
					text.Replace("<reuse>", "");
				}

				text.ReplaceContent(contentInfo, typeContentInfo);
				text.ReplaceContent(slotContent,
					"<slotname>", "<slotshortname>", "<slotdescription>", "<sloticon>", "<slotcustomcontent=",
					"", "", "", "", "");
				text.Replace("<level>", level);
				text.Replace("<classlevel>", classLevel);
				text.Replace("<quantity>", quantity);
				text.Replace("<quantityinventory>", inventoryQuantity);
				text.Replace("<quantitymax>", quantityMax);
				text.Replace("<totalbuyprice>", totalBuyPrice);
				text.Replace("<buyprice>", buyPrice);
				text.Replace("<totalsellprice>", totalSellPrice);
				text.Replace("<sellprice>", sellPrice);
				text.Replace("<usecost>", useCost);
				text.Replace("<levelupcost>", levelUpCost);
				text.Replace("<info>", info);

				if(content is ResearchItem)
				{
					((ResearchItem)content).ReplaceProgressCounts(text);
				}
				else
				{
					ResearchItem.ReplaceProgressCountsEmpty(text);
				}
			}
			if(this.removeEmptyLines)
			{
				text.RemoveEmptyLines();
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public virtual void UpdateContent(UIText content)
		{
			if(ORKSlotContentLayoutType.Text == this.type ||
				ORKSlotContentLayoutType.SlotText == this.type)
			{
				content.sprite = null;
				content.texture = null;
			}
			else if(ORKSlotContentLayoutType.Icon == this.type ||
				ORKSlotContentLayoutType.SlotIcon == this.type ||
				ORKSlotContentLayoutType.Info == this.type ||
				ORKSlotContentLayoutType.LevelUpCost == this.type)
			{
				content.text = "";
			}
			else if(ORKSlotContentLayoutType.Custom == this.type)
			{
				content.Set(this.GetCustomText(content.text, null, content.sprite, content.texture));
			}
			else if(ORKSlotContentLayoutType.None == this.type)
			{
				content.sprite = null;
				content.texture = null;
				content.text = "";
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual UIText GetContent(IContent slotContent, IContent content)
		{
			UIText contentText = null;
			if(ORKSlotContentLayoutType.Text == this.type)
			{
				contentText = content.GetName();
				this.addHUD.Add(contentText, content, content);
			}
			else if(ORKSlotContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("", content.GetIconSprite(), content.GetIconTexture());
				this.addHUD.Add(contentText, content, content);
			}
			else if(ORKSlotContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(content.GetName(), content.GetIconSprite(), content.GetIconTexture());
				this.addHUD.Add(contentText, content, content);
			}
			else if(ORKSlotContentLayoutType.SlotText == this.type)
			{
				contentText = slotContent.GetName();
				this.addHUD.Add(contentText, slotContent, content);
			}
			else if(ORKSlotContentLayoutType.SlotIcon == this.type)
			{
				contentText = new UIText("", slotContent.GetIconSprite(), slotContent.GetIconTexture());
				this.addHUD.Add(contentText, slotContent, content);
			}
			else if(ORKSlotContentLayoutType.SlotTextAndIcon == this.type)
			{
				contentText = new UIText(slotContent.GetName(), slotContent.GetIconSprite(), slotContent.GetIconTexture());
				this.addHUD.Add(contentText, slotContent, content);
			}
			else if(ORKSlotContentLayoutType.Info == this.type ||
				ORKSlotContentLayoutType.LevelUpCost == this.type ||
				ORKSlotContentLayoutType.None == this.type)
			{
				contentText = "";
				this.addHUD.Add(contentText, content, content);
			}
			else if(ORKSlotContentLayoutType.Custom == this.type)
			{
				Currency currency = ORK.Currencies.Get(0);
				string level = "";
				string classLevel = "";
				if(content is AbilityShortcut)
				{
					level = ((AbilityShortcut)content).LevelFormatted;
				}
				else if(content is AbilityLinkShortcut)
				{
					level = ((AbilityLinkShortcut)content).Shortcut.LevelFormatted;
				}
				else if(content is EquipShortcut)
				{
					level = ((EquipShortcut)content).LevelFormatted;
				}
				else if(content is CombatantShortcut)
				{
					CombatantShortcut combatantShortcut = (CombatantShortcut)content;
					level = combatantShortcut.Combatant.Status.LevelFormatted;
					classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
				}
				else if(content is ClassShortcut)
				{
					level = ((ClassShortcut)content).LevelFormatted;
					classLevel = level;
				}
				else if(content is ShopWrapperShortcut)
				{
					currency = ((ShopWrapperShortcut)content).Currency;
					IShortcut tmpContent = ((ShopWrapperShortcut)content).Shortcut;
					if(tmpContent is AbilityShortcut)
					{
						level = ((AbilityShortcut)tmpContent).LevelFormatted;
					}
					else if(tmpContent is EquipShortcut)
					{
						level = ((EquipShortcut)tmpContent).LevelFormatted;
					}
					else if(tmpContent is CombatantShortcut)
					{
						CombatantShortcut combatantShortcut = (CombatantShortcut)tmpContent;
						level = combatantShortcut.Combatant.Status.LevelFormatted;
						classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
					}
					else if(tmpContent is ShopClassShortcut)
					{
						level = ((ShopClassShortcut)tmpContent).LevelFormatted;
						classLevel = level;
					}
				}

				string levelUpCost = "";

				int buyPrice = 0;
				int sellPrice = 0;
				int priceQuantity = 0;
				if(content is IShortcut)
				{
					Combatant combatant = ORK.Menu.GetMenuUser();
					if(combatant == null)
					{
						combatant = ORK.Game.ActiveGroup.Leader;
					}
					IShortcut shortcut = (IShortcut)content;
					buyPrice = shortcut.BuyPrice(combatant);
					sellPrice = shortcut.SellPrice(combatant);
					priceQuantity = shortcut.Quantity > 0 ? shortcut.Quantity : 1;
				}

				string useCost = "";

				contentText = this.GetCustomText(null, content,
					// content
					slotContent, content, null,
					// quantity, price
					"", "", "",
					ORK.TextDisplaySettings.priceText.GetBuyText(currency, buyPrice),
					ORK.TextDisplaySettings.priceText.GetSellText(currency, sellPrice),
					ORK.TextDisplaySettings.priceText.GetBuyText(currency, buyPrice * priceQuantity),
					ORK.TextDisplaySettings.priceText.GetSellText(currency, sellPrice * priceQuantity),
					// level, cost, info
					level, classLevel, levelUpCost, useCost, "");
				this.addHUD.Add(contentText, content != null ? content : slotContent, content);
			}
			this.FinalSetup(contentText, content as IVariableSource);
			return contentText;
		}

		public virtual UIText GetContent(IContent slotContent, IShortcut content, IContent typeContent, Combatant combatant, DragShortcutWrapper wrapper)
		{
			UIText contentText = null;
			if(ORKSlotContentLayoutType.Text == this.type)
			{
				contentText = content.GetName();
			}
			else if(ORKSlotContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("", content.GetIconSprite(), content.GetIconTexture());
			}
			else if(ORKSlotContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(content.GetName(), content.GetIconSprite(), content.GetIconTexture());
			}
			else if(ORKSlotContentLayoutType.SlotText == this.type)
			{
				contentText = slotContent.GetName();
			}
			else if(ORKSlotContentLayoutType.SlotIcon == this.type)
			{
				contentText = new UIText("", slotContent.GetIconSprite(), slotContent.GetIconTexture());
			}
			else if(ORKSlotContentLayoutType.SlotTextAndIcon == this.type)
			{
				contentText = new UIText(slotContent.GetName(), slotContent.GetIconSprite(), slotContent.GetIconTexture());
			}
			else if(ORKSlotContentLayoutType.Info == this.type)
			{
				contentText = CombatantContentHelper.Get(content, combatant);
			}
			else if(ORKSlotContentLayoutType.LevelUpCost == this.type)
			{
				if(content is ILevelUpCostText)
				{
					contentText = ((ILevelUpCostText)content).GetLevelUpCostString(combatant);
				}
				else
				{
					contentText = "";
				}
			}
			else if(ORKSlotContentLayoutType.Custom == this.type)
			{
				Currency currency = ORK.Currencies.Get(0);
				string level = "";
				string classLevel = "";
				if(content is AbilityShortcut)
				{
					level = ((AbilityShortcut)content).LevelFormatted;
				}
				else if(content is AbilityLinkShortcut)
				{
					level = ((AbilityLinkShortcut)content).Shortcut.LevelFormatted;
				}
				else if(content is EquipShortcut)
				{
					level = ((EquipShortcut)content).LevelFormatted;
				}
				else if(content is CombatantShortcut)
				{
					CombatantShortcut combatantShortcut = (CombatantShortcut)content;
					level = combatantShortcut.Combatant.Status.LevelFormatted;
					classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
				}
				else if(content is ClassShortcut)
				{
					level = ((ClassShortcut)content).LevelFormatted;
					classLevel = level;
				}
				else if(content is ShopWrapperShortcut)
				{
					currency = ((ShopWrapperShortcut)content).Currency;
					IShortcut tmpContent = ((ShopWrapperShortcut)content).Shortcut;
					if(tmpContent is AbilityShortcut)
					{
						level = ((AbilityShortcut)tmpContent).LevelFormatted;
					}
					else if(tmpContent is EquipShortcut)
					{
						level = ((EquipShortcut)tmpContent).LevelFormatted;
					}
					else if(tmpContent is CombatantShortcut)
					{
						CombatantShortcut combatantShortcut = (CombatantShortcut)tmpContent;
						level = combatantShortcut.Combatant.Status.LevelFormatted;
						classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
					}
					else if(tmpContent is ShopClassShortcut)
					{
						level = ((ShopClassShortcut)tmpContent).LevelFormatted;
						classLevel = level;
					}
				}

				string levelUpCost = content is ILevelUpCostText ?
					((ILevelUpCostText)content).GetLevelUpCostString(combatant) : "";

				int buyPrice = content.BuyPrice(combatant);
				int sellPrice = content.SellPrice(combatant);
				int priceQuantity = content.Quantity > 0 ? content.Quantity : 1;

				string useCost = content is IUseCostDisplay ?
					((IUseCostDisplay)content).GetUseCostText(combatant) : "";

				contentText = this.GetCustomText(combatant, content,
					// content
					slotContent, content, typeContent,
					// quantity, price
					ORK.TextDisplaySettings.quantityText.GetText(content),
					ORKTextHelper.GetInventoryQuantity(content),
					ORKTextHelper.GetMaxQuantity(combatant, content),
					ORK.TextDisplaySettings.priceText.GetBuyText(currency, buyPrice),
					ORK.TextDisplaySettings.priceText.GetSellText(currency, sellPrice),
					ORK.TextDisplaySettings.priceText.GetBuyText(currency, buyPrice * priceQuantity),
					ORK.TextDisplaySettings.priceText.GetSellText(currency, sellPrice * priceQuantity),
					// level, cost, info
					level, classLevel, levelUpCost, useCost, CombatantContentHelper.Get(content, combatant));
			}
			else if(ORKSlotContentLayoutType.None == this.type)
			{
				contentText = "";
			}
			this.addHUD.Add(contentText, wrapper, content);
			this.FinalSetup(contentText, content as IVariableSource);
			return contentText;
		}
	}
}
