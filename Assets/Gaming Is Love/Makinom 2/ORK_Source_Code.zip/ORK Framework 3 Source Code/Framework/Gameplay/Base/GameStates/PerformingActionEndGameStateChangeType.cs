﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Performing Action End", "When a battle action ends performing (no active action afterwards).")]
	public class PerformingActionEndGameStateChangeType : BaseGameStateChangeType
	{
		public PerformingActionEndGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Battle.Actions.ActiveEnd += notify;
		}
	}
}
