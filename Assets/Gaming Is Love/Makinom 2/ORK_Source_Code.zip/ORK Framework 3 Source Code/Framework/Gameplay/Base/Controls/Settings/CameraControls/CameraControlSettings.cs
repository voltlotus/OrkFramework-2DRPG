
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum CameraControlType { None, Follow, Look, Mouse, FirstPerson, TopDownBorder };

	public class CameraControlSettings : BaseData
	{
		[EditorHelp("Camera Control Type", "Select the camera control type:\n" +
			"- None: No control is added to the camera. " +
			"You have to add a camera control component to the camera in each scene by hand.\n" +
			"- Follow: The camera will follow behind the player.\n" +
			"- Look: The camera will look at the player.\n" +
			"- Mouse: The camera will follow the player. " +
			"Height and rotation can be changed by mouse/touch control.\n" +
			"- First Person: The camera is linked to the player (or a child object). " +
			"It can be moved horizontally/vertically (e.g. by mouse).\n" +
			"- Top Down Border: The camera follows the player until the he crosses a border. " +
			"The border is defined using a 'Camera Border' component with a 'Box Collider' in the scene.", "")]
		public CameraControlType type = CameraControlType.Follow;


		// follow
		[EditorCondition("type", CameraControlType.Follow)]
		[EditorEndCondition]
		public FollowCameraSettings followControl = new FollowCameraSettings();


		// look
		[EditorCondition("type", CameraControlType.Look)]
		[EditorEndCondition]
		public LookCameraSettings lookControl = new LookCameraSettings();


		// mouse
		[EditorCondition("type", CameraControlType.Mouse)]
		[EditorEndCondition]
		public MouseCameraSettings mouseControl = new MouseCameraSettings();


		// first person
		[EditorCondition("type", CameraControlType.FirstPerson)]
		[EditorEndCondition]
		public FirstPersonCameraSettings firstPersonControl = new FirstPersonCameraSettings();


		// top down border
		[EditorCondition("type", CameraControlType.TopDownBorder)]
		[EditorEndCondition]
		public TopDownBorderCameraSettings topDownBorderControl = new TopDownBorderCameraSettings();


		// camera control target transition
		[EditorFoldout("Control Target Transition", "You can optionally use a transition when changing the camera control target.", "")]
		[EditorEndFoldout]
		public CameraControlTargetTransition targetTransition = new CameraControlTargetTransition();

		public CameraControlSettings()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsFollowControl()
		{
			return CameraControlType.Follow == ORK.Control.CameraControlType;
		}

		public bool IsLookControl()
		{
			return CameraControlType.Look == ORK.Control.CameraControlType;
		}

		public bool IsMouseControl()
		{
			return CameraControlType.Mouse == ORK.Control.CameraControlType;
		}

		public bool IsFirstPersonControl()
		{
			return CameraControlType.FirstPerson == ORK.Control.CameraControlType;
		}

		public bool IsTopDownBorderControl()
		{
			return CameraControlType.TopDownBorder == ORK.Control.CameraControlType;
		}


		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public void AddCameraControl(GameObject camera)
		{
			this.AddControlComponent(camera);
		}

		public void AddControlComponent(GameObject camera)
		{
			NoCameraControl check = camera.GetComponent<NoCameraControl>();
			if(check == null)
			{
				if(this.IsFollowControl())
				{
					this.followControl.Setup(camera);
				}
				else if(this.IsLookControl())
				{
					this.lookControl.Setup(camera);
				}
				else if(this.IsMouseControl())
				{
					this.mouseControl.Setup(camera);
				}
				else if(this.IsFirstPersonControl())
				{
					this.firstPersonControl.Setup(camera);
				}
				else if(this.IsTopDownBorderControl())
				{
					this.topDownBorderControl.Setup(camera);
				}
			}
		}

		public void RemoveCameraControl(GameObject camera)
		{
			this.RemoveControlComponent(camera);
		}

		public void RemoveControlComponent(GameObject camera)
		{
			NoCameraControl check = camera.GetComponent<NoCameraControl>();
			if(check == null)
			{
				if(this.IsFollowControl())
				{
					SmoothFollow comp = camera.GetComponent<SmoothFollow>();
					Maki.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsLookControl())
				{
					SmoothLookAt comp = camera.GetComponent<SmoothLookAt>();
					Maki.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsMouseControl())
				{
					MouseCamera comp = camera.GetComponent<MouseCamera>();
					Maki.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsFirstPersonControl())
				{
					FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
					Maki.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsTopDownBorderControl())
				{
					TopDownBorderCamera comp = camera.GetComponent<TopDownBorderCamera>();
					Maki.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
			}
		}
	}
}
