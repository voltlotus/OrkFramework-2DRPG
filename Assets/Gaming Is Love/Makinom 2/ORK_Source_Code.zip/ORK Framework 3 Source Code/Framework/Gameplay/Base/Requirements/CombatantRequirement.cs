
using System;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantRequirement : BaseData
	{
		[EditorHelp("Combatant", "The selected combatant is required.", "")]
		public AssetSelection<CombatantAsset> combatant = new AssetSelection<CombatantAsset>();

		[EditorSeparator]
		[EditorTitleLabel("Status Conditions")]
		public StatusConditionSettings statusConditions = new StatusConditionSettings();

		public CombatantRequirement()
		{

		}

		public bool Check()
		{
			if(this.combatant.StoredAsset != null)
			{
				Combatant combatant = ORK.Game.ActiveGroup.GetMember(this.combatant.StoredAsset.Settings);
				if(combatant != null &&
					this.statusConditions.Check(combatant))
				{
					return true;
				}
			}
			return false;
		}
	}
}

