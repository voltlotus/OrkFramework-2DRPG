﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Clear Selected Data", "Clears selected data, i.e. either all or " +
		"the selected data of the defined key will be removed.", "")]
	[NodeInfo("Selected Data")]
	public class ClearSelectedDataNode : BaseAINode
	{
		[EditorHelp("Clear All", "Clears/removes all data.\n" +
			"If disabled, only the selected data of a defined key is cleared/removed.", "")]
		public bool all = false;

		[EditorCondition("all", true)]
		public SelectedDataOrigin<BattleAIObjectSelection> allSelectedData = new SelectedDataOrigin<BattleAIObjectSelection>();

		[EditorElseCondition]
		[EditorEndCondition]
		public SelectedData<BattleAIObjectSelection> selectedData = new SelectedData<BattleAIObjectSelection>();

		public ClearSelectedDataNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.all)
			{
				this.allSelectedData.Clear(call);
			}
			else
			{
				this.selectedData.Clear(call, this.selectedData.key.GetValue(call));
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? this.allSelectedData.ToString() : this.selectedData.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Selected Data Count", "Checks how many data is stored in a selected data list.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Selected Data")]
	public class SelectedDataCountNode : BaseAICheckNode
	{
		public SelectedData<BattleAIObjectSelection> selectedData = new SelectedData<BattleAIObjectSelection>();

		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public SelectedDataCountNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.check.Check(this.selectedData.GetCount(call), call))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.ToString() + " " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Selected Data", "Uses the first, last, a random or all content from another selected data as selected data.\n" +
		"E.g. select a random content from a list of data.\n" +
		"If something was stored, 'Success' will be executed, otherwise (i.e. nothing left to store) 'Failed'.", "")]
	[NodeInfo("Selected Data")]
	public class SelectSelectedDataNode : BaseAICheckNode
	{
		// store
		[EditorFoldout("Store Selected Data", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> storeSelectedData = new SelectedDataChange<BattleAIObjectSelection>();


		// source
		[EditorFoldout("Source Selected Data", "The source of the selected data.", "")]
		[EditorCondition("storeSelectedData.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public SelectedData<BattleAIObjectSelection> sourceSelectedData = new SelectedData<BattleAIObjectSelection>();

		[EditorHelp("Select Type", "Define which content of the selected data will be stored:\n" +
			"- First: The first content in the selected data.\n" +
			"- Last: The last content in the selected data.\n" +
			"- Random: A random content from the selected data.\n" +
			"- All: All content from the selected data.", "")]
		[EditorSeparator]
		public ListSelectionType selectionType = ListSelectionType.Random;

		[EditorHelp("Remove", "Removes the content from the selected data.", "")]
		[EditorEndCondition]
		[EditorEndFoldout]
		public bool remove = false;

		public SelectSelectedDataNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool stored = false;

			if(ListChangeType.Clear == this.storeSelectedData.changeType)
			{
				this.storeSelectedData.Change(null, call, true);
			}
			else
			{
				string sourceKey = this.sourceSelectedData.key.GetValue(call);
				List<object> list = this.sourceSelectedData.GetSelectedData(call, sourceKey);

				if(list != null)
				{
					if(ListSelectionType.First == this.selectionType)
					{
						if(list.Count > 0)
						{
							this.StoreSingle(call, list[0], ref stored, list);
						}
					}
					else if(ListSelectionType.Last == this.selectionType)
					{
						if(list.Count > 0)
						{
							this.StoreSingle(call, list[list.Count - 1], ref stored, list);
						}
					}
					else if(ListSelectionType.Random == this.selectionType)
					{
						if(list.Count > 0)
						{
							this.StoreSingle(call, list[Random.Range(0, list.Count)], ref stored, list);
						}
					}
					else if(ListSelectionType.All == this.selectionType)
					{
						if(list.Count > 0)
						{
							stored = true;
							this.storeSelectedData.Change(list, call, true);

							if(this.remove)
							{
								this.sourceSelectedData.Clear(call, sourceKey);
							}
						}
					}
				}
			}

			if(stored)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void StoreSingle(BattleAICall call, object newData, ref bool stored, List<object> list)
		{
			if(newData != null)
			{
				stored = true;
				this.storeSelectedData.Change(newData, call, true);

				if(this.remove)
				{
					list.Remove(newData);
					this.sourceSelectedData.Change(call, list, ListChangeType.Set);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.storeSelectedData.IsClear)
			{
				return this.storeSelectedData.ToString();
			}
			return this.storeSelectedData.ToString() + ": " +
				this.selectionType + " " + this.sourceSelectedData.ToString() +
				(this.remove ? " (remove)" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Combatant", "Uses combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectCombatantNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// combatants
		[EditorHelp("Use All Combatants", "The list of all combatants will be set as selected data.\n" +
			"If disabled, only the first available combatant will be set as selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool allCombatants = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorCondition("allCombatants", true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Use Random", "Use a random combatant from the group.", "")]
		[EditorCondition("combatantScope", MenuCombatantScope.Current)]
		[EditorElseCondition]
		[EditorEndCondition(2)]
		public bool useRandom = false;

		[EditorSeparator]
		public SelectCombatantSettings<BattleAIObjectSelection> selectCombatant = new SelectCombatantSettings<BattleAIObjectSelection>();

		[EditorSeparator]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();


		// requirements
		[EditorHelp("Use Requirements", "Check for enemy state or valid conditions, " +
			"e.g. combatant status or variable conditions to check if a combatant will be used.\n" +
			"The requirements are only checked for the combatant itself, not e.g. the combatant's last targets.", "")]
		[EditorFoldout("Filter Settings", "Optionally filter the used combatants by checking for enemies or valid conditions, " +
			"e.g. combatant status or variable conditions.", "")]
		public bool useRequirements = false;

		[EditorHelp("Is Enemy", "Select if the combatants are enemies of the user:\n" +
			"- Yes: The combatants are enemies.\n" +
			"- No: The combatants are allies.\n" +
			"- Ignore: Ignores the faction standings.", "")]
		[EditorCondition("useRequirements", true)]
		public Consider isEnemy = Consider.Ignore;

		[EditorSeparator]
		[EditorEndFoldout]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public CombatantGeneralConditionSettings conditions;

		public SelectCombatantNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				List<Combatant> found = new List<Combatant>();
				List<Combatant> list = this.targetSettings.GetTargetList(call);

				if(this.allCombatants)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(this.useRequirements)
						{
							this.conditions.FilterList(list);
						}
						for(int i = 0; i < list.Count; i++)
						{
							call.checkTarget = list[i];
							this.selectCombatant.Get(call, list[i], found);
						}
					}
					else
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						if(this.useRequirements)
						{
							this.conditions.FilterList(combatants);
						}

						if(this.useRandom)
						{
							Combatant tmpCombatant = combatants[UnityWrapper.Range(0, combatants.Count)];
							call.checkTarget = tmpCombatant;
							this.selectCombatant.Get(call, tmpCombatant, found);
						}
						else
						{
							for(int i = 0; i < combatants.Count; i++)
							{
								call.checkTarget = combatants[i];
								this.selectCombatant.Get(call, combatants[i], found);
							}
						}
					}
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null &&
							(!this.useRequirements || this.conditions.Check(list[i])))
						{
							call.checkTarget = list[i];
							this.selectCombatant.Get(call, list[i], found);
							break;
						}
					}
				}

				if(found.Count > 0 &&
					this.useRequirements &&
					Consider.Ignore != this.isEnemy)
				{
					for(int i = 0; i < found.Count; i++)
					{
						if(found[i].IsEnemy(call.user) == (Consider.No == this.isEnemy))
						{
							found.RemoveAt(i--);
						}
					}
				}
				call.checkTarget = null;
				this.dataChange.Change(found, call, true);
			}

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + this.targetSettings.ToString() + (this.allCombatants ? " (all)" : "")));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Combatant Body Part", "Uses body parts of combatants or the parent combatant of body parts as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectCombatantBodyPartNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// combatants
		[EditorFoldout("Combatant Settings", "Define the combatant and body parts that will be used.")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();

		[EditorHelp("Get Parent Combatant", "Get the parent combatant of the defined combatants (body parts).\n" +
			"If disabled, body parts of the defined combatants will be used.")]
		[EditorSeparator]
		[EditorEndFoldout]
		public bool getParentCombatant = false;


		// conditions
		[EditorFoldout("Conditions", "Optionally check for defined conditions being valid to select a body part or parent combatant.")]
		[EditorEndFoldout]
		public CombatantGeneralConditionSettings conditions = new CombatantGeneralConditionSettings();

		public SelectCombatantBodyPartNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				List<Combatant> found = new List<Combatant>();
				List<Combatant> list = this.targetSettings.GetTargetList(call);

				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.getParentCombatant)
						{
							if(list[i].IsBodyPart)
							{
								CombatantBodyPart bodyPart = list[i] as CombatantBodyPart;
								if(bodyPart != null &&
									!found.Contains(bodyPart.Parent) &&
									this.conditions.Check(bodyPart.Parent))
								{
									found.Add(bodyPart.Parent);
								}
							}
						}
						else if(list[i].HasBodyParts)
						{
							List<CombatantBodyPart> bodyPart = list[i].GetBodyParts();
							if(bodyPart != null)
							{
								for(int j = 0; j < bodyPart.Count; j++)
								{
									if(bodyPart[j] != null &&
										!found.Contains(bodyPart[j]) &&
										this.conditions.Check(bodyPart[j]))
									{
										found.Add(bodyPart[j]);
									}
								}
							}
						}
					}
				}

				if(found.Count == 1)
				{
					this.dataChange.Change(found[0], call, true);
				}
				else if(found.Count > 1)
				{
					this.dataChange.Change(found, call, true);
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + this.targetSettings.ToString() +
					(this.getParentCombatant ? " (parent)" : " (body parts)")));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Ability", "Uses abilities of combatants or a newly created ability as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectAbilityNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// ability settings
		[EditorHelp("Create Ability", "Create a new instance of the defined ability.\n" +
			"If disabled, abilities known by a combatant will be used.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Ability Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool createAbility = false;

		// all abilities
		[EditorHelp("All Abilities", "Get all abilities of the combatant.", "")]
		[EditorCondition("createAbility", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool allAbilities = false;

		[EditorHelp("Useable In", "Select where the abilities can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Passive abilities.", "")]
		[EditorCondition("allAbilities", true)]
		public UseableIn useableIn = UseableIn.Both;

		[EditorHelp("Add Temporary Abilities", "Select if temporary abilities will be included:\n" +
			"- Yes: Temporary abilities will be included.\n" +
			"- No: Temporary abilities will not be included.\n" +
			"- Only: Only temporary abilities will be used.", "")]
		public IncludeCheckType addTemporary = IncludeCheckType.Yes;

		[EditorHelp("Add Passive Toggleable", "Add passive abilities that can be turned on/off.")]
		[EditorCondition("useableIn", UseableIn.None)]
		[EditorElseCondition]
		[EditorEndCondition]
		public bool addPassiveToggleable = false;

		[EditorHelp("Add Hidden Abilities", "Hidden abilities (either via the ability or ability type being hidden) will be added.\n" +
			"If disabled, hidden abilities will be excluded.")]
		public bool addHidden = true;

		[EditorHelp("Limit Ability Type", "Limit the abilities to a defined ability type and it's sub-types.", "")]
		public bool limitAbilityType = false;

		[EditorHelp("Ability Type", "Select the ability type that will be used to limit the abilities.", "")]
		[EditorCondition("limitAbilityType", true)]
		[EditorAutoInit]
		public AssetSelection<AbilityTypeAsset> abilityType;

		[EditorHelp("Use Sub-Types", "The sub-types of the defined ability type will also be used.", "")]
		[EditorEndCondition]
		public bool useSubTypes = true;

		// ability
		[EditorElseCondition]
		[EditorEndCondition]
		public AbilitySelection ability = new AbilitySelection();


		// combatant
		[EditorHelp("Use All Combatants", "The abilities of all combatants will be set as selected data.\n" +
			"If disabled, only the first available ability will be set as selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorCondition("createAbility", false)]
		public bool allCombatants = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorCondition("allCombatants", true)]
		[EditorEndCondition]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorSeparator]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();

		public SelectAbilityNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else if(this.createAbility)
			{
				this.dataChange.Change(this.ability.CreateShortcut(AbilityState.None), call, true);
			}
			else
			{
				List<Combatant> list = this.targetSettings.GetTargetList(call);

				AbilityType tmpType = this.limitAbilityType && this.abilityType.StoredAsset != null ?
					this.abilityType.StoredAsset.Settings : null;

				if(this.allCombatants)
				{
					List<AbilityShortcut> abilities = new List<AbilityShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allAbilities)
							{
								List<AbilityShortcut> tmpAbilities = tmpType != null ?
									list[i].Abilities.GetByType(tmpType, this.useableIn, this.addTemporary, this.addPassiveToggleable, this.useSubTypes) :
									list[i].Abilities.GetAbilities(this.useableIn, this.addTemporary, this.addPassiveToggleable);

								for(int j = 0; j < tmpAbilities.Count; j++)
								{
									if((this.addHidden || !tmpAbilities[j].IsHidden) &&
										!abilities.Contains(tmpAbilities[j]))
									{
										abilities.Add(tmpAbilities[j]);
									}
								}
							}
							else
							{
								AbilityShortcut ability = this.ability.GetAbility(list[i]);

								if(ability != null &&
									!abilities.Contains(ability))
								{
									abilities.Add(ability);
								}
							}
						}
					}

					this.dataChange.Change(abilities, call, true);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allAbilities)
							{
								List<AbilityShortcut> tmpAbilities = tmpType != null ?
									list[i].Abilities.GetByType(tmpType, this.useableIn, this.addTemporary, this.addPassiveToggleable, this.useSubTypes) :
									list[i].Abilities.GetAbilities(this.useableIn, this.addTemporary, this.addPassiveToggleable);
								if(!this.addHidden)
								{
									for(int j = 0; j < tmpAbilities.Count; j++)
									{
										if(tmpAbilities[j].IsHidden)
										{
											tmpAbilities.RemoveAt(j--);
										}
									}
								}
								this.dataChange.Change(tmpAbilities, call, true);
								break;
							}
							else
							{
								AbilityShortcut ability = this.ability.GetAbility(list[i]);

								if(ability != null)
								{
									this.dataChange.Change(ability, call, true);
									break;
								}
							}
						}
					}
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + (this.createAbility ?
					"Create " :
					(this.targetSettings.ToString() + (this.allCombatants ? " (all) " : " "))) +
				(this.allAbilities ? "all abilities" : this.ability.ToString())));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Base Attack", "Uses base attacks of combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectBaseAttackNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// attack settings
		[EditorHelp("Base Attack Scope", "Select the scope of the base attack that will be used:\n" +
			"- Current: Use the current base attack of the combatant.\n" +
			"- Index: Use a base attack at a defined index.\n" +
			"- All: Use all base attacks of the combatant.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Base Attack Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public BaseAttackScope attackScope = BaseAttackScope.Current;

		[EditorHelp("Attack Index", "The index of the base attack.")]
		[EditorCondition("attackScope", BaseAttackScope.Index)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<BattleAIObjectSelection> attackIndex;


		// combatant
		[EditorHelp("Use All Combatants", "The base attacks of all combatants will be set as selected data.\n" +
			"If disabled, only the first available base attack will be set as selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		public bool allCombatants = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorCondition("allCombatants", true)]
		[EditorEndCondition]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorSeparator]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();

		public SelectBaseAttackNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				List<Combatant> list = this.targetSettings.GetTargetList(call);
				if(this.allCombatants)
				{
					List<AbilityShortcut> abilities = new List<AbilityShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(BaseAttackScope.All == this.attackScope)
							{
								list[i].Abilities.GetBaseAttacks(ref abilities);
							}
							else
							{
								AbilityShortcut ability = null;

								if(BaseAttackScope.Current == this.attackScope)
								{
									ability = list[i].Abilities.GetCurrentBaseAttack();
								}
								else if(BaseAttackScope.Index == this.attackScope)
								{
									call.checkTarget = list[i];
									ability = list[i].Abilities.GetBaseAttack((int)this.attackIndex.GetValue(call));
								}

								if(ability != null &&
									!abilities.Contains(ability))
								{
									abilities.Add(ability);
								}
							}
						}
					}

					this.dataChange.Change(abilities, call, true);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(BaseAttackScope.All == this.attackScope)
							{
								List<AbilityShortcut> abilities = new List<AbilityShortcut>();
								list[i].Abilities.GetBaseAttacks(ref abilities);
								this.dataChange.Change(abilities, call, true);
								break;
							}
							else
							{
								AbilityShortcut ability = null;

								if(BaseAttackScope.Current == this.attackScope)
								{
									ability = list[i].Abilities.GetCurrentBaseAttack();
								}
								else if(BaseAttackScope.Index == this.attackScope)
								{
									call.checkTarget = list[i];
									ability = list[i].Abilities.GetBaseAttack((int)this.attackIndex.GetValue(call));
								}

								if(ability != null)
								{
									this.dataChange.Change(ability, call, true);
									break;
								}
							}
						}
					}
				}
			}

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + this.targetSettings.ToString() + (this.allCombatants ? " (all) " : " ") +
				this.attackScope.ToString()));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Counter Attack", "Uses counter attacks of combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectCounterAttackNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// combatant
		[EditorHelp("Use All Combatants", "The counter attacks of all combatants will be set as selected data.\n" +
			"If disabled, only the first available counter attack will be set as selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool allCombatants = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorCondition("allCombatants", true)]
		[EditorEndCondition]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorSeparator]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();

		public SelectCounterAttackNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				List<Combatant> list = this.targetSettings.GetTargetList(call);
				if(this.allCombatants)
				{
					List<AbilityShortcut> abilities = new List<AbilityShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							AbilityShortcut ability = list[i].Abilities.GetCounterAttack();

							if(ability != null &&
								!abilities.Contains(ability))
							{
								abilities.Add(ability);
							}
						}
					}

					this.dataChange.Change(abilities, call, true);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							call.checkTarget = list[i];
							this.dataChange.Change(list[i].Abilities.GetCounterAttack(), call, true);
							break;
						}
					}
				}
			}

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + this.targetSettings.ToString() + (this.allCombatants ? " (all)" : "")));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Equipment", "Uses the equipment currently equipped on combatants as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectEquipmentNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// equipment
		[EditorHelp("All Equipment", "Use all currently equipped equipment of the combatant.\n" +
			"If disabled, only the equipment of a defined equipment slot will be used.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Equipment Settings")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool allEquipment = false;

		[EditorHelp("Equipment Slot", "Select the equipment slot which's current equipment will be used.", "")]
		[EditorCondition("allEquipment", false)]
		[EditorEndCondition]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		[EditorHelp("Limit Item Type", "Limit the equipment to a defined item type and its sub-types.", "")]
		public bool limitItemType = false;

		[EditorHelp("Item Type", "Select the item type that will be used to limit the equipment.", "")]
		[EditorCondition("limitItemType", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<ItemTypeAsset> itemType;


		// combatant
		[EditorHelp("Use All Combatants", "The equipment of all combatants will be set as selected data.\n" +
			"If disabled, only the first available equipment will be set as selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Combatant Settings")]
		public bool allCombatants = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorCondition("allCombatants", true)]
		[EditorEndCondition]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorSeparator]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();


		// filter
		[EditorHelp("Use Filter", "Use equipment variable conditions on the equipment.\n" +
			"Equipment that doesn't match the conditions will not be used.\n" +
			"The equipment variables are available as 'Local' variable origin.", "")]
		[EditorFoldout("Filter Settings", "Optionally filter the used equipment by using equipment variable conditions on them.\n" +
			"The equipment variables are available as 'Local' variable origin.", "")]
		public bool useFilter = false;

		[EditorSeparator]
		[EditorEndFoldout]
		[EditorCondition("useFilter", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public VariableCondition<BattleAIObjectSelection> condition;

		public SelectEquipmentNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				ItemType tmpType = this.limitItemType && this.itemType.StoredAsset != null ?
					this.itemType.StoredAsset.Settings : null;
				List<Combatant> list = this.targetSettings.GetTargetList(call);
				if(this.allCombatants)
				{
					List<EquipShortcut> equipment = new List<EquipShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allEquipment)
							{
								for(int j = 0; j < ORK.EquipmentSlots.Count; j++)
								{
									if(list[i].Equipment[j].Available &&
										list[i].Equipment[j].Equipped)
									{
										call.checkTarget = list[i];
										EquipShortcut equip = list[i].Equipment[j].Equipment;

										if(equip != null &&
											!equipment.Contains(equip) &&
											(!this.limitItemType ||
												equip.IsItemType(tmpType, true)) &&
											(!this.useFilter ||
												(equip.HasVariables &&
													this.condition.CheckVariables(call))))
										{
											equipment.Add(equip);
										}
									}
								}
							}
							else if(this.equipmentSlot.StoredAsset != null)
							{
								EquipmentSlot equipSlot = list[i].Equipment.GetSlot(this.equipmentSlot.StoredAsset.Settings);
								if(equipSlot.Available &&
									equipSlot.Equipped)
								{
									call.checkTarget = list[i];
									EquipShortcut equip = equipSlot.Equipment;

									if(equip != null &&
										!equipment.Contains(equip) &&
										(!this.limitItemType ||
											equip.IsItemType(tmpType, true)) &&
										(!this.useFilter ||
											(equip.HasVariables &&
												this.condition.CheckVariables(call))))
									{
										equipment.Add(equip);
									}
								}
							}
						}
					}

					this.dataChange.Change(equipment, call, true);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							call.checkTarget = list[i];
							if(this.allEquipment)
							{
								List<EquipShortcut> equipment = new List<EquipShortcut>();

								for(int j = 0; j < ORK.EquipmentSlots.Count; j++)
								{
									if(list[i].Equipment[j].Available &&
										list[i].Equipment[j].Equipped)
									{
										EquipShortcut equip = list[i].Equipment[j].Equipment;

										if(equip != null &&
											!equipment.Contains(equip) &&
											(!this.limitItemType ||
												equip.IsItemType(tmpType, true)) &&
											(!this.useFilter ||
												(equip.HasVariables &&
													this.condition.CheckVariables(call))))
										{
											equipment.Add(equip);
										}
									}
								}

								this.dataChange.Change(equipment, call, true);
								break;
							}
							else if(this.equipmentSlot.StoredAsset != null)
							{
								EquipmentSlot equipSlot = list[i].Equipment.GetSlot(this.equipmentSlot.StoredAsset.Settings);
								if(equipSlot.Available &&
									equipSlot.Equipped)
								{
									EquipShortcut equip = equipSlot.Equipment;

									if(equip != null &&
										(!this.limitItemType ||
											equip.IsItemType(tmpType, true)) &&
										(!this.useFilter ||
											(equip.HasVariables &&
												this.condition.CheckVariables(call))))
									{
										this.dataChange.Change(equip, call, true);
										break;
									}
								}
							}
						}
					}
				}
			}

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + this.targetSettings.ToString() + (this.allCombatants ? " (all) " : " ") +
				(this.allEquipment ? "all equipment" : this.equipmentSlot.ToString())));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Item", "Uses items from the inventory of combatants or newly created items as selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectItemNode : BaseAINode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<BattleAIObjectSelection> dataChange = new SelectedDataChange<BattleAIObjectSelection>();


		// item settings
		[EditorHelp("Create Item", "Create new instances of the defined items.\n" +
			"If disabled, items from the inventories of combatants will be used.", "")]
		[EditorFoldout("Item Settings", "Define the items that will be selected.")]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public bool createItem = false;

		// all items
		[EditorHelp("All Items", "Use all items currently in the combatant's inventory.\n" +
			"If disabled, only the defined items will be used.", "")]
		[EditorCondition("createItem", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool allItems = false;

		[EditorHelp("Add Hidden Items", "Hidden items (either via the item or item type being hidden) will be added.\n" +
			"If disabled, hidden items will be excluded.")]
		[EditorCondition("allItems", true)]
		public bool addHidden = true;

		[EditorSeparator]
		public InventoryAccessSettings inventoryAccess = new InventoryAccessSettings();

		// item type
		[EditorHelp("Limit Item Type", "Limit the items to a defined item type and its sub-types.", "")]
		[EditorSeparator]
		public bool limitItemType = false;

		[EditorHelp("Item Type", "Select the item type that will be used to limit the items.", "")]
		[EditorCondition("limitItemType", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<ItemTypeAsset> itemType;

		// define items
		[EditorEndFoldout]
		[EditorArray("Add Item", "Adds an item to the list.", "",
			"Remove", "Removes this item from the list.", "",
			noRemoveCount = 1, isCopy = true, isMove = true, foldout = true, foldoutText = new string[] {
				"Item", "Define the item.", ""
		})]
		[EditorElseCondition]
		[EditorEndCondition]
		public ItemGain<BattleAIObjectSelection>[] item = new ItemGain<BattleAIObjectSelection>[] {
			new ItemGain<BattleAIObjectSelection>()
		};


		// combatant
		[EditorHelp("Use All Combatants", "The items of all combatants will be set as selected data.\n" +
			"If disabled, only the first available items will be set as selected data.", "")]
		[EditorFoldout("Combatant Settings", "Define the combatant which's inventory will be used.")]
		[EditorCondition("createItem", false)]
		public bool allCombatants = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorCondition("allCombatants", true)]
		[EditorEndCondition]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorSeparator]
		public BattleAISelectedDataTargetSettings targetSettings = new BattleAISelectedDataTargetSettings();

		// inventory containers
		[EditorHelp("Use Inventory Container", "Select items from a defined inventory container.\n" +
			"No items will be selected if the combatant doesn't have inventory containers " +
			"(e.g. when feature not used or limited to player combatants).")]
		[EditorSeparator]
		public bool useInventoryContainer = false;

		[EditorHelp("Inventory Container", "Select the inventory container that will be used.")]
		[EditorEndFoldout]
		[EditorCondition("useInventoryContainer", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<InventoryContainerAsset> inventoryContainer;


		// filter
		[EditorHelp("Use Filter", "Use item or equipment variable conditions on the items and equipment.\n" +
			"Items and equipment that doesn't match the conditions will not be used.\n" +
			"Other things without variables will not be checked.\n" +
			"The item/equipment variables are available as 'Local' variable origin.", "")]
		[EditorFoldout("Filter Settings", "Optionally filter the used items and equipment " +
			"by using item/equipment variable conditions on them.\n" +
			"The item/equipment variables are available as 'Local' variable origin.", "")]
		public bool useFilter = false;

		[EditorSeparator]
		[EditorLabel("The item/equipment's variables are available as 'Local' origin.")]
		[EditorEndFoldout]
		[EditorCondition("useFilter", true)]
		[EditorEndCondition(3)]
		[EditorAutoInit]
		public VariableCondition<BattleAIObjectSelection> condition;

		public SelectItemNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else if(this.createItem)
			{
				List<IShortcut> items = new List<IShortcut>();
				for(int i = 0; i < this.item.Length; i++)
				{
					items.Add(this.item[i].CreateShortcut(call.user.Call));
				}
				this.dataChange.Change(items, call, true);
			}
			else
			{
				ItemType tmpType = this.limitItemType && this.itemType.StoredAsset != null ?
					this.itemType.StoredAsset.Settings : null;
				List<Combatant> list = this.targetSettings.GetTargetList(call);
				if(this.allCombatants)
				{
					List<Inventory> inventory = new List<Inventory>();
					List<IShortcut> items = new List<IShortcut>();

					if(MenuCombatantScope.Current == this.combatantScope ||
						ORK.InventorySettings.IsGroup())
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null &&
								!inventory.Contains(list[i].Inventory))
							{
								inventory.Add(list[i].Inventory);
							}
						}
					}
					else
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								List<Combatant> group = new List<Combatant>();
								list[i].Group.GetMembers(this.combatantScope, ref group);
								for(int j = 0; j < group.Count; j++)
								{
									if(group[j] != null &&
										!inventory.Contains(group[j].Inventory))
									{
										inventory.Add(group[j].Inventory);
									}
								}
							}
						}
					}

					for(int i = 0; i < inventory.Count; i++)
					{
						if(inventory[i] != null)
						{
							List<IShortcut> tmpItems = new List<IShortcut>();
							if(this.allItems)
							{
								if(this.useInventoryContainer)
								{
									InventoryContainer container = inventory[i].GetContainer(this.inventoryContainer.StoredAsset);
									if(container != null)
									{
										this.inventoryAccess.GetAll(container, tmpType, true, ref tmpItems);
									}
								}
								else
								{
									this.inventoryAccess.GetAll(inventory[i], tmpType, true, ref tmpItems);
								}
								if(!this.addHidden)
								{
									for(int j = 0; j < tmpItems.Count; j++)
									{
										if(ShortcutHelper.IsHidden(tmpItems[j]))
										{
											tmpItems.RemoveAt(j--);
										}
									}
								}
							}
							else if(this.useInventoryContainer)
							{
								InventoryContainer container = inventory[i].GetContainer(this.inventoryContainer.StoredAsset);
								if(container != null)
								{
									for(int j = 0; j < this.item.Length; j++)
									{
										this.item[j].GetFromInventoryContainer(call, container, true, ref tmpItems);
									}
								}
							}
							else
							{
								for(int j = 0; j < this.item.Length; j++)
								{
									this.item[j].GetFromInventory(call, inventory[i], true, ref tmpItems);
								}
							}
							this.Filter(call, inventory[i].GetOwner(), tmpItems);
							items.AddRange(tmpItems);
						}
					}

					this.dataChange.Change(items, call, true);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							call.checkTarget = list[i];
							List<IShortcut> items = new List<IShortcut>();
							if(this.allItems)
							{
								if(this.useInventoryContainer)
								{
									InventoryContainer container = list[i].Inventory.GetContainer(this.inventoryContainer.StoredAsset);
									if(container != null)
									{
										this.inventoryAccess.GetAll(container, tmpType, true, ref items);
									}
								}
								else
								{
									this.inventoryAccess.GetAll(list[i].Inventory, tmpType, true, ref items);
								}
								if(!this.addHidden)
								{
									for(int j = 0; j < items.Count; j++)
									{
										if(ShortcutHelper.IsHidden(items[j]))
										{
											items.RemoveAt(j--);
										}
									}
								}
							}
							else if(this.useInventoryContainer)
							{
								InventoryContainer container = list[i].Inventory.GetContainer(this.inventoryContainer.StoredAsset);
								if(container != null)
								{
									for(int j = 0; j < this.item.Length; j++)
									{
										this.item[j].GetFromInventoryContainer(call, container, true, ref items);
									}
								}
							}
							else
							{
								for(int j = 0; j < this.item.Length; j++)
								{
									this.item[j].GetFromInventory(call, list[i].Inventory, true, ref items);
								}
							}

							this.Filter(call, list[i], items);
							if(items.Count > 0)
							{
								this.dataChange.Change(items, call, true);
								break;
							}
						}
					}
				}
			}

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}

		private void Filter(BattleAICall call, Combatant combatant, List<IShortcut> list)
		{
			if(this.useFilter)
			{
				for(int i = 0; i < list.Count; i++)
				{
					call.checkTarget = combatant;
					if(list[i] == null)
					{
						list.RemoveAt(i--);
					}
					else if(list[i] is ItemShortcut)
					{
						ItemShortcut item = (ItemShortcut)list[i];
						if(!item.HasVariables ||
							!this.condition.CheckVariables(call))
						{
							list.RemoveAt(i--);
						}
					}
					else if(list[i] is EquipShortcut)
					{
						EquipShortcut equip = (EquipShortcut)list[i];
						if(!equip.HasVariables ||
							!this.condition.CheckVariables(call))
						{
							list.RemoveAt(i--);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dataChange.ToString() +
				(ListChangeType.Clear == this.dataChange.changeType ? "" :
				(" " + (this.createItem ?
					"Create" :
					(this.targetSettings.ToString() + (this.allCombatants ? " (all)" : "") +
						(this.allItems ? " all items" : "")))));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
