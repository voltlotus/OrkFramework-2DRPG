﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public delegate void BattleAICheckMultiTargets(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets);

	public delegate void BattleAICheckMultiTargets2(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets, List<Combatant> failList);

	public class BattleAIMultiTargetSettings : BaseData
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		public BattleAITargetSettings targetSettings = new BattleAITargetSettings();

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		public BattleAIMultiTargetSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override string ToString()
		{
			return this.targetSettings + ", " + this.foundType + " found";
		}

		public virtual bool Use(BattleAICall call, BattleAICheckMultiTargets check)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				check(ref any, call, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				check(ref any, call, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			check(ref any, call, this.targetSettings.GetTargetList(call), call.foundTargets);
			return any;
		}

		public virtual bool Use(BattleAICall call, BattleAICheckMultiTargets2 check, List<Combatant> failList)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				check(ref any, call, tmp, call.foundTargets, failList);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				check(ref any, call, call.foundTargets, call.foundTargets, failList);
			}

			// check all possible targets
			check(ref any, call, this.targetSettings.GetTargetList(call), call.foundTargets, failList);
			return any;
		}
	}
}
