
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(ShopInteraction))]
public class ShopInteractionInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as ShopInteraction);
	}

	private void ComponentSetup(ShopInteraction target)
	{
		Undo.RecordObject(target, "Change to 'Shop Interaction' on " + target.name);
		this.BaseInit(true);

		// shop ID
		this.ShowSceneGUID(target, "Use Shop ID", "Get New Shop ID",
			"The shop ID is used to keep track of shop's contents.\n" +
			"If shops share the same ID, their content will also be shared.\n" +
			"The shop ID is used game-wide, i.e. also in different scenes.");

		if(this.baseEditor.BeginFoldout("Shop Settings", "Define the shop that will be used.", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}