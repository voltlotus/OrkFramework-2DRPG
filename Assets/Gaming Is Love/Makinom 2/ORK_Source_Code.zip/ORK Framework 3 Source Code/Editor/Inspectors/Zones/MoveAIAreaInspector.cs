﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(MoveAIArea))]
public class MoveAIAreaInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as MoveAIArea);
	}

	protected virtual void ComponentSetup(MoveAIArea target)
	{
		Undo.RecordObject(target, "Change to 'Move AI Area' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}