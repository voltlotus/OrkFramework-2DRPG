﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(NoClickMove))]
public class NoClickMoveInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as NoClickMove);
	}

	protected virtual void ComponentSetup(NoClickMove target)
	{
		Undo.RecordObject(target, "Change to 'No Click Move' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}