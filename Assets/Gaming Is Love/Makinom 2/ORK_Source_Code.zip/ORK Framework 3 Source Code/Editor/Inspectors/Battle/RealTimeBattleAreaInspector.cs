
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(RealTimeBattleArea))]
public class RealTimeBattleAreaInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as RealTimeBattleArea);
	}

	protected virtual void ComponentSetup(RealTimeBattleArea target)
	{
		Undo.RecordObject(target, "Change to 'Real Time Battle Area' on " + target.name);
		this.BaseInit(true);

		if(target.EditorHasCollider())
		{
			EditorGUILayout.HelpBox("The real time battle starts when the player enters the trigger " +
				"and ends when the player leaves the trigger.\n" +
				"Remove the trigger (collider) to enable real time battle for the whole scene.",
				MessageType.Info);
		}
		else
		{
			EditorGUILayout.HelpBox("The real time battle starts when the player enters the scene " +
				"and ends when the player leaves the scene.\n" +
				"Add a trigger (collider) to limit the real time battle to an area of the scene.",
				MessageType.Info);
		}

		// start settings
		this.ShowBaseCondition(target);

		this.EndSetup();
	}
}
