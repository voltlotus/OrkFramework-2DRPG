
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class StatusDevelopmentEditor : MakinomFullViewEditor
	{
		protected string title = "";

		protected int[] value;

		protected int[] oldValue;

		protected int minLevel = 1;

		// curve points
		protected LevelPoint[] point = new LevelPoint[] { new LevelPoint(), new LevelPoint() };


		// scrolls
		protected Vector2 scroll = Vector2.zero;

		protected Vector2 scrollPoint = Vector2.zero;

		protected Vector2 scrollValue = Vector2.zero;


		// textures
		protected Texture2D tex = new Texture2D(1, 1);

		protected Texture2D tex2 = new Texture2D(1, 1);

		protected Texture2D tex3 = new Texture2D(1, 1);


		// min/max values
		protected int minValue = 0;

		protected int maxValue = 0;

		protected int barWidth = 2;

		protected bool barHighestValueDisplay = false;

		protected bool useHighestValueMax = false;

		protected int lastLevelHighlight = -1;


		// animation curve
		protected bool useCurve = false;

		protected AnimationCurve animationCurve;

		protected float maxCurveValue = 1000;

		protected Rect curveRanges;

		public StatusDevelopmentEditor(MakinomEditorWindow parent, string title,
			StatusValueSetting statusValue, int minLvl, ref int[] development) : base(parent)
		{
			this.title = title + " Curve Editor";

			this.minLevel = minLvl;
			this.oldValue = development;
			this.value = new int[development.Length];
			System.Array.Copy(development, this.value, development.Length);

			this.tex.SetPixel(0, 0, new Color(0, 0.5f, 1, 1));
			this.tex.Apply();
			this.tex2.SetPixel(0, 0, new Color(0, 0.5f, 1, 0.5f));
			this.tex2.Apply();
			this.tex3.SetPixel(0, 0, new Color(1, 0, 0, 1));
			this.tex3.Apply();

			if(statusValue != null)
			{
				this.minValue = statusValue.minValue;
				this.maxValue = statusValue.maxValue;
				this.maxCurveValue = this.maxValue;
			}
			else
			{
				this.minValue = 0;
				this.maxValue = int.MaxValue;
				this.useHighestValueMax = true;
				this.maxCurveValue = this.HighestValue;
			}

			// set base points
			this.point[0].level = this.minLevel;
			this.point[0].value = this.value[0];
			this.point[1].level = this.value.Length + this.minLevel - 1;
			this.point[1].value = this.value[this.value.Length - 1];

			// bar width
			if(this.value.Length > 250)
			{
				this.barWidth = 1;
			}
			else if(this.value.Length > 150)
			{
				this.barWidth = 2;
			}
			else if(this.value.Length > 100)
			{
				this.barWidth = 3;
			}
			else if(this.value.Length > 50)
			{
				this.barWidth = 4;
			}
			else if(this.value.Length > 25)
			{
				this.barWidth = 6;
			}
			else if(this.value.Length > 10)
			{
				this.barWidth = 8;
			}
			else
			{
				this.barWidth = 10;
			}

			this.animationCurve = new AnimationCurve(
				new Keyframe(this.minLevel, this.minValue),
				new Keyframe(this.value.Length + this.minLevel, this.maxCurveValue));
			this.curveRanges = new Rect(this.minLevel, this.minValue,
				this.value.Length + this.minLevel, this.maxCurveValue);
		}

		public virtual int HighestValue
		{
			get
			{
				int highest = 0;
				for(int i = 0; i < this.value.Length; i++)
				{
					if(highest < this.value[i])
					{
						highest = this.value[i];
					}
				}
				return highest;
			}
		}

		protected virtual void AddPointButton()
		{
			if(this.point.Length < this.value.Length &&
				GUILayout.Button(new GUIContent("Add Point", EditorContent.Instance.AddIcon, "Add a curve generation point.")))
			{
				LevelPoint newPoint = new LevelPoint();
				newPoint.level = this.point[this.point.Length - 2].level + 1;
				newPoint.value = this.point[this.point.Length - 2].value;
				ArrayHelper.Insert(ref this.point, this.point.Length - 1, newPoint);
				this.scrollPoint.y = Mathf.Infinity;
				GUI.changed = true;
			}
		}

		public override bool ShowGUI()
		{
			base.ShowGUI();

			bool close = false;

			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxStyle, GUILayout.ExpandHeight(true));

			EditorTool.BoldLabel(this.title);

			this.scroll = EditorGUILayout.BeginScrollView(this.scroll);

			EditorGUILayout.BeginHorizontal();

			// curve generation
			EditorGUILayout.BeginVertical(GUILayout.Width(325));
			EditorTool.BoldLabel("Curve Generation");

			EditorTool.Field("Use Curve", ref this.useCurve, "Use a curve to generate the values.", "", null, null);

			if(this.useCurve)
			{
				if(this.useHighestValueMax)
				{
					float tmpCurve = this.maxCurveValue;
					EditorTool.Field("Max Curve Value", ref this.maxCurveValue, "The maximum value of the curve.", "", null, null);
					if(tmpCurve != this.maxCurveValue)
					{
						this.curveRanges = new Rect(this.minLevel, this.minValue,
							this.value.Length + this.minLevel, this.maxCurveValue);
					}
				}
				EditorTool.CurveField("Curve", ref this.animationCurve, "", "", this.curveRanges, null, null);
			}
			else
			{
				EditorGUILayout.Separator();
				EditorTool.Field("Start Value (Min. Level)", ref this.point[0].value, "Set the curve generation start value, " +
					"which is the value at the minimum level.", "", null, null);
				EditorGUILayout.Separator();

				this.AddPointButton();
				EditorGUILayout.Separator();

				this.scrollPoint = EditorGUILayout.BeginScrollView(this.scrollPoint);

				for(int i = 1; i < this.point.Length - 1; i++)
				{
					EditorGUILayout.Separator();

					EditorGUILayout.BeginHorizontal();
					if(GUILayout.Button(
						new GUIContent(EditorContent.Instance.RemoveIcon, "Remove this curve point."),
						EditorTool.WIDTH_30))
					{
						ArrayHelper.RemoveAt(ref this.point, i);
						//i--;
						break;
					}

					EditorTool.BoldLabel("Point " + i);
					EditorGUILayout.EndHorizontal();

					EditorAutomation.Automate(this.point[i], this);

					if(this.point[i].level <= this.point[i - 1].level)
					{
						this.point[i].level = this.point[i - 1].level + 1;
					}
					else if(this.point[i].level >= this.point[i + 1].level)
					{
						this.point[i].level = this.point[i + 1].level - 1;
					}
					if(this.point[i].level < this.minLevel)
					{
						this.point[i].level = this.minLevel;
					}
					else if(this.point[i].level > this.value.Length + this.minLevel)
					{
						this.point[i].level = this.value.Length + this.minLevel;
					}
				}

				EditorGUILayout.EndScrollView();

				if(this.point.Length > 2)
				{
					EditorGUILayout.Separator();
					this.AddPointButton();
				}

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Last Point");
				EditorTool.Field("End Value (Max. Level)", ref this.point[this.point.Length - 1].value,
					"Set the curve generation end point, which is the value at the maximum level.", "", null, null);
				EditorAutomation.Automate(this.point[this.point.Length - 1].interpolation, this);

				for(int i = 0; i < this.point.Length; i++)
				{
					if(this.point[i].value < this.minValue)
					{
						this.point[i].value = this.minValue;
					}
					else if(this.point[i].value > this.maxValue)
					{
						this.point[i].value = this.maxValue;
					}
				}
			}

			if(GUILayout.Button(new GUIContent("Generate Curve", EditorContent.Instance.EditBigIcon, "Generate a status value development curve.")))
			{
				this.GenerateCurve();
			}

			// bar width
			EditorGUILayout.Separator();
			EditorTool.Field("Bar Width", ref this.barWidth,
				"Define the width used per value bar in the bar display.", "", null, null);
			if(this.barWidth < 1)
			{
				this.barWidth = 1;
			}
			if(this.barWidth > 10)
			{
				this.barWidth = 10;
			}
			if(!this.useHighestValueMax)
			{
				EditorTool.Field("Bar Highest Value Display", ref this.barHighestValueDisplay,
					"Use the highest value instead of the status value's maximum value for the bar display.", "", null, null);
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();


			// draw values

			Rect rect = new Rect(350, 25, this.value.Length * this.barWidth, this.parent.position.height - 100);

			int lvl = -1;
			Vector2 mousePosition = Event.current.mousePosition;
			if(mousePosition.x >= rect.x &&
				mousePosition.x <= rect.x + rect.width &&
				mousePosition.y >= rect.y &&
				mousePosition.y <= rect.y + rect.height)
			{
				lvl = (int)(mousePosition.x - 350) / this.barWidth;
			}

			if(lvl != this.lastLevelHighlight)
			{
				this.lastLevelHighlight = lvl;
				this.parent.Repaint();
			}

			GUILayout.Space(this.value.Length * this.barWidth + 50);

			GUI.Box(rect, "");

			int tmpMax = this.useHighestValueMax || this.barHighestValueDisplay ? this.HighestValue : this.maxValue;
			float o = (this.parent.position.height - 100) / tmpMax;
			for(int i = 0; i < this.value.Length; i++)
			{
				if(lvl == i)
				{
					GUI.DrawTexture(new Rect(350 + (i * this.barWidth),
						25 + (tmpMax - this.value[i]) * o, this.barWidth,
						this.value[i] * o), this.tex3);
				}
				else if(i % 2 == 0)
				{
					GUI.DrawTexture(new Rect(350 + (i * this.barWidth),
						25 + (tmpMax - this.value[i]) * o, this.barWidth,
						this.value[i] * o), this.tex);
				}
				else
				{
					GUI.DrawTexture(new Rect(350 + (i * this.barWidth),
						25 + (tmpMax - this.value[i]) * o, this.barWidth,
						this.value[i] * o), this.tex2);
				}
			}
			if(lvl >= 0 && lvl < this.value.Length)
			{
				GUI.Label(new Rect(350 + (lvl * this.barWidth),
					25 + (tmpMax - this.value[lvl]) * o, 300, 20),
					this.value[lvl].ToString());
			}


			// status values
			EditorGUILayout.BeginVertical(GUILayout.Width(325));

			EditorTool.BoldLabel("Level Values");
			this.scrollValue = EditorGUILayout.BeginScrollView(this.scrollValue);
			for(int i = 0; i < this.value.Length; i++)
			{
				EditorTool.Field("Level " + (i + this.minLevel).ToString(), ref this.value[i],
					"Set the status value for each level.", "", null, null);
				if(this.value[i] < this.minValue)
				{
					this.value[i] = this.minValue;
				}
				else if(this.value[i] > this.maxValue)
				{
					this.value[i] = this.maxValue;
				}
			}
			EditorGUILayout.EndScrollView();
			EditorGUILayout.EndVertical();

			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();

			EditorGUILayout.EndScrollView();

			// ok/cancel buttons
			EditorGUILayout.BeginHorizontal();
			if(EditorTool.ShowButton(EditorContent.Instance.CancelContent,
				"Cancel the changes made to this status value development.", "", EditorTool.W_EXPAND))
			{
				close = true;
			}
			if(EditorTool.ShowButton(EditorContent.Instance.ConfirmContent,
				"Confirm the changes made to this status value development.", "", EditorTool.W_EXPAND))
			{
				System.Array.Copy(this.value, this.oldValue, this.value.Length);
				close = true;
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.EndVertical();

			return close;
		}

		protected virtual void GenerateCurve()
		{
			if(this.useCurve)
			{
				for(int i = 0; i < this.value.Length; i++)
				{
					this.value[i] = (int)this.animationCurve.Evaluate(i + this.minLevel);
					if(this.value[i] < this.minValue)
					{
						this.value[i] = this.minValue;
					}
					else if(this.value[i] > this.maxValue)
					{
						this.value[i] = this.maxValue;
					}
				}
			}
			else
			{
				for(int i = 1; i < this.point.Length; i++)
				{
					int range = this.point[i].level - this.point[i - 1].level;
					Interpolation.FloatInstance interpolate = this.point[i].interpolation.CreateFloat(this.point[i - 1].value, this.point[i].value, range);
					this.value[this.point[i - 1].level - this.minLevel] = (int)interpolate.Tick(0);
					for(int j = 1; j <= range; j++)
					{
						this.value[j + this.point[i - 1].level - this.minLevel] = (int)interpolate.Tick(1);
					}

					this.value[0] = this.point[0].value;
					this.value[this.value.Length - 1] = this.point[this.point.Length - 1].value;
				}
			}
		}


		/*
		============================================================================
		Settings
		============================================================================
		*/
		protected class LevelPoint : BaseData
		{
			[EditorHelp("Level", "Set the level of this curve point.")]
			[EditorLimit(1, false)]
			public int level = 1;

			[EditorHelp("Value", "Set the value of this curve point.\n" +
				"The value will be set at the curve point level and used to interpolate from the last and to the next value.")]
			public int value = 0;

			[EditorHelp("Interpolation", "The interpolation used for the curve generation.", "")]
			public Interpolation interpolation = new Interpolation();

			public LevelPoint()
			{

			}
		}
	}
}

