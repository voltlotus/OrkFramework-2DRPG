﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CursorSettingsTab : ORKBaseEditorTab
	{
		public CursorSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Cursor Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up cursor changes."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/cursor-settings/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.CursorSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.CursorSettings; }
		}
	}
}
