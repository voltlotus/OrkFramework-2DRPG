
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CombatantSelectionsTab : ORKGenericAssetListTab<CombatantSelectionAsset, CombatantSelection>
	{
		public CombatantSelectionsTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			base.DefaultSetup();
			if(Maki.Data.ProjectAsset.IsEmpty &&
				this.assetList.AssetExists(0))
			{
				ORK.CombatantSelections.menuUser.Source.EditorAsset = this.assetList.Assets[0];
				ORK.CombatantSelections.abilityTarget.Source.EditorAsset = this.assetList.Assets[0];
				ORK.CombatantSelections.itemTarget.Source.EditorAsset = this.assetList.Assets[0];
				ORK.CombatantSelections.equipTarget.Source.EditorAsset = this.assetList.Assets[0];
				ORK.CombatantSelections.giveTarget.Source.EditorAsset = this.assetList.Assets[0];
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Combatant Selections"; }
		}

		public override string HelpText
		{
			get
			{
				return "Combatant selections are used by menu screens to select combatants, e.g. when opening a menu or using an item.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/combatant-selections/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up the default combatant selections.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.CombatantSelections; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.CombatantSelections;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
