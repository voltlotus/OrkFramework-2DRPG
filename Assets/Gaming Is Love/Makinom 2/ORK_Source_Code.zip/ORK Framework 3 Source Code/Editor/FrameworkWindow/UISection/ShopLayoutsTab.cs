
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ShopLayoutsTab : ORKGenericAssetListTab<ShopLayoutAsset, ShopLayout>
	{
		public ShopLayoutsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Shop Layouts"; }
		}

		public override string HelpText
		{
			get
			{
				return "Shop layouts are used by shops to define their look.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/shops/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding shop layouts.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.ShopLayouts; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.ShopLayouts;
				}
				return base.DisplayedSettings;
			}
		}
	}
}

