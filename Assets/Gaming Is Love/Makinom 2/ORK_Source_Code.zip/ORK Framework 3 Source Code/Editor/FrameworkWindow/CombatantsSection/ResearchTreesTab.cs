﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Conditions;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ResearchTreesTab : ORKGenericAssetListTab<ResearchTreeAsset, ResearchTreeSetting>
	{
		public ResearchTreesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ResearchTrees.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.ResearchTrees.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Research Trees"; }
		}

		public override string HelpText
		{
			get
			{
				return "Research trees are used by combatants to learn new abilities, change status values, get new quests and many other things.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/research-trees/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<ResearchTypeAsset, ResearchType>(
							new string[] { "Research Type", "Filter the research tree list by research type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				ResearchType type = this.Filter.assetFilterSelection[0].Selection as ResearchType;
				return this.assetList.Assets[index].Settings.IsType(type, false);
			}
			return true;
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:name")
			{

				EditorGUILayout.HelpBox("<name> = original name",
					 MessageType.Info, true);
			}
			else if(info == "textcodes:shortname")
			{
				EditorGUILayout.HelpBox("<shortname> = original short name",
					 MessageType.Info, true);
			}
			else if(info == "textcodes:description")
			{
				EditorGUILayout.HelpBox("<description> = original description",
					 MessageType.Info, true);
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void AutomationRemoveCallback(int arrayIndex, string info)
		{
			if(info == "researchitem:removed")
			{
				if(this.assetList.AssetExists(this.index))
				{
					ResearchTreeAsset asset = this.assetList.Assets[this.index];
					EditorDataHandler.Instance.SubDataRemoved(asset.GetType(), asset, arrayIndex);
				}
			}
			else
			{
				base.AutomationRemoveCallback(arrayIndex, info);
			}
		}

		public override void InstanceCallback(string info, object instance)
		{
			if(info == "button:addpreviouscondition")
			{
				if(instance is ResearchItemSetting)
				{
					ResearchTreeSetting tree = this.CurrentSettings;
					if(tree != null)
					{
						ResearchItemSetting item = (ResearchItemSetting)instance;
						for(int i = 0; i < tree.item.Length; i++)
						{
							if(tree.item[i] == item)
							{
								if(EditorTool.Button(new GUIContent("Add Previous Item Completed", EditorContent.Instance.AddIcon),
									"Adds a status conditions to check if the previous research item has been completed.\n" +
									"Added to the first research item (index 0) will check the item itself.", ""))
								{
									ResearchItemStatusConditionType researchItem = new ResearchItemStatusConditionType();
									researchItem.researchTree.Source.EditorAsset = this.assetList.Assets[this.index];
									researchItem.researchItem = i > 0 ? i - 1 : i;
									researchItem.researchItemState = ResearchItemState.Complete;

									this.AddCondition(item, researchItem);
								}
								if(EditorTool.Button(new GUIContent("Add Previous Item Researched", EditorContent.Instance.AddIcon),
									"Adds a status conditions to check if the previous research item has been researched at least once.\n" +
									"Added to the first research item (index 0) will check the item itself.", ""))
								{
									ResearchItemStatusConditionType researchItem = new ResearchItemStatusConditionType();
									researchItem.researchTree.Source.EditorAsset = this.assetList.Assets[this.index];
									researchItem.researchItem = i > 0 ? i - 1 : i;
									researchItem.checkResearchCount = true;
									researchItem.check.type = ValueCheckType.IsGreaterEqual;
									researchItem.check.value = new FloatValue<GameObjectSelection>(1);

									this.AddCondition(item, researchItem);
								}
								EditorGUILayout.Separator();
								break;
							}
						}
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}

		private void AddCondition(ResearchItemSetting item, ResearchItemStatusConditionType researchItem)
		{
			// status
			StatusCondition status = new StatusCondition();
			status.status = new StatusConditionSelection();
			status.status.settings = researchItem;
			status.status.type = researchItem.GetType().ToString();

			// combatant status
			CombatantStatusGeneralCondition<GameObjectSelection> combatantStatus = new CombatantStatusGeneralCondition<GameObjectSelection>();
			ArrayHelper.Add(ref combatantStatus.conditions.condition, status);

			// general condition
			GeneralCondition<GameObjectSelection> generalCondition = new GeneralCondition<GameObjectSelection>();
			generalCondition.settings = combatantStatus;
			generalCondition.type = generalCondition.settings.GetGenericTypeName();

			// add
			if(!item.learnConditions.useConditions ||
				item.learnConditions.conditions == null)
			{
				item.learnConditions.useConditions = true;
				item.learnConditions.conditions = new GeneralConditionSetting<GameObjectSelection>();
			}
			ArrayHelper.Add(ref item.learnConditions.conditions.condition, generalCondition);
		}
	}
}
