﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleSystemsTab : ORKGenericAssetListTab<BattleSystemAsset, BattleSystem>
	{
		public BattleSystemsTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(BattleSystemsTab.CreateAsset("Turn Based", typeof(TurnBasedBattleSystem), true));
				this.assetList.Add(BattleSystemsTab.CreateAsset("Active Time", typeof(ActiveTimeBattleSystem), true));
				this.assetList.Add(BattleSystemsTab.CreateAsset("Real Time", typeof(RealTimeBattleSystem), false));
				this.assetList.Add(BattleSystemsTab.CreateAsset("Phase", typeof(PhaseBattleSystem), true));

				ORK.BattleSettings.defaultBattleSystem.Source.EditorAsset = this.assetList.Assets[0];
				ORK.BattleSettings.realTimeBattleAreaSystem.Source.EditorAsset = this.assetList.Assets[2];

				GenericAssetList<BattleMenuAsset> battleMenus = EditorDataHandler.Instance.GetAssets<BattleMenuAsset>();
				if(battleMenus.Count > 0)
				{
					ORK.BattleSettings.defaultBattleMenu.Source.EditorAsset = battleMenus.Assets[0];
				}
			}
		}

		private static BattleSystemAsset CreateAsset(string name, System.Type battleSystemType, bool blockControls)
		{
			BattleSystemAsset asset = ScriptableObject.CreateInstance<BattleSystemAsset>();
			asset.Settings = new BattleSystem(name, battleSystemType, blockControls);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string Name
		{
			get { return "Battle System"; }
		}

		public override string HelpText
		{
			get
			{
				return "Define how the battle system will work.\n" +
					"You can set up different battle system types: turn based, active time, real time or phase.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/battle-systems/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings for the battle system.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.BattleSettings;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
