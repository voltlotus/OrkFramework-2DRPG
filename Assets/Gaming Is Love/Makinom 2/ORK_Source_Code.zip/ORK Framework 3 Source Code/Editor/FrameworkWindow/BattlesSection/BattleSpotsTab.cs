
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleSpotsTab : ORKBaseEditorTab
	{
		public BattleSpotsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Spots"; }
		}

		public override string HelpText
		{
			get { return "Set up the default battle positions for player, ally and enemy combatants."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-spots/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleSpots; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.BattleSpots; }
		}
	}
}
