﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ActionCombosTab : ORKGenericAssetListTab<ActionComboAsset, ActionComboSettings>
	{
		public ActionCombosTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ActionCombos.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Action Combos"; }
		}

		public override string HelpText
		{
			get
			{
				return "Action combos are used to replace actions in a sequence of actions.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/action-combos/"; }
		}
	}
}
