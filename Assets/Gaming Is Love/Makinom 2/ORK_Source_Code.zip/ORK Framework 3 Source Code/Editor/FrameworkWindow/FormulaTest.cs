﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;
using System.Text;

namespace GamingIsLove.ORKFramework.Editor
{
	public class FormulaTest : BaseData
	{
		[EditorHelp("Initial Value", "The initial value used when calculating the formula.")]
		public float initialValue = 0;

		[EditorFoldout("User", "Select the user of the formula.")]
		[EditorEndFoldout]
		public CombatantSetup user = new CombatantSetup();

		[EditorFoldout("Target", "Select the target of the formula.")]
		[EditorEndFoldout]
		public CombatantSetup target = new CombatantSetup();


		// selected data
		public enum ActionType { None, Ability, Item }

		[EditorHelp("Action Type", "Select what will be passed on to the formula as selected data with the 'action' selected key:\n" +
			"- None: Nothing.\n" +
			"- Ability: An ability.\n" +
			"- Item: An item, equipment, currency, etc.", "")]
		[EditorFoldout("Selected Data", "Select the selected data that will be stored in the 'action' selected key when using the formula.")]
		public ActionType type = ActionType.None;

		// ability
		[EditorHelp("Ability", "Select the ability that will be used.", "")]
		[EditorCondition("type", ActionType.Ability)]
		public AssetSelection<AbilityAsset> ability = new AssetSelection<AbilityAsset>();

		[EditorHelp("Ability Level", "Define the ability level that will be used.", "")]
		[EditorEndCondition]
		[EditorLimit(1, false)]
		public int abilityLevel = 1;

		// item
		[EditorEndFoldout]
		[EditorCondition("type", ActionType.Item)]
		[EditorEndCondition]
		public ItemGain<GameObjectSelection> item = new ItemGain<GameObjectSelection>();

		public FormulaTest()
		{
			this.user.combatant.Source.EditorAsset = ORK.Combatants.GetAsset(0);
			this.target.combatant.Source.EditorAsset = ORK.Combatants.GetAsset(0);
		}

		public virtual void Calculate(FormulaAsset formula, ref string singleResult, Dictionary<string, string> result, List<string> userKeys, List<string> targetKeys)
		{
			singleResult = "";
			result.Clear();
			userKeys.Clear();
			targetKeys.Clear();

			if(this.user.useLevelRange ||
				this.target.useLevelRange)
			{
				SelectedDataHandler selectedData = this.CreateSelectedData();

				if(this.user.useLevelRange)
				{
					if(this.target.useLevelRange)
					{
						for(int i = this.user.minLevel; i <= this.user.maxLevel; i++)
						{
							Combatant tmpUser = this.user.Create(i);
							string userKey = "User LVL " + i;
							userKeys.Add(userKey);

							for(int j = this.target.minLevel; j <= this.target.maxLevel; j++)
							{
								string targetKey = "Target LVL " + j;
								if(!targetKeys.Contains(targetKey))
								{
									targetKeys.Add(targetKey);
								}

								result.Add(userKey + ", " + targetKey,
									formula.Settings.Calculate(new FormulaCall(
										this.initialValue, tmpUser, this.target.Create(j),
										null, selectedData, 0)).ToString());
							}
						}
					}
					else
					{
						Combatant tmpTarget = this.target.Create();
						string targetKey = "Target LVL " + tmpTarget.Status.Level;
						targetKeys.Add(targetKey);

						for(int i = this.user.minLevel; i <= this.user.maxLevel; i++)
						{
							string userKey = "User LVL " + i;
							userKeys.Add(userKey);

							result.Add(userKey + ", " + targetKey,
								formula.Settings.Calculate(new FormulaCall(
									this.initialValue, this.user.Create(i), tmpTarget,
									null, selectedData, 0)).ToString());
						}
					}
				}
				else
				{
					Combatant tmpUser = this.user.Create();
					string userKey = "User LVL " + tmpUser.Status.Level;
					userKeys.Add(userKey);

					for(int j = this.target.minLevel; j <= this.target.maxLevel; j++)
					{
						string targetKey = "Target LVL " + j;
						targetKeys.Add(targetKey);

						result.Add(userKey + ", " + targetKey,
							formula.Settings.Calculate(new FormulaCall(
								this.initialValue, tmpUser, this.target.Create(j),
								null, selectedData, 0)).ToString());
					}
				}
			}
			else
			{
				singleResult = formula.Settings.Calculate(new FormulaCall(
					this.initialValue, this.user.Create(), this.target.Create(),
					null, this.CreateSelectedData(), 0)).ToString();
			}
		}

		public virtual SelectedDataHandler CreateSelectedData()
		{
			if(ActionType.Ability == this.type)
			{
				if(this.ability.StoredAsset != null)
				{
					return new AbilityShortcut(this.ability.StoredAsset.Settings,
						this.abilityLevel, AbilityState.None).GetSelectedData();
				}
			}
			else if(ActionType.Item == type)
			{
				return SelectedDataHelper.CreateSelectedData(SelectedDataHelper.Action, 
					this.item.CreateShortcut(this.item.quantityValue.NeedsCall ? new DataCall() : null));
			}
			return null;
		}

		public class CombatantSetup : BaseData
		{
			[EditorHelp("Combatant", "Select the combatant that will be used.")]
			public AssetSelection<CombatantAsset> combatant = new AssetSelection<CombatantAsset>();

			[EditorHelp("Use Level Range", "Check the formula for a range of levels, listing each result.\n" +
				"Checking level range will use the same level for base and class level.")]
			[EditorSeparator]
			public bool useLevelRange = false;

			[EditorHelp("Minimum Level", "Define the minimum level that will be used.", "")]
			[EditorLimit(1, false)]
			[EditorCondition("useLevelRange", true)]
			public int minLevel = 1;

			[EditorHelp("Maximum Level", "Define the maximum level that will be used.", "")]
			[EditorLimit("minLevel", false)]
			public int maxLevel = 99;


			// level
			[EditorHelp("Use Start Level", "Use the combatant's start level.\n" +
				"If disabled, define a level that will be used.")]
			[EditorSeparator]
			[EditorElseCondition]
			public bool useStartLevel = true;

			[EditorHelp("Level", "Define the level that will be used.", "")]
			[EditorLimit(1)]
			[EditorCondition("useStartLevel", false)]
			[EditorEndCondition]
			public int level = 1;


			// classlevel
			[EditorHelp("Use Start Class Level", "Use the combatant's start class level.\n" +
				"If disabled, define a class level that will be used.")]
			[EditorSeparator]
			public bool useStartClassLevel = true;

			[EditorHelp("Class Level", "Define the class level that will be used.", "")]
			[EditorLimit(1)]
			[EditorCondition("useStartClassLevel", false)]
			[EditorEndCondition(2)]
			public int classLevel = 1;

			public CombatantSetup()
			{

			}

			public virtual Combatant Create()
			{
				if(this.combatant.StoredAsset != null)
				{
					Combatant combatant = ORK.Access.Combatant.CreateInstance(
						this.combatant.StoredAsset.Settings, new Group(), false, false,
						this.useStartLevel ? this.combatant.StoredAsset.Settings.startLevel : this.level,
						this.useStartClassLevel ? this.combatant.StoredAsset.Settings.startClassLevel : this.classLevel,
						this.combatant.StoredAsset.Settings.GetStartClass(), false,
						true, true, true, true, true);
					return combatant;
				}
				return null;
			}

			public virtual Combatant Create(int level)
			{
				if(this.combatant.StoredAsset != null)
				{
					Combatant combatant = ORK.Access.Combatant.CreateInstance(
						this.combatant.StoredAsset.Settings, new Group(), false, false, level, level,
						this.combatant.StoredAsset.Settings.GetStartClass(), false,
						true, true, true, true, true);
					return combatant;
				}
				return null;
			}
		}
	}
}
