﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class EditorClipboard
	{
		public DataObject data;

		public System.Type type;

		public EditorClipboard(DataObject data, System.Type type)
		{
			this.data = data;
			this.type = type;
		}
	}
}
