
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Reflection;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Formulas;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Audio;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public static class EditorAutomation
	{
		public static Dictionary<object, List<object>> debugValues;

		public static void ShowDebug(IBaseData instance)
		{
			if(debugValues != null)
			{
				List<object> list = null;
				if(debugValues.TryGetValue(instance, out list))
				{
					if(list.Count > 0)
					{
						string debug = "";
						if(list.Count == 1)
						{
							debug += "Debug Value: " + list[0];
						}
						else
						{
							debug = "Debug Values:";
							for(int i = 0; i < list.Count; i++)
							{
								debug += "\n" + list[i];
							}
						}
						EditorGUILayout.BeginHorizontal();
						if(EditorTool.Button(EditorContent.Instance.CopyToClipboardContent, EditorTool.WIDTH_30))
						{
							EditorGUIUtility.systemCopyBuffer = debug;
						}
						EditorGUILayout.HelpBox(debug, MessageType.None);
						EditorGUILayout.EndHorizontal();
					}
				}
			}
		}


		/*
		============================================================================
		Search functions
		============================================================================
		*/
		private static Color PreSearchColor = Color.white;
		private static int InSearchMark = 0;

		public static bool IsSearchMarked
		{
			get { return InSearchMark > 0; }
		}

		public static void ClearSearchMark()
		{
			InSearchMark = 0;
			InCopiedMark = 0;
		}

		public static void MarkSearch(bool mark, BaseEditor baseEditor, bool markFoldout)
		{
			if(markFoldout)
			{
				baseEditor.SearchMarkFoldout();
			}
			if(mark)
			{
				if(InSearchMark == 0)
				{
					if(EditorGUIUtility.isProSkin)
					{
						PreSearchColor = GUI.contentColor;
						GUI.contentColor = Maki.EditorSettings.searchSettingHighlightColor;
					}
					else
					{
						PreSearchColor = GUI.backgroundColor;
						GUI.backgroundColor = Maki.EditorSettings.searchSettingHighlightColor;
					}
				}
				InSearchMark++;
			}
			else
			{
				InSearchMark--;
				if(InSearchMark == 0)
				{
					if(EditorGUIUtility.isProSkin)
					{
						GUI.contentColor = PreSearchColor;
					}
					else
					{
						GUI.backgroundColor = PreSearchColor;
					}
				}
				if(Event.current.type == EventType.Repaint)
				{
					baseEditor.AddSearchScrollPosition(GUILayoutUtility.GetLastRect().y);
				}
			}
		}


		/*
		============================================================================
		Copy/paste settings functions
		============================================================================
		*/
		private static DataObject ClipboardData = null;
		private static IBaseData ClipboardInstance = null;
		private static Color PreCopiedColor = Color.white;
		private static int InCopiedMark = 0;

		public static void StartContextClick(BaseEditor baseEditor, IBaseData instance, bool beginVertical)
		{
			if(Maki.EditorSettings.useCopyContextMenu)
			{
				if(ClipboardData != null &&
					ClipboardInstance == instance)
				{
					if(InCopiedMark == 0)
					{
						if(EditorGUIUtility.isProSkin)
						{
							PreCopiedColor = GUI.contentColor;
							GUI.contentColor = Maki.EditorSettings.copiedSettingHighlightColor;
						}
						else
						{
							PreCopiedColor = GUI.backgroundColor;
							GUI.backgroundColor = Maki.EditorSettings.copiedSettingHighlightColor;
						}
					}
					InCopiedMark++;
				}
				if(beginVertical)
				{
					EditorGUILayout.BeginVertical();
				}
			}
		}

		public static void EndContextClick(BaseEditor baseEditor, IBaseData instance, bool endVertical)
		{
			if(Maki.EditorSettings.useCopyContextMenu)
			{
				if(endVertical)
				{
					EditorGUILayout.EndVertical();
				}
				if(ClipboardData != null &&
					ClipboardInstance == instance)
				{
					InCopiedMark--;
					if(InCopiedMark == 0)
					{
						if(EditorGUIUtility.isProSkin)
						{
							GUI.contentColor = PreCopiedColor;
						}
						else
						{
							GUI.backgroundColor = PreCopiedColor;
						}
					}
				}
				try
				{
					if(Event.current.type == EventType.ContextClick &&
						GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition))
					{
						Event.current.Use();
						GenericMenu contextMenu = new GenericMenu();
						contextMenu.AddItem(new GUIContent("Copy to Clipboard", "Copy the settings to the clipboard."),
							false, CopyToClipboard, instance);
						if(ClipboardData != null)
						{
							if(ClipboardInstance.GetType().IsAssignableFrom(instance.GetType()) ||
								instance.GetType().IsAssignableFrom(ClipboardInstance.GetType()))
							{
								contextMenu.AddItem(new GUIContent("Paste from Clipboard", "Paste the settings from the clipboard."),
									false, PasteFromClipboard, instance);
							}
							else
							{
								contextMenu.AddDisabledItem(new GUIContent("Paste Incompatible", "Copied and current data are not compatible."));
							}
							contextMenu.AddItem(new GUIContent("Clear Clipboard", "Remove the copied data from the clipboard."),
								false, ClearClipboard);
						}
						contextMenu.ShowAsContext();
					}
				}
				catch(System.Exception ex)
				{
					// silent
				}
			}
		}

		private static void CopyToClipboard(object instance)
		{
			if(instance is IBaseData)
			{
				ClipboardInstance = (IBaseData)instance;
				ClipboardData = ClipboardInstance.GetData();
			}
		}

		private static void PasteFromClipboard(object instance)
		{
			if(instance is IBaseData &&
				ClipboardData != null)
			{
				((IBaseData)instance).SetData(ClipboardData);
			}
		}

		private static void ClearClipboard()
		{
			ClipboardInstance = null;
			ClipboardData = null;
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public static void Automate(IBaseData instance, BaseEditor baseEditor)
		{
			if(instance is BaseLanguageData)
			{
				EditorAutomation.StartContextClick(baseEditor, instance, false);
				baseEditor.BeginFoldout("Content Information", "Set the name, description and icon.", "", true);
				EditorAutomation.Automate("languageContent", instance, baseEditor, true);
				EditorAutomation.Automate("customContent", instance, baseEditor, true);
				EditorAutomation.Automate("editorName", instance, baseEditor, true);
				baseEditor.EndFoldout();
				EditorAutomation.EndContextClick(baseEditor, instance, false);
			}

			FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());
			Dictionary<string, AttributeHelper> list = EditorAttributes.GetAttributes(instance.GetType());
			AttributeHelper helper;

			EditorAutomation.StartContextClick(baseEditor, instance, true);
			for(int i = 0; i < field.Length; i++)
			{
				if(list != null &&
					list.TryGetValue(field[i].Name, out helper))
				{
					EditorAutomation.Automate(field[i], instance, baseEditor, false, helper);
				}
				else
				{
					EditorAutomation.Automate(field[i], instance, baseEditor, false, null);
				}
			}
			EditorAutomation.EndContextClick(baseEditor, instance, true);
		}

		public static void AutomateNoContextClick(IBaseData instance, BaseEditor baseEditor)
		{
			if(instance is BaseLanguageData)
			{
				baseEditor.BeginFoldout("Content Information", "Set the name, description and icon.", "", true);
				EditorAutomation.Automate("languageContent", instance, baseEditor, true);
				EditorAutomation.Automate("customContent", instance, baseEditor, true);
				EditorAutomation.Automate("editorName", instance, baseEditor, true);
				baseEditor.EndFoldout();
			}

			FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());
			Dictionary<string, AttributeHelper> list = EditorAttributes.GetAttributes(instance.GetType());
			AttributeHelper helper;

			for(int i = 0; i < field.Length; i++)
			{
				if(list != null &&
					list.TryGetValue(field[i].Name, out helper))
				{
					EditorAutomation.Automate(field[i], instance, baseEditor, false, helper);
				}
				else
				{
					EditorAutomation.Automate(field[i], instance, baseEditor, false, null);
				}
			}
		}

		public static void Automate(IBaseData instance, BaseEditor baseEditor, bool ignoreHide)
		{
			if(instance is BaseLanguageData)
			{
				EditorAutomation.StartContextClick(baseEditor, instance, false);
				baseEditor.BeginFoldout("Content Information", "Set the name, description and icon.", "", true);
				EditorAutomation.Automate("editorName", instance, baseEditor, true);
				EditorAutomation.Automate("customContent", instance, baseEditor, true);
				EditorAutomation.Automate("languageContent", instance, baseEditor, true);
				baseEditor.EndFoldout();
				EditorAutomation.EndContextClick(baseEditor, instance, false);
			}

			FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());
			Dictionary<string, AttributeHelper> list = EditorAttributes.GetAttributes(instance.GetType());
			AttributeHelper helper;

			EditorAutomation.StartContextClick(baseEditor, instance, true);
			for(int i = 0; i < field.Length; i++)
			{
				if(list != null &&
					list.TryGetValue(field[i].Name, out helper))
				{
					EditorAutomation.Automate(field[i], instance, baseEditor, ignoreHide, helper);
				}
				else
				{
					EditorAutomation.Automate(field[i], instance, baseEditor, ignoreHide, null);
				}
			}
			EditorAutomation.EndContextClick(baseEditor, instance, true);
		}

		public static void Automate(string name, IBaseData instance, BaseEditor baseEditor)
		{
			EditorAutomation.Automate(name, instance, baseEditor, false);
		}

		public static void Automate(string name, IBaseData instance, BaseEditor baseEditor, bool ignoreHide)
		{
			FieldInfo fieldInfo = instance.GetType().GetField(name);
			if(fieldInfo != null)
			{
				EditorAutomation.Automate(fieldInfo, instance, baseEditor, ignoreHide, null);
			}
		}

		public static void Automate(FieldInfo fieldInfo, IBaseData instance, BaseEditor baseEditor)
		{
			EditorAutomation.Automate(fieldInfo, instance, baseEditor, false, null);
		}

		public static void Automate(FieldInfo fieldInfo, IBaseData instance, BaseEditor baseEditor, bool ignoreHide, AttributeHelper attributes)
		{
			if(attributes == null)
			{
				attributes = EditorAttributes.GetAttribute(fieldInfo, instance.GetType());
			}

			// conditions
			attributes.StartConditions(instance, baseEditor);

			IBaseData tmpInstance = attributes.foldout != null && attributes.endFoldout != null &&
					typeof(IBaseData).IsAssignableFrom(fieldInfo.FieldType) ?
				fieldInfo.GetValue(instance) as IBaseData : null;

			// begin foldout
			bool blockFoldout = false;
			attributes.BeginFoldout(tmpInstance, baseEditor, ignoreHide, ref blockFoldout);

			if(baseEditor.checkGroupStack.Count == 0 || baseEditor.checkGroupStack.Peek())
			{
				// auto init
				attributes.AutoInit(instance, fieldInfo, true);
				attributes.Callback(instance, baseEditor, EditorCallbackType.InstanceBefore);

				// show field if not hidden or folded
				if((attributes.hide == 0 || (ignoreHide && attributes.hide == 1)) &&
					baseEditor.GetFoldout(false))
				{
					bool closeSearch = false;
					if(!EditorAutomation.IsSearchMarked &&
						baseEditor.CheckSearch(attributes.help.content.text))
					{
						EditorAutomation.MarkSearch(true, baseEditor, true);
						closeSearch = true;
					}

					attributes.BeforeField(instance, baseEditor);

					EditorAutomation.Field(fieldInfo, attributes, instance, baseEditor, ignoreHide);

					attributes.AfterField(instance, baseEditor);

					if(closeSearch)
					{
						EditorAutomation.MarkSearch(false, baseEditor, false);
					}
				}

				attributes.Callback(instance, baseEditor, EditorCallbackType.InstanceAfter);
			}
			else
			{
				attributes.AutoInit(instance, fieldInfo, false);
			}

			attributes.EndConditions(baseEditor);
			attributes.EndFoldout(tmpInstance, baseEditor, blockFoldout);
		}

		public static bool CheckConditions(IBaseData instance, string[] checkField, object[] fieldValue, Needed needed)
		{
			for(int i = 0; i < checkField.Length; i++)
			{
				object value = null;
				if(ReflectionTypeHandler.GetFieldValue(out value, instance, checkField[i]))
				{
					if(value == null ?
						fieldValue[i] == null :
						value.Equals(fieldValue[i]))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				else if(Needed.All == needed)
				{
					return false;
				}
			}

			return Needed.All == needed;
		}

		public static bool CheckConditions(IBaseData instance, string[] checkField, object[] fieldValue, bool[] fieldCheck, Needed needed)
		{
			for(int i = 0; i < checkField.Length; i++)
			{
				object value = null;
				if(ReflectionTypeHandler.GetFieldValue(out value, instance, checkField[i]))
				{
					if(fieldCheck[i] == (value == null ?
							fieldValue[i] == null :
							value.Equals(fieldValue[i])))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				else if(Needed.All == needed)
				{
					return false;
				}
			}

			return Needed.All == needed;
		}


		/*
		============================================================================
		Field processing
		============================================================================
		*/
		public static void Field(FieldInfo fieldInfo, AttributeHelper attributes, IBaseData instance, BaseEditor baseEditor, bool ignoreHide)
		{
			// settings highlight
			if(attributes.highlightSettings >= 0)
			{
				EditorTool.BeginSettingsHighlight(attributes.highlightSettings);
				object value = fieldInfo.GetValue(instance);
				try
				{
					if(EditorAutomation.Value(ref value, fieldInfo, fieldInfo.FieldType, attributes, attributes.help, instance, baseEditor, ignoreHide))
					{
						fieldInfo.SetValue(instance, value);
					}
				}
				catch(ExitGUIException ex)
				{
					throw ex;
				}
				catch(System.Exception ex)
				{
					// silent
					/*Debug.LogWarning("Something went wrong while displaying a setting: " +
						(attributes != null && attributes.help != null && attributes.help.content != null ?
							attributes.help.content.text : fieldInfo.Name) +
						"\n\n" + ex.Message + "\n" + ex.StackTrace);*/
				}
				EditorTool.EndSettingsHighlight();
			}
			else
			{
				object value = fieldInfo.GetValue(instance);
				try
				{
					if(EditorAutomation.Value(ref value, fieldInfo, fieldInfo.FieldType, attributes, attributes.help, instance, baseEditor, ignoreHide))
					{
						fieldInfo.SetValue(instance, value);
					}
				}
				catch(ExitGUIException ex)
				{
					throw ex;
				}
				catch(System.Exception ex)
				{
					// silent
					/*Debug.LogWarning("Something went wrong while displaying a setting: " +
						(attributes != null && attributes.help != null && attributes.help.content != null ?
							attributes.help.content.text : fieldInfo.Name) +
						"\n\n" + ex.Message + "\n" + ex.StackTrace);*/
				}
			}
		}

		public static bool Value(ref object value, FieldInfo fieldInfo, System.Type type,
			AttributeHelper attributes, EditorHelpAttribute help, IBaseData instance, BaseEditor baseEditor, bool ignoreHide)
		{
			// base types
			if(value is int)
			{
				int tmp = (int)value;
				if(attributes.info.isTabPopup)
				{
					EditorTool.Popup(help.content, ref tmp,
						baseEditor.GetPopupList(attributes.info.tabPopupID), null,
						help.info, attributes, baseEditor);
				}
				else if(attributes.info.isLayerField)
				{
					EditorTool.LayerField(help.content, ref tmp, help.info, attributes, baseEditor);
				}
				else if(attributes.info.isAssetSubDataPopup)
				{
					string[] names = null;
					object fieldValue = null;
					if(ReflectionTypeHandler.GetFieldValue(out fieldValue, instance, attributes.info.assetSubDataField))
					{
						if(fieldValue is AssetSource)
						{
							AssetSource asset = (AssetSource)fieldValue;
							if(asset.Source.EditorAsset != null &&
								asset.Source.EditorAsset is ISubData)
							{
								names = ((ISubData)asset.Source.EditorAsset).GetEditorSubDataNames();
							}
						}
					}
					if(names == null)
					{
						names = new string[0];
					}
					EditorTool.Popup(help.content, ref tmp, names, null, help.info, attributes, baseEditor);
				}
				else
				{
					if(attributes.limit != null)
					{
						if(attributes.limit.isSlider)
						{
							int min = (int)attributes.limit.minimum;
							int max = (int)attributes.limit.maximum;

							if(attributes.limit.isLimitByField)
							{
								FieldInfo limitField = instance.GetType().GetField(attributes.limit.limitFieldName);
								if(limitField != null)
								{
									object limitValue = limitField.GetValue(instance);
									if(limitValue is int)
									{
										if(attributes.limit.fieldMaxLimit)
										{
											max = (int)limitValue;
										}
										else
										{
											min = (int)limitValue;
										}
									}
								}
							}

							EditorTool.IntSlider(help.content, ref tmp, min, max, help.info, attributes, baseEditor);
						}
						else
						{
							EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
							if(attributes.limit.isLimitByField)
							{
								FieldInfo limitField = instance.GetType().GetField(attributes.limit.limitFieldName);
								if(limitField != null)
								{
									object limitValue = limitField.GetValue(instance);
									if(limitValue is int)
									{
										if((!attributes.limit.fieldMaxLimit && tmp < (int)limitValue) ||
											(attributes.limit.fieldMaxLimit && tmp > (int)limitValue))
										{
											tmp = (int)limitValue;
										}
									}
								}
							}
							attributes.limit.Limit(ref tmp);
						}
					}
					else
					{
						EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
					}
				}
				value = tmp;
			}
			else if(value is float)
			{
				float tmp = (float)value;
				if(attributes.limit != null)
				{
					if(attributes.limit.isSlider)
					{
						float min = attributes.limit.minimum;
						float max = attributes.limit.maximum;

						if(attributes.limit.isLimitByField)
						{
							FieldInfo limitField = instance.GetType().GetField(attributes.limit.limitFieldName);
							if(limitField != null)
							{
								object limitValue = limitField.GetValue(instance);
								if(limitValue is float)
								{
									if(attributes.limit.fieldMaxLimit)
									{
										max = (float)limitValue;
									}
									else
									{
										min = (float)limitValue;
									}
								}
							}
						}

						EditorTool.Slider(help.content, ref tmp, min, max, help.info, attributes, baseEditor);
					}
					else
					{
						EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
						if(attributes.limit.isLimitByField)
						{
							FieldInfo limitField = instance.GetType().GetField(attributes.limit.limitFieldName);
							if(limitField != null)
							{
								object limitValue = limitField.GetValue(instance);
								if(limitValue is float)
								{
									if((!attributes.limit.fieldMaxLimit && tmp < (float)limitValue) ||
										(attributes.limit.fieldMaxLimit && tmp > (float)limitValue))
									{
										tmp = (float)limitValue;
									}
								}
							}
						}
						attributes.limit.Limit(ref tmp);
					}
				}
				else
				{
					EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				}
				value = tmp;
			}
			else if(value is bool)
			{
				bool tmp = (bool)value;
				if(attributes.info.isToggleButton)
				{
					EditorTool.ToggleButton(help.content, ref tmp, help.info);
				}
				else
				{
					EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				}
				value = tmp;
			}
			else if(value is string)
			{
				string tmp = (string)value;
				// reflection field
				if(attributes.reflection != null)
				{
					if(EditorReflectionFieldType.Class == attributes.reflection.type)
					{
						baseEditor.ReflectionField(help.content, ref tmp, help.info,
							attributes, "", EditorReflectionField.Type.Class, null);
					}
					else if(EditorReflectionFieldType.Enum == attributes.reflection.type)
					{
						baseEditor.ReflectionField(help.content, ref tmp, help.info,
							attributes, "", EditorReflectionField.Type.Enum, null);
					}
					else if(EditorReflectionFieldType.Function == attributes.reflection.type)
					{
						string className = "";
						FieldInfo reflectionField = instance.GetType().GetField(attributes.reflection.classFieldName);
						if(reflectionField != null)
						{
							object fieldValue = reflectionField.GetValue(instance);
							if(fieldValue is string)
							{
								className = (string)fieldValue;
							}
						}

						baseEditor.ReflectionField(help.content, ref tmp, help.info,
							attributes, className, EditorReflectionField.Type.Function, null);
					}
					else if(EditorReflectionFieldType.Field == attributes.reflection.type)
					{
						string className = "";
						FieldInfo reflectionField = instance.GetType().GetField(attributes.reflection.classFieldName);
						if(reflectionField != null)
						{
							object fieldValue = reflectionField.GetValue(instance);
							if(fieldValue is string)
							{
								className = (string)fieldValue;
							}
						}

						bool isProperty = false;
						if(attributes.reflection.propertyFieldName != "")
						{
							reflectionField = instance.GetType().GetField(attributes.reflection.propertyFieldName);
							if(reflectionField != null)
							{
								object fieldValue = reflectionField.GetValue(instance);
								if(fieldValue is bool)
								{
									isProperty = (bool)fieldValue;
								}
							}
						}

						baseEditor.ReflectionField(help.content, ref tmp, help.info,
							attributes, className, isProperty ?
								EditorReflectionField.Type.Property :
								EditorReflectionField.Type.Field,
							attributes.reflection.fieldType);
					}
				}
				// other
				else if(attributes.info.isVariableField)
				{
					baseEditor.VariableField(help.content, ref tmp, help.info, attributes);
				}
				else if(attributes.info.settingBaseType != null)
				{
					if(attributes.info.settingAutoSetup != "")
					{
						GUIContent tmpContent = new GUIContent(help.content);
						EditorSortedSettingInfo infos = EditorAttributes.GetSettingInfos(attributes.info.settingBaseType);
						tmpContent.tooltip += infos.infoHelpText;
						int index = infos.GetIndex(tmp);
						baseEditor.PopupSelectionField(tmpContent, index,
							infos.names, infos.descriptions, attributes.info.settingBaseType.FullName,
							help.info, attributes,
							delegate (int selectedIndex)
							{
								if(selectedIndex != index)
								{
									tmp = infos.GetValue(selectedIndex);
									fieldInfo.SetValue(instance, tmp);
									instance.EditorAutoSetup(attributes.info.settingAutoSetup);
									baseEditor.SettingChanged(instance, fieldInfo.Name, tmp);
									baseEditor.Repaint();
								}
							});
					}
					return false;
				}
				else
				{
					EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				}
				value = tmp;
			}
			else if(value is LayerMask)
			{
				LayerMask tmp = (LayerMask)value;
				EditorTool.LayerMaskField(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			// enums
			else if(value is System.Enum)
			{
				EditorSortedEnum sortedEnum = EditorAttributes.GetSortedEnum(value);
				int index = sortedEnum.GetIndex(value);
				baseEditor.PopupSelectionField(help.content, index, sortedEnum.names, null, value.GetType().FullName, help.info, attributes,
					delegate (int selectedIndex)
					{
						if(selectedIndex != index)
						{
							object newValue = sortedEnum.GetValue(selectedIndex);
							fieldInfo.SetValue(instance, newValue);
							baseEditor.SettingChanged(instance, fieldInfo.Name, newValue);
							baseEditor.Repaint();
						}
					});
				return false;
			}
			// special types
			else if(typeof(ICustomVisualization).IsAssignableFrom(type))
			{
				if(value != null)
				{
					// asset source
					if(typeof(AssetSource).IsAssignableFrom(type))
					{
						AssetSource tmp = (AssetSource)value;
						AssetSourceEditor.Edit(ref tmp, attributes, baseEditor,
							delegate (UnityEngine.Object newObject)
							{
								tmp.Source.EditorAsset = newObject;
								tmp.ResetStoredAsset();
								baseEditor.SettingChanged(instance, fieldInfo.Name, tmp);
								baseEditor.Repaint();
							});
						value = tmp;
					}
					// language
					else if(typeof(TextContent).IsAssignableFrom(type))
					{
						TextContent tmp = (TextContent)value;
						baseEditor.TextArea(help.content, ref tmp, help.info);
						value = tmp;
					}
					// axis bool
					else if(typeof(AxisBool) == type)
					{
						AxisBool tmp = (AxisBool)value;
						EditorTool.AxisBoolField(help.content, ref tmp, help.info);
						value = tmp;
					}
					// schematic selections
					else if(typeof(SchematicObjectSelection) == type)
					{
						SchematicObjectSelection tmp = (SchematicObjectSelection)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						string[] actors = baseEditor.GetPopupList(0);
						string[] prefabs = baseEditor.GetPopupList(2);
						List<string> list = new List<string>();
						list.AddRange(actors);
						list.AddRange(prefabs);
						list.Add("Player");
						list.Add("Machine Object");
						list.Add("Starting Object");
						list.Add("Camera");
						list.Add("Selected Data");
						list.Add("Selected Object");
						list.Add("Grid Root");
						list.Add("Grid Cell");

						int tmpIndex = -1;
						if(SchematicObjectType.Actor == tmp.type)
						{
							tmpIndex = actors.Length > 0 ? tmp.actorID : -1;
						}
						else if(SchematicObjectType.Prefab == tmp.type)
						{
							tmpIndex = prefabs.Length > 0 ? actors.Length + tmp.prefabID : -1;
						}
						else if(SchematicObjectType.Player == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length;
						}
						else if(SchematicObjectType.MachineObject == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 1;
						}
						else if(SchematicObjectType.StartingObject == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 2;
						}
						else if(SchematicObjectType.Camera == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 3;
						}
						else if(SchematicObjectType.SelectedData == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 4;
						}
						else if(SchematicObjectType.SelectedObject == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 5;
						}
						else if(SchematicObjectType.GridRoot == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 6;
						}
						else if(SchematicObjectType.GridCell == tmp.type)
						{
							tmpIndex = actors.Length + prefabs.Length + 7;
						}
						int tmpIndex2 = tmpIndex;

						Dictionary<string, AttributeHelper> attrList = EditorAttributes.GetAttributes(tmp.GetType());
						AttributeHelper helper;
						if(attrList != null &&
							attrList.TryGetValue("type", out helper))
						{
							help = helper.help;
						}

						EditorGUILayout.BeginHorizontal();
						EditorTool.Popup(help.content, ref tmpIndex, list.ToArray(), null,
							help.info, attributes, baseEditor);

						if(tmpIndex != tmpIndex2)
						{
							if(tmpIndex < actors.Length)
							{
								tmp.type = SchematicObjectType.Actor;
								tmp.actorID = tmpIndex;
							}
							else if(tmpIndex < actors.Length + prefabs.Length)
							{
								tmp.type = SchematicObjectType.Prefab;
								tmp.prefabID = tmpIndex - actors.Length;
							}
							else
							{
								tmpIndex -= (actors.Length + prefabs.Length);
								if(tmpIndex == 0)
								{
									tmp.type = SchematicObjectType.Player;
								}
								else if(tmpIndex == 1)
								{
									tmp.type = SchematicObjectType.MachineObject;
								}
								else if(tmpIndex == 2)
								{
									tmp.type = SchematicObjectType.StartingObject;
								}
								else if(tmpIndex == 3)
								{
									tmp.type = SchematicObjectType.Camera;
								}
								else if(tmpIndex == 4)
								{
									tmp.type = SchematicObjectType.SelectedData;
								}
								else if(tmpIndex == 5)
								{
									tmp.type = SchematicObjectType.SelectedObject;
								}
								else if(tmpIndex == 6)
								{
									tmp.type = SchematicObjectType.GridRoot;
								}
								else if(tmpIndex == 7)
								{
									tmp.type = SchematicObjectType.GridCell;
								}
							}
						}

						EditorAutomation.Automate("prefabID2", tmp, baseEditor, true);
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();

						EditorAutomation.AutomateNoContextClick(tmp, baseEditor);
						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					// machine start variables
					else if(typeof(MachineStringStartVariable) == type)
					{
						MachineStringStartVariable tmp = (MachineStringStartVariable)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						EditorGUILayout.BeginHorizontal();
						tmp.enabled = EditorGUILayout.Toggle(tmp.enabled, EditorTool.WIDTH_15);
						EditorGUI.BeginDisabledGroup(!tmp.enabled);
						tmp.value = EditorGUILayout.TextField(tmp.key, tmp.value, EditorTool.W_EXPAND);
						EditorGUI.EndDisabledGroup();
						EditorGUILayout.EndHorizontal();

						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					else if(typeof(MachineBoolStartVariable) == type)
					{
						MachineBoolStartVariable tmp = (MachineBoolStartVariable)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						EditorGUILayout.BeginHorizontal();
						tmp.enabled = EditorGUILayout.Toggle(tmp.enabled, EditorTool.WIDTH_15);
						EditorGUI.BeginDisabledGroup(!tmp.enabled);
						tmp.value = EditorGUILayout.Toggle(tmp.key, tmp.value,
							baseEditor.isInspector ? EditorTool.W_EXPAND : EditorTool.WIDTH);
						EditorGUI.EndDisabledGroup();
						EditorGUILayout.EndHorizontal();

						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					else if(typeof(MachineIntStartVariable) == type)
					{
						MachineIntStartVariable tmp = (MachineIntStartVariable)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						EditorGUILayout.BeginHorizontal();
						tmp.enabled = EditorGUILayout.Toggle(tmp.enabled, EditorTool.WIDTH_15);
						EditorGUI.BeginDisabledGroup(!tmp.enabled);
						tmp.value = EditorGUILayout.IntField(tmp.key, tmp.value,
							baseEditor.isInspector ? EditorTool.W_EXPAND : EditorTool.WIDTH);
						EditorGUI.EndDisabledGroup();
						EditorGUILayout.EndHorizontal();

						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					else if(typeof(MachineFloatStartVariable) == type)
					{
						MachineFloatStartVariable tmp = (MachineFloatStartVariable)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						EditorGUILayout.BeginHorizontal();
						tmp.enabled = EditorGUILayout.Toggle(tmp.enabled, EditorTool.WIDTH_15);
						EditorGUI.BeginDisabledGroup(!tmp.enabled);
						tmp.value = EditorGUILayout.FloatField(tmp.key, tmp.value,
							baseEditor.isInspector ? EditorTool.W_EXPAND : EditorTool.WIDTH);
						EditorGUI.EndDisabledGroup();
						EditorGUILayout.EndHorizontal();

						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					else if(typeof(MachineVector3StartVariable) == type)
					{
						MachineVector3StartVariable tmp = (MachineVector3StartVariable)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						EditorGUILayout.BeginHorizontal();
						tmp.enabled = EditorGUILayout.Toggle(tmp.enabled, EditorTool.WIDTH_15);
						EditorGUI.BeginDisabledGroup(!tmp.enabled);
						tmp.value = EditorGUILayout.Vector3Field(tmp.key, tmp.value,
							baseEditor.isInspector ? EditorTool.W_EXPAND : EditorTool.WIDTH);
						EditorGUI.EndDisabledGroup();
						EditorGUILayout.EndHorizontal();

						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					// horizontal settings
					else if(attributes.combinedField != null &&
						typeof(IBaseData).IsAssignableFrom(type))
					{
						IBaseData tmp = (IBaseData)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);
						EditorAutomation.ShowDebug(tmp);
						attributes.CombinedField(tmp, baseEditor, true);
						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					// value checks
					else if(typeof(BaseValueCheck).IsAssignableFrom(type))
					{
						BaseValueCheck tmp = (BaseValueCheck)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);
						if(help.content.text == fieldInfo.Name)
						{
							EditorAutomation.Automate("type", tmp, baseEditor, true);
						}
						else
						{
							EditorSortedEnum sortedEnum = EditorAttributes.GetSortedEnum(tmp.CheckType);
							int index = sortedEnum.GetIndex(tmp.CheckType);
							baseEditor.PopupSelectionField(help.content, index, sortedEnum.names, null, tmp.CheckType.GetType().FullName, help.info, attributes,
								delegate (int selectedIndex)
								{
									if(selectedIndex != index)
									{
										tmp.CheckType = (ValueCheckType)sortedEnum.GetValue(selectedIndex);
										fieldInfo.SetValue(instance, tmp);
										baseEditor.SettingChanged(instance, fieldInfo.Name, tmp);
										baseEditor.Repaint();
									}
								});
						}
						EditorAutomation.AutomateNoContextClick(tmp, baseEditor);
						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					// child object settings
					else if(typeof(ChildObjectSettings) == type)
					{
						ChildObjectSettings tmp = (ChildObjectSettings)value;
						EditorAutomation.StartContextClick(baseEditor, tmp, true);

						EditorSortedEnum sortedEnum = EditorAttributes.GetSortedEnum(tmp.type);
						int index = sortedEnum.GetIndex(tmp.type);
						baseEditor.PopupSelectionField(help.content, index, sortedEnum.names, null, tmp.type.GetType().FullName, help.info, attributes,
							delegate (int selectedIndex)
							{
								if(selectedIndex != index)
								{
									tmp.type = (ChildObjectType)sortedEnum.GetValue(selectedIndex);
									fieldInfo.SetValue(instance, tmp);
									baseEditor.SettingChanged(instance, fieldInfo.Name, tmp);
									baseEditor.Repaint();
								}
							});

						EditorAutomation.AutomateNoContextClick(tmp, baseEditor);
						EditorAutomation.EndContextClick(baseEditor, tmp, true);
						value = tmp;
					}
					// no custom automation found
					else if(typeof(IBaseData).IsAssignableFrom(type))
					{
						if(value != null)
						{
							IBaseData tmp = (IBaseData)value;
							EditorAutomation.ShowDebug(tmp);
							EditorAutomation.Automate(tmp, baseEditor, ignoreHide);
						}
					}
				}
			}
			// other IBaseData types
			else if(typeof(IBaseData).IsAssignableFrom(type))
			{
				if(value != null)
				{
					IBaseData tmp = (IBaseData)value;
					EditorAutomation.ShowDebug(tmp);
					EditorAutomation.Automate(tmp, baseEditor, ignoreHide);
				}
			}
			// Unity types
			else if(typeof(Vector2) == type)
			{
				Vector2 tmp = (Vector2)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Vector3) == type)
			{
				Vector3 tmp = (Vector3)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Vector4) == type)
			{
				Vector4 tmp = (Vector4)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Rect) == type)
			{
				Rect tmp = (Rect)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Color) == type)
			{
				Color tmp = (Color)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Texture).IsAssignableFrom(type))
			{
				Texture tmp = (Texture)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(AudioClip).IsAssignableFrom(type))
			{
				AudioClip tmp = (AudioClip)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(AudioMixer).IsAssignableFrom(type))
			{
				AudioMixer tmp = (AudioMixer)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(AudioMixerGroup).IsAssignableFrom(type))
			{
				AudioMixerGroup tmp = (AudioMixerGroup)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(GameObject).IsAssignableFrom(type))
			{
				GameObject tmp = (GameObject)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(GUISkin).IsAssignableFrom(type))
			{
				GUISkin tmp = (GUISkin)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Material).IsAssignableFrom(type))
			{
				Material tmp = (Material)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
#if Unity_2019
			else if(typeof(PhysicMaterial).IsAssignableFrom(type))
			{
				PhysicMaterial tmp = (PhysicMaterial)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
#else
			else if(typeof(PhysicsMaterial).IsAssignableFrom(type))
			{
				PhysicsMaterial tmp = (PhysicsMaterial)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
#endif
			else if(typeof(PhysicsMaterial2D).IsAssignableFrom(type))
			{
				PhysicsMaterial2D tmp = (PhysicsMaterial2D)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Sprite).IsAssignableFrom(type))
			{
				Sprite tmp = (Sprite)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(Font).IsAssignableFrom(type))
			{
				Font tmp = (Font)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(AnimationCurve).IsAssignableFrom(type))
			{
				AnimationCurve tmp = (AnimationCurve)value;
				EditorTool.CurveField(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			// asset types
			else if(typeof(MakinomSchematicAsset).IsAssignableFrom(type))
			{
				MakinomSchematicAsset tmp = (MakinomSchematicAsset)value;
				EditorTool.Field(help.content, ref tmp, help.info, attributes, baseEditor);
				value = tmp;
			}
			else if(typeof(UnityEngine.Object).IsAssignableFrom(type))
			{
				UnityEngine.Object tmp = (UnityEngine.Object)value;
				EditorTool.AssetField(help.content, ref tmp, type, help.info, attributes, baseEditor);
				value = tmp;
			}
			// arrays
			else if(type.IsArray)
			{
				ArrayList tmp = null;
				if(value != null)
				{
					tmp = new ArrayList(value as System.Array);
				}

				if(tmp != null)
				{
					if(attributes.array.isAdd)
					{
						EditorGUILayout.Separator();

						bool clearSearch = false;
						if(baseEditor.CheckSearch(attributes.array.addText[0]))
						{
							clearSearch = true;
							EditorAutomation.MarkSearch(true, baseEditor, true);
						}
						if(baseEditor.isInspector ?
							GUILayout.Button(
								new GUIContent(attributes.array.addText[0], EditorContent.Instance.AddIcon, attributes.array.addText[1])) :
							EditorTool.Button(
								new GUIContent(attributes.array.addText[0], EditorContent.Instance.AddIcon, attributes.array.addText[1]),
								attributes.array.addText[1], attributes.array.addText[2]))
						{
							tmp.Add(ReflectionTypeHandler.Instance.CreateInstance(type.GetElementType()));
							if(attributes.array.callbackAdd != "")
							{
								baseEditor.AutomationAddCallback(attributes.array.callbackAdd);
							}
						}
						if(clearSearch)
						{
							EditorAutomation.MarkSearch(false, baseEditor, false);
						}
					}

					int removeIndex = -1;
					for(int i = 0; i < tmp.Count; i++)
					{
						bool show = true;
						if(show && attributes.array.checkCallback != "")
						{
							if(!baseEditor.AutomationCheck(i, attributes.array.checkCallback))
							{
								show = false;
							}
						}

						if(show)
						{
							object obj = tmp[i];

							// element settings
							if(obj != null)
							{
								IBaseData tmpInstance = obj as IBaseData;
								if(tmpInstance != null)
								{
									EditorAutomation.StartContextClick(baseEditor, tmpInstance, true);
								}

								// box and horizontal options
								if(attributes.array.foldout)
								{
									if(Maki.EditorSettings.foldoutExtendedInformation &&
										obj is IFoldoutInfo)
									{
										string info = "";
										try
										{
											info = ((IFoldoutInfo)obj).GetFoldoutInfo();
										}
										catch(System.Exception ex)
										{
											// silent
										}
										if(attributes.array.foldoutText == null)
										{
											EditorHelpAttribute tmpHelp = EditorAttributes.GetTypeHelpText(obj.GetType());
											baseEditor.BeginFoldout(tmpHelp.content.text + " " + i + (info != "" ? ": " + info : ""), tmpHelp.content.tooltip,
												tmpHelp.info, attributes.array.foldoutDefault);
										}
										else
										{
											baseEditor.BeginFoldout(attributes.array.foldoutText[0] + " " + i + (info != "" ? ": " + info : ""),
												attributes.array.foldoutText[1], attributes.array.foldoutText[2],
												attributes.array.foldoutDefault);
										}
									}
									else
									{
										if(attributes.array.foldoutText == null)
										{
											EditorHelpAttribute tmpHelp = EditorAttributes.GetTypeHelpText(obj.GetType());
											baseEditor.BeginFoldout(tmpHelp.content.text + " " + i, tmpHelp.content.tooltip,
												tmpHelp.info, attributes.array.foldoutDefault);
										}
										else
										{
											baseEditor.BeginFoldout(attributes.array.foldoutText[0] + " " + i,
												attributes.array.foldoutText[1], attributes.array.foldoutText[2],
												attributes.array.foldoutDefault);
										}
									}
								}
								if(baseEditor.GetFoldout(false))
								{
									if(attributes.array.enbox)
									{
										EditorGUILayout.BeginVertical(EditorContent.Instance.BoxStyle);
									}
									if(attributes.array.isHorizontal)
									{
										EditorGUILayout.BeginHorizontal();
									}

									if(attributes.array.titleLabel != "")
									{
										EditorTool.BoldLabel(attributes.array.titleLabel + " " + i);
									}

									// remove button
									if((attributes.array.isCopy || attributes.array.isMove) &&
										!attributes.array.isHorizontal)
									{
										EditorGUILayout.BeginHorizontal();
									}
									bool doContinue = false;
									if(attributes.array.isRemove &&
										tmp.Count > attributes.array.noRemoveCount)
									{
										if(baseEditor.isInspector || attributes.array.isHorizontal ?
											GUILayout.Button(new GUIContent(EditorContent.Instance.RemoveIcon, attributes.array.removeText[1]), EditorTool.WIDTH_30) :
											EditorTool.SmallButton(
												new GUIContent(attributes.array.removeText[0], EditorContent.Instance.RemoveIcon, attributes.array.removeText[1]),
												attributes.array.removeText[1], attributes.array.removeText[2]))
										{
											removeIndex = i;
											/*tmp.RemoveAt(i);
											if(attributes.array.foldout)
											{
												baseEditor.RemoveCurrentFoldout();
											}
											if(attributes.array.callbackRemove != "")
											{
												baseEditor.AutomationRemoveCallback(i, attributes.array.callbackRemove);
											}
											i--;
											doContinue = true;*/
										}
									}
									if(attributes.array.isCopy && obj is IBaseData)
									{
										if(baseEditor.isInspector || attributes.array.isHorizontal ?
											GUILayout.Button(new GUIContent(EditorContent.Instance.CopyIcon, "Create a copy of this element."), EditorTool.WIDTH_30) :
											EditorTool.SmallButton(
												new GUIContent("Copy", EditorContent.Instance.CopyIcon, "Create a copy of this element."),
												"Create a copy of this element.", ""))
										{
											object newObj = ReflectionTypeHandler.Instance.CreateInstance(obj.GetType());
											((IBaseData)newObj).SetData(((IBaseData)obj).GetData());
											tmp.Insert(i + 1, newObj);
											if(attributes.array.callbackAdd != "")
											{
												baseEditor.AutomationAddCallback(attributes.array.callbackAdd);
											}
										}
									}
									if(attributes.array.isMove &&
										tmp.Count > 1)
									{
										EditorGUI.BeginDisabledGroup(i == 0);
										if(baseEditor.isInspector || attributes.array.isHorizontal ?
											GUILayout.Button(new GUIContent(EditorContent.Instance.MoveUpIcon, "Move this element up by one position."), EditorTool.WIDTH_30) :
											EditorTool.SmallButton(
												new GUIContent("Move Up", EditorContent.Instance.MoveUpIcon, "Move this element up by one position."),
												"Move this element up by one position.", ""))
										{
											tmp[i] = tmp[i - 1];
											tmp[i - 1] = obj;
											i--;
											doContinue = true;
										}
										EditorGUI.EndDisabledGroup();

										EditorGUI.BeginDisabledGroup(i == tmp.Count - 1);
										if(baseEditor.isInspector || attributes.array.isHorizontal ?
											GUILayout.Button(new GUIContent(EditorContent.Instance.MoveDownIcon, "Move this element down by one position."), EditorTool.WIDTH_30) :
											EditorTool.SmallButton(
												new GUIContent("Move Down", EditorContent.Instance.MoveDownIcon, "Move this element down by one position."),
												"Move this element down by one position.", ""))
										{
											tmp[i] = tmp[i + 1];
											tmp[i + 1] = obj;
											i--;
											doContinue = true;
										}
										EditorGUI.EndDisabledGroup();
									}
									if((attributes.array.isCopy || attributes.array.isMove) &&
										!attributes.array.isHorizontal)
									{
										GUILayout.FlexibleSpace();
										EditorGUILayout.EndHorizontal();
										EditorGUILayout.Separator();
									}
									if(doContinue)
									{
										continue;
									}

									if(attributes.array.callbackBefore != "")
									{
										baseEditor.AutomationCallback(i, attributes.array.callbackBefore);
									}

									EditorHelpAttribute tmpHelp = new EditorHelpAttribute(help);
									if(attributes.array.nameIndex)
									{
										tmpHelp.content.text += " " + i;
									}

									if(attributes.array.showOnly)
									{
										EditorTool.Label(obj.ToString());
									}
									else
									{
										if(obj is FieldChange)
										{
											if(obj != null)
											{
												FieldChange tmpField = (FieldChange)obj;
												EditorAutomation.FieldChange(ref tmpField, instance, baseEditor);
												obj = tmpField;
											}
										}
										else if(obj is SchematicFieldCheck)
										{
											if(obj != null)
											{
												SchematicFieldCheck tmpField = (SchematicFieldCheck)obj;
												EditorAutomation.SchematicFieldCheck(ref tmpField, instance, baseEditor);
												obj = tmpField;
											}
										}
										else
										{
											EditorAutomation.Value(ref obj, fieldInfo, obj.GetType(),
												attributes, tmpHelp, instance, baseEditor, ignoreHide);
										}
										tmp[i] = obj;
									}

									if(attributes.array.callbackAfter != "")
									{
										baseEditor.AutomationCallback(i, attributes.array.callbackBefore);
									}

									// box and horizontal options
									if(attributes.array.isHorizontal)
									{
										if(!baseEditor.isInspector)
										{
											GUILayout.FlexibleSpace();
										}
										EditorGUILayout.EndHorizontal();
									}
									if(attributes.array.separator)
									{
										EditorGUILayout.Separator();
									}
									if(attributes.array.enbox)
									{
										EditorGUILayout.EndVertical();
									}
								}
								if(attributes.array.foldout)
								{
									baseEditor.EndFoldout();
								}

								if(tmpInstance != null)
								{
									EditorAutomation.EndContextClick(baseEditor, tmpInstance, true);
								}
							}
						}
						else if(attributes.array.setDefaultValue)
						{
							tmp[i] = attributes.array.defaultValue;
						}
					}

					if(removeIndex >= 0)
					{
						tmp.RemoveAt(removeIndex);
						if(attributes.array.callbackRemove != "")
						{
							baseEditor.AutomationRemoveCallback(removeIndex, attributes.array.callbackRemove);
						}
					}

					if(attributes.array.isAdd &&
						tmp.Count > 0)
					{
						bool clearSearch = false;
						if(baseEditor.CheckSearch(attributes.array.addText[0]))
						{
							clearSearch = true;
							EditorAutomation.MarkSearch(true, baseEditor, true);
						}
						if(baseEditor.isInspector ?
							GUILayout.Button(
								new GUIContent(attributes.array.addText[0], EditorContent.Instance.AddIcon, attributes.array.addText[1])) :
							EditorTool.Button(
								new GUIContent(attributes.array.addText[0], EditorContent.Instance.AddIcon, attributes.array.addText[1]),
								attributes.array.addText[1], attributes.array.addText[2]))
						{
							tmp.Add(ReflectionTypeHandler.Instance.CreateInstance(type.GetElementType()));
							if(attributes.array.callbackAdd != "")
							{
								baseEditor.AutomationAddCallback(attributes.array.callbackAdd);
							}
						}
						if(clearSearch)
						{
							EditorAutomation.MarkSearch(false, baseEditor, false);
						}
						EditorGUILayout.Separator();
					}

					value = System.Convert.ChangeType(tmp.ToArray(type.GetElementType()), type);
				}
			}
			return true;
		}


		/*
		============================================================================
		Special automation functions
		============================================================================
		*/
		public static object GetFieldValue(object instance, string fieldName)
		{
			if(instance != null)
			{
				FieldInfo fieldInfo = instance.GetType().GetField(fieldName);
				if(fieldInfo != null)
				{
					return fieldInfo.GetValue(instance);
				}
			}
			return null;
		}

		public static void FieldChange(ref FieldChange field, IBaseData instance, BaseEditor baseEditor)
		{
			string className = "";
			FieldInfo reflectionField = instance.GetType().GetField("className");
			if(reflectionField != null)
			{
				object fieldValue = reflectionField.GetValue(instance);
				if(fieldValue is string)
				{
					className = (string)fieldValue;
				}
			}

			// field name
			FieldInfo fieldInfo = field.GetType().GetField("fieldName");
			if(fieldInfo != null)
			{
				AttributeHelper attributes = EditorAttributes.GetAttribute(fieldInfo, field.GetType());
				baseEditor.ReflectionField(attributes.help.content, ref field.fieldName, attributes.help.info,
					attributes, className, field.IsProperty ?
						EditorReflectionField.Type.Property :
						EditorReflectionField.Type.Field,
					field.FieldType);
			}

			// other settings
			EditorAutomation.Automate(field, baseEditor);
		}

		public static void SchematicFieldCheck(ref SchematicFieldCheck field, IBaseData instance, BaseEditor baseEditor)
		{
			string className = "";
			FieldInfo reflectionField = instance.GetType().GetField("className");
			if(reflectionField != null)
			{
				object fieldValue = reflectionField.GetValue(instance);
				if(fieldValue is string)
				{
					className = (string)fieldValue;
				}
			}

			// field name
			FieldInfo fieldInfo = field.GetType().GetField("fieldName");
			if(fieldInfo != null)
			{
				AttributeHelper attributes = EditorAttributes.GetAttribute(fieldInfo, field.GetType());
				baseEditor.ReflectionField(attributes.help.content, ref field.fieldName, attributes.help.info,
					attributes, className,
					field.isProperty ?
						EditorReflectionField.Type.Property :
						EditorReflectionField.Type.Field,
					field.FieldType);
			}

			// other settings
			EditorAutomation.Automate(field, baseEditor);
		}
	}
}
