
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(RenderMachineComponent))]
public class RenderMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as RenderMachineComponent);
	}

	private void MachineSetup(RenderMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Render Machine' on " + target.name);
		this.BaseInit(true);

		// warnings
		if((target.settings.startSetting.isPreRender || target.settings.startSetting.isPostRender) &&
			target.GetComponent<Camera>() == null)
		{
			EditorGUILayout.HelpBox("Only called when attached to a camera.", MessageType.Warning);
		}

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		this.EndSetup();
	}
}
