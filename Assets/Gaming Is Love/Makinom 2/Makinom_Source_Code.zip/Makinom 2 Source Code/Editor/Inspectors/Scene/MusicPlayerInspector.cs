﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MusicPlayer))]
public class MusicPlayerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as MusicPlayer);
	}

	private void ComponentSetup(MusicPlayer target)
	{
		Undo.RecordObject(target, "Change to 'Music Player' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Music Settings", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}