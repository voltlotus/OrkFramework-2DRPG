
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(MakinomHandler))]
public class MakinomHandlerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.BaseInit(true);

		if(Application.isPlaying)
		{
			// states
			if(this.baseEditor.BeginFoldout("Controls/States", "", "", true))
			{
				EditorGUILayout.LabelField("Game Running", Maki.Game.Running.ToString());
				EditorGUILayout.LabelField("Game Paused", Maki.Game.Paused.ToString());
				EditorGUILayout.LabelField("Game Time", Maki.Game.GetTimeString());
				EditorGUILayout.LabelField("Player Control Blocked", Maki.Control.Blocked.ToString());
				EditorGUILayout.LabelField("Camera Control Blocked", Maki.Control.CameraBlocked.ToString());
				EditorGUILayout.LabelField("Can Interact", Maki.Control.CanInteract.ToString());
				EditorGUILayout.LabelField("Changing Scene", Maki.Control.ChangingScene.ToString());
				EditorGUILayout.Separator();

				EditorTool.BoldLabel("Game States");
				for(int i = 0; i < Maki.GameStates.Count; i++)
				{
					GameState state = Maki.GameStates.Get(i);
					if(state != null)
					{
						EditorGUILayout.LabelField(state.name, state.IsActive.ToString());
					}
				}
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// volumes
			if(this.baseEditor.BeginFoldout("Audio Volumes", "", "", false))
			{
				// global
				Maki.Audio.GlobalVolume = EditorGUILayout.Slider("Global Volume", Maki.Audio.RealGlobalVolume, 0, 1);
				Maki.Audio.MuteGlobalVolume = EditorGUILayout.Toggle("Mute Global", Maki.Audio.MuteGlobalVolume);
				EditorGUILayout.Separator();

				// music
				EditorTool.BoldLabel("Music Volumes");
				Maki.Audio.MusicVolume = EditorGUILayout.Slider("Music Volume", Maki.Audio.RealMusicVolume, 0, 1);
				Maki.Audio.MuteMusicVolume = EditorGUILayout.Toggle("Mute Music", Maki.Audio.MuteMusicVolume);
				EditorGUILayout.Separator();

				Dictionary<int, MusicChannel> musicChannels = Maki.Audio.GetMusicChannels();
				foreach(KeyValuePair<int, MusicChannel> pair in musicChannels)
				{
					pair.Value.Volume = EditorGUILayout.Slider("Music Channel " + pair.Key + " Volume", pair.Value.RealVolume, 0, 1);
					pair.Value.Mute = EditorGUILayout.Toggle("Mute Music Channel " + pair.Key, pair.Value.Mute);
					EditorGUILayout.Separator();
				}

				// sound
				EditorTool.BoldLabel("Sound Volumes");
				Maki.Audio.SoundVolume = EditorGUILayout.Slider("Sound Volume", Maki.Audio.RealSoundVolume, 0, 1);
				Maki.Audio.MuteSoundVolume = EditorGUILayout.Toggle("Mute Sound", Maki.Audio.MuteSoundVolume);
				EditorGUILayout.Separator();

				Dictionary<int, SoundChannel> soundChannels = Maki.Audio.GetSoundChannels();
				foreach(KeyValuePair<int, SoundChannel> pair in soundChannels)
				{
					pair.Value.Volume = EditorGUILayout.Slider("Sound Channel " + pair.Key + " Volume", pair.Value.RealVolume, 0, 1);
					pair.Value.Mute = EditorGUILayout.Toggle("Mute Sound Channel " + pair.Key, pair.Value.Mute);
					EditorGUILayout.Separator();
				}
			}
			this.baseEditor.EndFoldout();


			// machines
			if(this.baseEditor.BeginFoldout("Machines/Schematics", "", "", true))
			{
				EditorGUILayout.LabelField("Blocking Machines", Maki.Control.IsMachineBlocked.ToString());
				EditorGUILayout.LabelField("Running Schematics", Maki.MachineHandler.Count.ToString());
				EditorGUILayout.LabelField("Non Priority Count", Maki.MachineHandler.NonPriorityCount.ToString());
				EditorGUILayout.LabelField("Priority Count", Maki.MachineHandler.PriorityCount.ToString());
				EditorGUILayout.Separator();

				// update priority
				if(this.baseEditor.BeginFoldout("Update (Priority)", "", "", false))
				{
					this.ShowRunningMachines(Maki.MachineHandler.UpdateMachines.GetPriorityMachines());
				}
				this.baseEditor.EndFoldout();

				// update
				if(this.baseEditor.BeginFoldout("Update", "", "", false))
				{
					this.ShowRunningMachines(Maki.MachineHandler.UpdateMachines.GetMachines());
				}
				this.baseEditor.EndFoldout();

				// late update priority
				if(this.baseEditor.BeginFoldout("Late Update (Priority)", "", "", false))
				{
					this.ShowRunningMachines(Maki.MachineHandler.LateUpdateMachines.GetPriorityMachines());
				}
				this.baseEditor.EndFoldout();

				// late update
				if(this.baseEditor.BeginFoldout("Late Update", "", "", false))
				{
					this.ShowRunningMachines(Maki.MachineHandler.LateUpdateMachines.GetMachines());
				}
				this.baseEditor.EndFoldout();

				// fixed update priority
				if(this.baseEditor.BeginFoldout("Fixed Update (Priority)", "", "", false))
				{
					this.ShowRunningMachines(Maki.MachineHandler.FixedUpdateMachines.GetPriorityMachines());
				}
				this.baseEditor.EndFoldout();

				// fixed update
				if(this.baseEditor.BeginFoldout("Fixed Update", "", "", false))
				{
					this.ShowRunningMachines(Maki.MachineHandler.FixedUpdateMachines.GetMachines());
				}
				this.baseEditor.EndFoldout();
			}
			this.baseEditor.EndFoldout();


			// variables
			if(this.baseEditor.BeginFoldout("Variables", "", "", true))
			{
				this.baseEditor.VariableEditor.Show(Maki.Game.Variables);
			}
			this.baseEditor.EndFoldout();
		}
		else
		{
			EditorGUILayout.HelpBox("Shows information while playing.", MessageType.Info);
		}
		EditorGUILayout.Separator();
	}

	private void ShowRunningMachines(List<Schematic> list)
	{
		EditorGUILayout.LabelField("Running", list.Count.ToString());
		for(int i = 0; i < list.Count; i++)
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.InspectorBoxStyle);
			if(list[i].IsPriority)
			{
				GUILayout.Label("Priority " + list[i].Priority);
			}
			if(list[i].Starter is GlobalMachine)
			{
				GUILayout.Label("Global Machine");
			}
			else if(list[i].Starter is GameStarter)
			{
				GUILayout.Label("Game Starter");
			}

			EditorGUILayout.ObjectField("Schematic Asset",
				list[i].Asset, typeof(MakinomSchematicAsset), true);
			EditorGUILayout.ObjectField("Machine Object",
				list[i].MachineObject != null ? list[i].MachineObject.FirstAdded : null, typeof(GameObject), true);
			EditorGUILayout.ObjectField("Starting Object",
				list[i].StartingObject != null ? list[i].StartingObject.FirstAdded : null, typeof(GameObject), true);

			if(GUILayout.Button("Stop Machine"))
			{
				list[i].Stop();
			}

			EditorGUILayout.EndVertical();
		}
	}
}
