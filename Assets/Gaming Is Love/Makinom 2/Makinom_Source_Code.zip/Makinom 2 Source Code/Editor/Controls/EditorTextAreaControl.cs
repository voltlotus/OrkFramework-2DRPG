
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorTextAreaControl
	{
		private static BaseUITextCodes systemTextCodes = null;

		private static int optionsOffset = 0;

		private static string[] options = new string[] {
			"Custom", "Data", "Variable"
		};

		private static string[] optionsActor = new string[] {
			"Custom", "Data", "Variable", "Actor"
		};

		private static string[] dataOptions;

		private string[] dataNames = new string[0];

		private static string[] variableOptions = new string[] {
			"String", "Bool", "Int", "Int with Format", "Float", "Float as Int", "Float with Format",
			"Vector3", "Vector3 X-Axis", "Vector3 Y-Axis", "Vector3 Z-Axis"
		};

		private static string[] actorSubOptions = new string[] {
			"Name", "Short Name", "Description", "Icon", "Custom Content",
			"Type Name", "Type Short Name", "Type Description", "Type Icon", "Type Custom Content"
		};


		// controls
		public Vector2 scroll = Vector2.zero;

		public bool isEditing = false;

		public string editingText = "";

		public TextContent text;


		// menu
		public bool moreOptions = false;

		public int buttonMode = 0;

		public int dataMode = 0;

		public TextCodeAttribute textCodeData;

		public int subMode = 0;

		public int subData = 0;

		public int subDataIndex = 0;

		public string gvKey = "";

		public string floatFormat = "00.0";

		public string customContentKey = "";


		// selections
		public int selectionStart = 0;

		public int selectionEnd = 0;

		public bool updateSelections = false;

		public EditorTextAreaControl(BaseEditor baseEditor)
		{
			if(EditorTextAreaControl.dataOptions == null)
			{
				List<TextCodeAttribute> textCodes = EditorDataHandler.Instance.TextCodes;
				EditorTextAreaControl.dataOptions = new string[textCodes.Count];
				for(int i = 0; i < textCodes.Count; i++)
				{
					EditorTextAreaControl.dataOptions[i] = textCodes[i].name;
				}
			}
		}

		public static void ResetTextCodes()
		{
			systemTextCodes = null;
			optionsOffset = 0;
			options = new string[] {
				"Custom", "Data", "Variable"
			};
			optionsActor = new string[] {
				"Custom", "Data", "Variable", "Actor"
			};
		}


		/*
		============================================================================
		Text functions
		============================================================================
		*/
		private void ShowTextCodeButton(BaseUITextCodes.TextCodeSingle textCode, GUILayoutOption width)
		{
			if(textCode != null &&
				textCode.Used &&
				EditorTool.ShowButton2(textCode.name, textCode.tooltip, "",
				width, EditorContent.Instance.ButtonRichTextStyle))
			//EditorTool.MicroButton2(textCode.name, textCode.tooltip, ""))
			{
				this.WrapText(textCode.open, textCode.close);
			}
		}

		private void ShowTextCodeAttributes(BaseUITextCodes.TextCodeSingle textCode)
		{
			if(textCode != null &&
				textCode.Used &&
				textCode.attribute != null)
			{
				for(int i = 0; i < textCode.attribute.Length; i++)
				{
					if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Option == textCode.attribute[i].type)
					{
						EditorTool.ToggleButton(textCode.attribute[i].name, ref textCode.attribute[i].useOption,
							textCode.attribute[i].tooltip, "");
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Color == textCode.attribute[i].type ||
						BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.ColorAlpha == textCode.attribute[i].type)
					{
						EditorTool.NoTitleField<Color>(textCode.attribute[i].name, ref textCode.attribute[i].color,
							textCode.attribute[i].tooltip, "", null, EditorTool.W_MICRO_BUTTON);
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Int == textCode.attribute[i].type)
					{
						EditorTool.NoTitleField<int>(textCode.attribute[i].name, ref textCode.attribute[i].intValue,
							textCode.attribute[i].tooltip, "", null, EditorTool.WIDTH_150);
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Float == textCode.attribute[i].type)
					{
						EditorTool.NoTitleField<float>(textCode.attribute[i].name, ref textCode.attribute[i].floatValue,
							textCode.attribute[i].tooltip, "", null, EditorTool.WIDTH_150);
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.String == textCode.attribute[i].type)
					{
						EditorTool.NoTitleField<string>(textCode.attribute[i].name, ref textCode.attribute[i].stringValue,
							textCode.attribute[i].tooltip, "", null, EditorTool.WIDTH_150);
					}
				}
			}
		}

		private string GetAttributeOpen(BaseUITextCodes.TextCodeSingle textCode)
		{
			string open = textCode.open;
			if(!string.IsNullOrEmpty(textCode.open) &&
				textCode.attribute != null)
			{
				for(int i = 0; i < textCode.attribute.Length; i++)
				{
					string value = "";
					if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Option == textCode.attribute[i].type)
					{
						value = textCode.attribute[i].useOption ? textCode.attribute[i].option : "";
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Color == textCode.attribute[i].type)
					{
						value = TextHelper.GetColorString(textCode.attribute[i].color);
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.ColorAlpha == textCode.attribute[i].type)
					{
						value = TextHelper.GetColorAlphaString(textCode.attribute[i].color);
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Int == textCode.attribute[i].type)
					{
						value = textCode.attribute[i].intValue.ToString();
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.Float == textCode.attribute[i].type)
					{
						value = textCode.attribute[i].floatValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
					}
					else if(BaseUITextCodes.TextCodeSingle.Attribute.AttributeType.String == textCode.attribute[i].type)
					{
						value = textCode.attribute[i].stringValue;
					}
					open = open.Replace("[" + i + "]", value);
				}
			}
			return open;
		}

		private void WrapText(BaseUITextCodes.TextCodeSingle textCode)
		{
			this.WrapText(this.GetAttributeOpen(textCode), textCode.close);
		}

		private void WrapText(string begin, string end)
		{
			if(this.selectionStart < 0)
			{
				this.selectionStart = 0;
			}
			else if(this.selectionStart > this.editingText.Length)
			{
				this.selectionStart = this.editingText.Length;
			}
			if(this.selectionEnd < this.selectionStart || this.selectionEnd < 0)
			{
				this.selectionEnd = this.selectionStart;
			}
			else if(this.selectionEnd > this.editingText.Length)
			{
				this.selectionEnd = this.editingText.Length;
			}

			this.editingText = this.editingText.Insert(this.selectionEnd, end);
			this.editingText = this.editingText.Insert(this.selectionStart, begin);

			this.selectionStart += begin.Length;
			this.selectionEnd += begin.Length;
			this.updateSelections = true;
		}

		private void InsertText(string insert)
		{
			if(this.selectionStart < 0)
			{
				this.selectionStart = 0;
			}
			else if(this.selectionStart > this.editingText.Length)
			{
				this.selectionStart = this.editingText.Length;
			}
			if(this.selectionEnd < this.selectionStart || this.selectionEnd < 0)
			{
				this.selectionEnd = this.selectionStart;
			}
			else if(this.selectionEnd > this.editingText.Length)
			{
				this.selectionEnd = this.editingText.Length;
			}

			this.editingText = this.editingText.Insert(this.selectionStart, insert);

			this.selectionStart += insert.Length;
			this.selectionEnd += insert.Length;
			this.updateSelections = true;
		}

		private void AddSubDataSettings()
		{
			if(this.textCodeData != null &&
				this.subMode >= 0 &&
				this.subMode < this.textCodeData.textCodes.Length)
			{
				IMakinomGenericAsset asset = EditorDataHandler.Instance.GetAssetAtIndex(this.textCodeData.assetType, this.subData);

				if(asset != null)
				{
					// sub data
					if(this.textCodeData.IsSubContent(this.subMode))
					{
						// sub data custom content
						if(this.textCodeData.IsCustomContent(this.subMode))
						{
							this.InsertText(this.textCodeData.textCodes[this.subMode] + asset.EditorSettings.GUID +
								TextCode.SubData + this.subDataIndex +
								TextCode.CustomContent + this.customContentKey + TextCode.QuoteCloseTag);
						}
						// sub data other
						else
						{
							this.InsertText(this.textCodeData.textCodes[this.subMode] + asset.EditorSettings.GUID +
								TextCode.SubData + this.subDataIndex + TextCode.QuoteCloseTag);
						}
					}
					// custom content
					else if(this.textCodeData.IsCustomContent(this.subMode))
					{
						this.InsertText(this.textCodeData.textCodes[this.subMode] + asset.EditorSettings.GUID +
							TextCode.CustomContent + this.customContentKey + TextCode.QuoteCloseTag);
					}
					// other
					else
					{
						this.InsertText(this.textCodeData.textCodes[this.subMode] + asset.EditorSettings.GUID + TextCode.CloseTag);
					}
				}
			}
		}

		private void AddActorData(string name, string shortName, string description, string icon, string customContent,
			string typeName, string typeShortName, string typeDescription, string typeIcon, string typeCustomContent)
		{
			string data = this.subData.ToString();

			// Name
			if(this.subMode == 0)
			{
				this.InsertText(name + data + TextCode.CloseTag);
			}
			// Short Name
			else if(this.subMode == 1)
			{
				this.InsertText(shortName + data + TextCode.CloseTag);
			}
			// Description
			else if(this.subMode == 2)
			{
				this.InsertText(description + data + TextCode.CloseTag);
			}
			// Icon
			else if(this.subMode == 3)
			{
				this.InsertText(icon + data + TextCode.CloseTag);
			}
			// Custom Content
			else if(this.subMode == 4)
			{
				this.InsertText(customContent + data + TextCode.CustomContent + this.customContentKey + TextCode.QuoteCloseTag);
			}
			// Type Name
			else if(this.subMode == 5)
			{
				this.InsertText(typeName + data + TextCode.CloseTag);
			}
			// Type Short Name
			else if(this.subMode == 6)
			{
				this.InsertText(typeShortName + data + TextCode.CloseTag);
			}
			// Type Description
			else if(this.subMode == 7)
			{
				this.InsertText(typeDescription + data + TextCode.CloseTag);
			}
			// Type Icon
			else if(this.subMode == 8)
			{
				this.InsertText(typeIcon + data + TextCode.CloseTag);
			}
			// Type Custom Content
			else if(this.subMode == 9)
			{
				this.InsertText(typeCustomContent + data + TextCode.CustomContent + this.customContentKey + TextCode.QuoteCloseTag);
			}
		}


		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public void CancelEditing()
		{
			if(this.isEditing)
			{
				GUI.FocusControl("");
				this.isEditing = false;
				this.editingText = "";
				EditorTextAreaControl.CheckAssetReferences(ref this.text);
			}
		}

		public void AcceptEditing()
		{
			if(this.isEditing)
			{
				GUI.FocusControl("");
				this.isEditing = false;
				this.text.text = this.editingText;
				this.editingText = "";
				EditorTextAreaControl.CheckAssetReferences(ref this.text);
			}
		}

		public void Edit(GUIContent content, ref TextContent text, string helpInfo, BaseEditor baseEditor, int optionType)
		{
			this.text = text;
			EditorGUILayout.BeginVertical();

			EditorGUILayout.Separator();

			if(this.isEditing)
			{
				// name and ok/cancel editing
				EditorGUILayout.BeginHorizontal();
				EditorTool.BoldLabel(content);
				EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);

				if(EditorTool.MicroButton2("Cancel", "Cancels editing the text and restores the previous text.", ""))
				{
					this.CancelEditing();
				}
				if(EditorTool.MicroButton2("Ok", "Accepts the changes and ends editing the text.", ""))
				{
					this.AcceptEditing();
				}

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Separator();

				// text format controls
				EditorGUILayout.BeginHorizontal();

				if(systemTextCodes == null)
				{
					systemTextCodes = Maki.UISystem.settings.TextCodes;

					if(systemTextCodes != null)
					{
						optionsOffset = systemTextCodes.other.Count;
						List<string> optionList = new List<string>();
						for(int i = 0; i < systemTextCodes.other.Count; i++)
						{
							optionList.Add(systemTextCodes.other[i].name);
						}
						optionList.Add("Custom");
						optionList.Add("Data");
						optionList.Add("Variable");
						options = optionList.ToArray();

						optionList.Add("Actor");
						optionsActor = optionList.ToArray();
					}
					else
					{
						optionsOffset = 0;
						options = new string[] {
							"Custom", "Data", "Variable"
						};

						optionsActor = new string[] {
							"Custom", "Data", "Variable", "Actor"
						};
					}
				}

				if(systemTextCodes != null)
				{
					if(EditorContent.CTRL_B &&
						systemTextCodes.bold != null &&
						systemTextCodes.bold.Used)
					{
						this.WrapText(systemTextCodes.bold);
						if(EventType.Repaint != Event.current.type &&
							EventType.Layout != Event.current.type)
						{
							Event.current.Use();
						}
					}
					if(EditorContent.CTRL_I &&
						systemTextCodes.italic != null &&
						systemTextCodes.italic.Used)
					{
						this.WrapText(systemTextCodes.italic);
						if(EventType.Repaint != Event.current.type &&
							EventType.Layout != Event.current.type)
						{
							Event.current.Use();
						}
					}

					// text style
					this.ShowTextCodeButton(systemTextCodes.bold, EditorTool.WIDTH_30);
					this.ShowTextCodeButton(systemTextCodes.italic, EditorTool.WIDTH_30);
					EditorGUILayout.Separator();

					// lines
					this.ShowTextCodeButton(systemTextCodes.strikethrough, EditorTool.WIDTH_45);
					this.ShowTextCodeButton(systemTextCodes.underline, EditorTool.WIDTH_45);
					EditorGUILayout.Separator();

					// alignment
					this.ShowTextCodeButton(systemTextCodes.alignLeft, EditorTool.WIDTH_45);
					this.ShowTextCodeButton(systemTextCodes.alignCenter, EditorTool.WIDTH_45);
					this.ShowTextCodeButton(systemTextCodes.alignRight, EditorTool.WIDTH_45);
					EditorGUILayout.Separator();
				}

				EditorTool.ToggleButton("More", ref this.moreOptions, "Display more text options.", "");

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();


				if(this.moreOptions)
				{
					EditorGUILayout.Separator();

					// sub selector
					EditorGUILayout.BeginHorizontal();

					// actor mode
					if(optionType == 1)
					{
						this.buttonMode = GUILayout.Toolbar(this.buttonMode, EditorTextAreaControl.optionsActor);
					}
					// rest
					else
					{
						this.buttonMode = GUILayout.Toolbar(this.buttonMode, EditorTextAreaControl.options);
					}

					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.Separator();


					// sub menu
					EditorGUILayout.BeginHorizontal();

					// others
					if(this.buttonMode < optionsOffset)
					{
						if(systemTextCodes != null)
						{
							if(this.buttonMode < systemTextCodes.other.Count)
							{
								EditorTool.NoTitlePopup("Text Code",
									ref this.subData, systemTextCodes.other[this.buttonMode].names,
									"Select the text code that will be used.", "", baseEditor);
								if(this.subData >= 0 &&
									this.subData < systemTextCodes.other[this.buttonMode].textCode.Length)
								{
									this.ShowTextCodeAttributes(systemTextCodes.other[this.buttonMode].textCode[this.subData]);

									if(EditorTool.MicroButton2("Add", "Add the selected text code.\n" +
										systemTextCodes.other[this.buttonMode].textCode[this.subData].tooltip, ""))
									{
										this.WrapText(systemTextCodes.other[this.buttonMode].textCode[this.subData]);
									}
								}
							}
							else
							{
								EditorTool.Label("The UI system doesn't have other text codes available");
							}
						}
					}
					// custom text codes
					else if(this.buttonMode == optionsOffset)
					{
						string[] textCode = Maki.TextCodes.GetTextCodes();
						if(textCode.Length > 0)
						{
							EditorTool.NoTitlePopup("Custom Text Code", ref this.subData, textCode,
								"Select the custom text code that will be used.", "", baseEditor);
							if(EditorTool.MicroButton2("Add", "Add the selected text code.", ""))
							{
								this.InsertText(textCode[this.subData]);
							}
						}
						else
						{
							EditorTool.Label("Add custom text codes in 'UI > Text Codes'");
						}
					}
					// data
					else if(this.buttonMode == optionsOffset + 1)
					{
						// data selector
						int tmp = this.dataMode;
						EditorTool.NoTitlePopup("Data", ref this.dataMode, EditorTextAreaControl.dataOptions, "", "", baseEditor);

						if(tmp != this.dataMode ||
							this.textCodeData == null)
						{
							List<TextCodeAttribute> textCodes = EditorDataHandler.Instance.TextCodes;
							if(this.dataMode >= 0 &&
								this.dataMode < textCodes.Count)
							{
								this.dataNames = EditorDataHandler.Instance.GetNames(textCodes[this.dataMode].assetType, true).ToArray();
								this.textCodeData = textCodes[this.dataMode];
							}
							else
							{
								this.dataNames = new string[0];
								this.textCodeData = null;
							}
						}

						if(this.textCodeData != null)
						{
							EditorTool.NoTitlePopup("Data", ref this.subData, this.dataNames,
								"Select the data that will be used.", "", baseEditor);
							EditorTool.NoTitlePopup("Data Type", ref this.subMode, this.textCodeData.options,
								"Select the content type of that will be added.", "", baseEditor);

							if(this.textCodeData.IsSubContent(this.subMode))
							{
								IMakinomGenericAsset asset = EditorDataHandler.Instance.GetAssetAtIndex(this.textCodeData.assetType, this.subData);
								EditorTool.NoTitlePopup("Data", ref this.subDataIndex, asset.GetEditorSubDataNames(),
									"Select the sub data that will be used.", "", baseEditor);
							}
							if(this.textCodeData.IsCustomContent(this.subMode))
							{
								GUILayout.FlexibleSpace();
								EditorGUILayout.EndHorizontal();
								EditorGUILayout.BeginHorizontal();
								this.customContentKey = EditorGUILayout.TextField("Custom Content Key", this.customContentKey, EditorTool.WIDTH);
							}

							if(EditorTool.MicroButton2("Add", "Add the selected data content.", ""))
							{
								this.AddSubDataSettings();
							}
						}
					}
					// variable
					else if(this.buttonMode == optionsOffset + 2)
					{
						EditorTool.NoTitlePopup("Variable Type", ref this.subMode, EditorTextAreaControl.variableOptions,
							"Select the type of the variable that should be added.\n" +
							"Use the next field to input the variable key.", "", baseEditor);
						this.gvKey = EditorGUILayout.TextField(this.gvKey, EditorTool.WIDTH_150);
						if(this.subMode == 3 || this.subMode == 6)
						{
							GUILayout.FlexibleSpace();
							EditorGUILayout.EndHorizontal();
							EditorGUILayout.BeginHorizontal();
							this.floatFormat = EditorGUILayout.TextField("Format", this.floatFormat, EditorTool.WIDTH);
						}
						if(this.gvKey != "" && EditorTool.MicroButton2("Add", "Add the selected variable.", ""))
						{
							if(this.subMode == 0)
							{
								this.InsertText(TextCode.VariableString + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 1)
							{
								this.InsertText(TextCode.VariableBool + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 2)
							{
								this.InsertText(TextCode.VariableInt + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 3)
							{
								this.InsertText(TextCode.VariableCustomInt + this.gvKey +
									TextCode.FormatSeparator + this.floatFormat + TextCode.CloseTag);
							}
							else if(this.subMode == 4)
							{
								this.InsertText(TextCode.VariableFloat + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 5)
							{
								this.InsertText(TextCode.VariableIFloat + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 6)
							{
								this.InsertText(TextCode.VariableCustomFloat + this.gvKey +
									TextCode.FormatSeparator + this.floatFormat + TextCode.CloseTag);
							}
							else if(this.subMode == 7)
							{
								this.InsertText(TextCode.VariableVector3 + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 8)
							{
								this.InsertText(TextCode.VariableVector3X + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 9)
							{
								this.InsertText(TextCode.VariableVector3Y + this.gvKey + TextCode.CloseTag);
							}
							else if(this.subMode == 10)
							{
								this.InsertText(TextCode.VariableVector3Z + this.gvKey + TextCode.CloseTag);
							}
						}
					}
					// actor
					else if(this.buttonMode == optionsOffset + 3)
					{
						EditorTool.NoTitlePopup("Actor", ref this.subData, baseEditor.GetPopupList(0),
							"Select the actor should be used.", "", baseEditor);

						EditorTool.NoTitlePopup("Data Type", ref this.subMode, EditorTextAreaControl.actorSubOptions,
							"Select the type of the data that should be added.\n" +
							"Description and icon are also only available for actors with a 'Scene Object' component.", "", baseEditor);

						if(this.subMode == 4 || subMode == 9)
						{
							GUILayout.FlexibleSpace();
							EditorGUILayout.EndHorizontal();
							EditorGUILayout.BeginHorizontal();
							this.customContentKey = EditorGUILayout.TextField("Custom Content Key", this.customContentKey, EditorTool.WIDTH);
						}

						if(EditorTool.MicroButton2("Add", "Add the selected actor data.", ""))
						{
							this.AddActorData(TextCode.ActorName, TextCode.ActorShortName,
								TextCode.ActorDescription, TextCode.ActorIcon, TextCode.ActorCustomContent,
								TextCode.ActorTypeName, TextCode.ActorTypeShortName,
								TextCode.ActorTypeDescription, TextCode.ActorTypeIcon, TextCode.ActorTypeCustomContent);
						}
					}

					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}

				EditorGUILayout.Separator();


				this.scroll = EditorGUILayout.BeginScrollView(this.scroll, GUILayout.Height(Maki.EditorSettings.textAreaHeight));
				GUI.SetNextControlName(content.text);

				int pPos = 0;
				TextEditor editor = null;
				if((Event.current.keyCode == KeyCode.Return ||
						Event.current.type == EventType.Repaint) &&
					GUI.GetNameOfFocusedControl() == content.text)
				{
					editor = EditorReflection.Instance.GetTextEditor();
					if(editor != null)
					{
						pPos = editor.cursorIndex;
					}
				}

				GUIStyle textStyle = new GUIStyle(EditorContent.Instance.TextAreaStyle);
				if(Maki.EditorSettings.setTextAreaColor)
				{
					textStyle.normal.textColor = Maki.EditorSettings.textAreaColor;
					textStyle.active.textColor = Maki.EditorSettings.textAreaColor;
					textStyle.focused.textColor = Maki.EditorSettings.textAreaColor;
					textStyle.hover.textColor = Maki.EditorSettings.textAreaColor;
				}
				this.editingText = EditorGUILayout.TextArea(this.editingText, textStyle);
				EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);

				if((Event.current.keyCode == KeyCode.Return ||
						Event.current.type == EventType.Repaint) &&
					GUI.GetNameOfFocusedControl() == content.text)
				{
					if(editor == null)
					{
						editor = EditorReflection.Instance.GetTextEditor();
					}
					if(editor != null)
					{
						editor.text = this.editingText;
						if(this.updateSelections)
						{
							this.updateSelections = false;
							editor.cursorIndex = this.selectionStart;
							editor.selectIndex = this.selectionEnd;
						}

						if(pPos != editor.cursorIndex || Event.current.keyCode == KeyCode.Return)
						{
							if(editor.graphicalCursorPos.y < this.scroll.y + textStyle.lineHeight)
							{
								this.scroll.y = editor.graphicalCursorPos.y - 20;
							}
							else if(editor.graphicalCursorPos.y > this.scroll.y + 90)
							{
								this.scroll.y = editor.graphicalCursorPos.y - 70;
							}
							baseEditor.Repaint();
						}

						// update selections in control
						if(editor.cursorIndex < editor.selectIndex)
						{
							this.selectionStart = editor.cursorIndex;
							this.selectionEnd = editor.selectIndex;
						}
						else
						{
							this.selectionStart = editor.selectIndex;
							this.selectionEnd = editor.cursorIndex;
						}
					}
				}
				EditorGUILayout.EndScrollView();
			}
			else
			{
				// name and start editing
				EditorGUILayout.BeginHorizontal();
				EditorTool.BoldLabel(content);
				EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
				if(EditorTool.SmallButton2(new GUIContent("Edit Text", EditorContent.Instance.EditIcon), "Edit this text.", ""))
				{
					this.isEditing = true;
					this.editingText = this.text.text;
				}
				if(EditorTool.MicroButton2("Copy", "Copy this text to the clipboard.", ""))
				{
					EditorGUIUtility.systemCopyBuffer = this.text.text;
				}
				if(EditorGUIUtility.systemCopyBuffer != "" &&
					EditorTool.MicroButton2("Paste", "Paste a text from the clipboard.", ""))
				{
					this.text.text = EditorGUIUtility.systemCopyBuffer;
					EditorTextAreaControl.CheckAssetReferences(ref this.text);
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				GUIStyle tmp = new GUIStyle(EditorContent.Instance.BoxTextAreaStyle);
				if(Maki.EditorSettings.setTextAreaColor)
				{
					tmp.normal.textColor = Maki.EditorSettings.textAreaColor;
				}
				else
				{
					tmp.normal.textColor = EditorStyles.label.normal.textColor;
				}
				tmp.wordWrap = true;
				tmp.clipping = TextClipping.Clip;
				tmp.alignment = TextAnchor.UpperLeft;

				float height = Mathf.Ceil(tmp.CalcHeight(new GUIContent(this.text.text), this.lastWidth));
				GUILayout.Label(this.text.text, tmp, GUILayout.ExpandWidth(true),
					GUILayout.Height(Mathf.Min(height, Maki.EditorSettings.textAreaPreviewHeight)));
				if(Event.current.type == EventType.Repaint)
				{
					this.lastWidth = GUILayoutUtility.GetLastRect().width;
				}
				if(!this.isEditing &&
					Event.current.type == EventType.MouseDown &&
					Event.current.button == 0 &&
					Event.current.clickCount == 2 &&
					GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition))
				{
					this.isEditing = true;
					this.editingText = this.text.text;
					Event.current.Use();
					baseEditor.Repaint();
				}
				EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			}
			EditorGUILayout.EndVertical();
		}

		private float lastWidth = 100;

		public static void CheckAssetReferences(ref TextContent text)
		{
			text.ClearAssetReferences();

			if(text.text.Contains("<"))
			{
				string tmpText = text.text;

				List<TextCodeAttribute> textCodes = EditorDataHandler.Instance.TextCodes;
				for(int i = 0; i < textCodes.Count; i++)
				{
					if(text.text.Contains(textCodes[i].baseTextCode))
					{
						for(int j = 0; j < textCodes[i].textCodes.Length; j++)
						{
							if(textCodes[i].IsSubContent(j))
							{
								string guid = TextHelper.NextSpecialString(ref tmpText, textCodes[i].textCodes[j], TextCode.SubData, 0);
								while(guid != "")
								{
									IMakinomGenericAsset asset = EditorDataHandler.Instance.GetAssetForGUID(textCodes[i].assetType, guid);
									if(asset != null)
									{
										text.AddAssetReference(asset);
									}
									tmpText = tmpText.Replace(
										textCodes[i].textCodes[j] + guid + TextCode.SubData,
										"");
									guid = TextHelper.NextSpecialString(ref tmpText, textCodes[i].textCodes[j], TextCode.SubData, 0);
								}
							}
							else if(textCodes[i].IsCustomContent(j))
							{
								string guid = TextHelper.NextSpecialString(ref tmpText, textCodes[i].textCodes[j], TextCode.CustomContent, 0);
								while(guid != "")
								{
									IMakinomGenericAsset asset = EditorDataHandler.Instance.GetAssetForGUID(textCodes[i].assetType, guid);
									if(asset != null)
									{
										text.AddAssetReference(asset);
									}
									tmpText = tmpText.Replace(
										textCodes[i].textCodes[j] + guid + TextCode.CustomContent,
										"");
									guid = TextHelper.NextSpecialString(ref tmpText, textCodes[i].textCodes[j], TextCode.CustomContent, 0);
								}
							}
							else
							{
								string guid = TextHelper.NextSpecialString(ref tmpText, textCodes[i].textCodes[j], 0);
								while(guid != "")
								{
									IMakinomGenericAsset asset = EditorDataHandler.Instance.GetAssetForGUID(textCodes[i].assetType, guid);
									if(asset != null)
									{
										text.AddAssetReference(asset);
									}
									tmpText = tmpText.Replace(
										textCodes[i].textCodes[j] + guid + TextCode.CloseTag,
										"");
									guid = TextHelper.NextSpecialString(
										ref tmpText, textCodes[i].textCodes[j], 0);
								}
							}
						}
					}
				}
			}
		}
	}
}
