﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class GeneralSelectionPopup : BaseSelectionPopup
	{
		private NotifyInt selectCallback;

		public GeneralSelectionPopup(string name, int selectedIndex,
			string[] items, string[] descriptions, string favoriteInfo,
			float activatorHeight, Vector2 callPosition, Rect callBounds,
			NotifyInt selectCallback, Notify closeCallback, BaseEditor baseEditor)
		{
			this.selectedIndex = selectedIndex;
			this.selectCallback = selectCallback;
			this.Init(BaseSelectionPopup.WIDTH, activatorHeight, name,
				this.CreateTree(items, descriptions, favoriteInfo), callPosition, callBounds, closeCallback, baseEditor);
		}

		protected virtual List<Element> CreateTree(string[] items, string[] descriptions, string favoriteInfo)
		{
			List<Element> tree = new List<Element>();
			Dictionary<string, Element> lookup = new Dictionary<string, Element>();
			for(int i = 0; i < items.Length; i++)
			{
				Element element = null;
				if(items[i].Contains("/"))
				{
					string[] types = items[i].Split('/');
					string typeName = "";
					Element parent = null;
					for(int j = 0; j < types.Length - 1; j++)
					{
						if(j > 0)
						{
							typeName += "/";
						}
						typeName += types[j];
						if(!lookup.TryGetValue(typeName, out parent))
						{
							if(this.selectedIndex >= tree.Count)
							{
								this.selectedIndex++;
							}
							parent = new TypeElement(types[j], "", parent, this);
							lookup.Add(typeName, parent);
							tree.Add(parent);
						}
					}
					element = new ItemElement(this, i, types[types.Length - 1], descriptions != null ? descriptions[i] : "", parent);
				}
				else
				{
					element = new ItemElement(this, i, items[i], descriptions != null ? descriptions[i] : "", null);
				}
				if(element != null)
				{
					if(favoriteInfo != null)
					{
						element.FavoriteInformation = favoriteInfo + ":" + items[i];
					}
					tree.Add(element);
				}
			}
			return tree;
		}


		/*
		============================================================================
		Element classes
		============================================================================
		*/
		public class ItemElement : Element
		{
			private GeneralSelectionPopup callPopup;

			private int index = -1;

			public ItemElement(GeneralSelectionPopup popup, int index, string name, string description, Element parent) : base(name, description, parent)
			{
				this.callPopup = popup;
				this.popup = popup;
				this.index = index;
			}

			public override void Accepted()
			{
				if(this.callPopup.selectCallback != null)
				{
					this.callPopup.selectCallback(this.index);
				}
				this.popup.Close();
			}

			public override object Value
			{
				get { return this.index; }
			}

			public override bool CheckValue(object value)
			{
				return this.index.Equals(value);
			}
		}
	}
}
