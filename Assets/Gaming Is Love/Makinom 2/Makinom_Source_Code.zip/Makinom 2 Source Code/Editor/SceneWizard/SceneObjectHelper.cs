
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.Makinom.Editor
{
	public static class SceneObjectHelper
	{
		public static void SetNextSceneID<T>(T target) where T : Behaviour, ISceneID
		{
			target.SceneID = -1;
#if Unity_2019
			T[] sceneID = GameObject.FindObjectsOfType<T>();
#else
			T[] sceneID = GameObject.FindObjectsByType<T>(FindObjectsSortMode.None);
#endif
			for(int i = 0; i < sceneID.Length; i++)
			{
				if(sceneID[i].UseSceneID &&
					target.SceneID <= sceneID[i].SceneID)
				{
					target.SceneID = sceneID[i].SceneID + 1;
				}
			}
			EditorSceneManager.MarkAllScenesDirty();
		}

		public static void ResetAllSceneIDs<T>() where T : Behaviour, ISceneID
		{
			int id = 0;
#if Unity_2019
			T[] sceneID = GameObject.FindObjectsOfType<T>();
#else
			T[] sceneID = GameObject.FindObjectsByType<T>(FindObjectsSortMode.None);
#endif
			for(int i = 0; i < sceneID.Length; i++)
			{
				if(sceneID[i].UseSceneID)
				{
					sceneID[i].SceneID = id++;
				}
			}
			EditorSceneManager.MarkAllScenesDirty();
		}

		public static T Create<T>(string name) where T : Behaviour, ISceneID
		{
			GameObject gameObject = new GameObject(name);
			if(Selection.activeGameObject != null)
			{
				GameObjectUtility.SetParentAndAlign(gameObject, Selection.activeGameObject);
			}
			T t = gameObject.AddComponent<T>();
			SceneObjectHelper.SetNextSceneID(t);
			t.gameObject.name += " " + t.SceneID;
			SceneObjectHelper.PlaceObject(t.transform);
			Selection.objects = new Object[] { t.gameObject };
			Undo.RegisterCreatedObjectUndo(gameObject, "Create " + name);
			return t;
		}

		public static T CreateSimple<T>(string name) where T : Component
		{
			GameObject gameObject = new GameObject(name);
			if(Selection.activeGameObject != null)
			{
				GameObjectUtility.SetParentAndAlign(gameObject, Selection.activeGameObject);
			}
			T t = gameObject.AddComponent<T>();
			SceneObjectHelper.PlaceObject(t.transform);
			Selection.objects = new Object[] { t.gameObject };
			Undo.RegisterCreatedObjectUndo(gameObject, "Create " + name);
			return t;
		}

		public static List<T> AddToSelection<T>() where T : Behaviour, ISceneID
		{
			List<T> list = new List<T>();
			foreach(GameObject gameObject in Selection.objects)
			{
				if(gameObject != null)
				{
					T t = gameObject.AddComponent<T>();
					SceneObjectHelper.SetNextSceneID(t);
					list.Add(t);
				}
			}
			return list;
		}

		public static List<T> AddToSelectionSimple<T>() where T : Component
		{
			List<T> list = new List<T>();
			foreach(GameObject gameObject in Selection.objects)
			{
				if(gameObject != null)
				{
					T t = gameObject.AddComponent<T>();
					list.Add(t);
				}
			}
			return list;
		}

		public static void PlaceObject(Transform transform)
		{
			if(Selection.transforms.Length > 0)
			{
				transform.position = TransformHelper.GetCenterPosition(new List<Transform>(Selection.transforms));
			}
			else if(SceneView.lastActiveSceneView != null &&
				SceneView.lastActiveSceneView.camera != null)
			{
				Ray ray = SceneView.lastActiveSceneView.camera.ScreenPointToRay(
						SceneView.lastActiveSceneView.camera.ViewportToScreenPoint(new Vector3(0.5f, 0.5f, -10)));
				RaycastOutput hit;
				if(RaycastHelper.Raycast(RaycastType.First3D, ray.origin, ray.direction, out hit))
				{
					transform.position = hit.point;
				}
				else
				{
					transform.position = SceneView.lastActiveSceneView.camera.
						ViewportToWorldPoint(new Vector3(0.5f, 0.5f, -10));
				}
			}
			if(SceneView.lastActiveSceneView)
			{
				SceneView.lastActiveSceneView.LookAt(transform.position);
				SceneView.lastActiveSceneView.Focus();
			}
		}
	}
}
