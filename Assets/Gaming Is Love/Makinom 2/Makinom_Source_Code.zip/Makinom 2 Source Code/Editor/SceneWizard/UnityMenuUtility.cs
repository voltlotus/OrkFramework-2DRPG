﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public static class UnityMenuUtility
	{
		/*
		============================================================================
		Game object functions
		============================================================================
		*/
		[MenuItem("GameObject/Makinom/Game Starter", false, 21)]
		public static GameStarter CreateGameStarter()
		{
			GameStarter gameStarter = SceneObjectHelper.CreateSimple<GameStarter>("Game Starter");
			gameStarter.project = MakinomAssetHelper.LoadProjectAsset();
			return gameStarter;
		}

		[MenuItem("GameObject/Makinom/Music Player", false, 21)]
		public static MusicPlayer CreateMusicPlayer()
		{
			MusicPlayer musicPlayer = SceneObjectHelper.CreateSimple<MusicPlayer>("Music Player");
			musicPlayer.gameObject.layer = 2;
			return musicPlayer;
		}

		[MenuItem("GameObject/Makinom/Music Player (2D)", false, 21)]
		public static MusicPlayer CreateMusicPlayer2D()
		{
			MusicPlayer musicPlayer = SceneObjectHelper.CreateSimple<MusicPlayer>("Music Player");
			CircleCollider2D collider = musicPlayer.gameObject.AddComponent<CircleCollider2D>();
			collider.radius = 5f;
			collider.isTrigger = true;
			musicPlayer.gameObject.layer = 2;
			musicPlayer.startSettings.DisableAll();
			musicPlayer.startSettings.triggerStartSetting.isTriggerEnter = true;
			return musicPlayer;
		}

		[MenuItem("GameObject/Makinom/Music Player (3D)", false, 21)]
		public static MusicPlayer CreateMusicPlayer3D()
		{
			MusicPlayer musicPlayer = SceneObjectHelper.CreateSimple<MusicPlayer>("Music Player");
			SphereCollider collider = musicPlayer.gameObject.AddComponent<SphereCollider>();
			collider.radius = 5f;
			collider.isTrigger = true;
			musicPlayer.gameObject.layer = 2;
			musicPlayer.startSettings.DisableAll();
			musicPlayer.startSettings.triggerStartSetting.isTriggerEnter = true;
			return musicPlayer;
		}

		[MenuItem("GameObject/Makinom/Pool", false, 21)]
		public static PoolComponent CreatePool()
		{
			PoolComponent pool = SceneObjectHelper.CreateSimple<PoolComponent>("Pool");
			return pool;
		}

		[MenuItem("GameObject/Makinom/Camera Event", false, 21)]
		public static CameraEvent CreateCameraEvent()
		{
			CameraEvent cameraEvent = SceneObjectHelper.CreateSimple<CameraEvent>("Camera Event");
			SphereCollider collider = cameraEvent.gameObject.AddComponent<SphereCollider>();
			collider.radius = 5f;
			collider.isTrigger = true;
			cameraEvent.gameObject.layer = 2;
			return cameraEvent;
		}

		[MenuItem("GameObject/Makinom/Scene Changer (2D)", false, 21)]
		public static SceneChanger CreateSceneChanger2D()
		{
			SceneChanger sceneChanger = SceneObjectHelper.CreateSimple<SceneChanger>("Scene Changer");
			sceneChanger.settings.target[0].positionType = SceneTargetType.SpawnID;
			sceneChanger.settings.target[0].spawnID = new FloatValue<GameObjectSelection>(0);
			CircleCollider2D collider = sceneChanger.gameObject.AddComponent<CircleCollider2D>();
			collider.radius = 5f;
			collider.isTrigger = true;
			sceneChanger.gameObject.layer = 2;
			return sceneChanger;
		}

		[MenuItem("GameObject/Makinom/Scene Changer (3D)", false, 21)]
		public static SceneChanger CreateSceneChanger3D()
		{
			SceneChanger sceneChanger = SceneObjectHelper.CreateSimple<SceneChanger>("Scene Changer");
			sceneChanger.settings.target[0].positionType = SceneTargetType.SpawnID;
			sceneChanger.settings.target[0].spawnID = new FloatValue<GameObjectSelection>(0);
			SphereCollider collider = sceneChanger.gameObject.AddComponent<SphereCollider>();
			collider.radius = 5f;
			collider.isTrigger = true;
			sceneChanger.gameObject.layer = 2;
			return sceneChanger;
		}

		[MenuItem("GameObject/Makinom/Spawn Point", false, 21)]
		public static SpawnPoint CreateSpawnPoint()
		{
			return SceneObjectHelper.Create<SpawnPoint>("Spawn Point");
		}

		[MenuItem("GameObject/Makinom/Waypoint Path", false, 21)]
		public static WaypointPathComponent CreateWaypointPath()
		{
			return SceneObjectHelper.CreateSimple<WaypointPathComponent>("Path");
		}

		[MenuItem("GameObject/Makinom/Interaction Controller (2D)", false, 21)]
		public static InteractionController CreateInteractionController2D()
		{
			InteractionController interactionController = SceneObjectHelper.CreateSimple<InteractionController>("Interaction Controller (2D)");
			BoxCollider2D collider = interactionController.gameObject.AddComponent<BoxCollider2D>();
			collider.size = new Vector2(1, 2);
			collider.isTrigger = true;
			interactionController.gameObject.layer = 2;
			Rigidbody2D rigidbody = interactionController.gameObject.AddComponent<Rigidbody2D>();
			rigidbody.gravityScale = 0;
			rigidbody.isKinematic = true;
			rigidbody.constraints = RigidbodyConstraints2D.FreezeAll;
			return interactionController;
		}

		[MenuItem("GameObject/Makinom/Interaction Controller (3D)", false, 21)]
		public static InteractionController CreateInteractionController3D()
		{
			InteractionController interactionController = SceneObjectHelper.CreateSimple<InteractionController>("Interaction Controller (3D)");
			BoxCollider collider = interactionController.gameObject.AddComponent<BoxCollider>();
			collider.size = new Vector3(1.5f, 2, 1);
			collider.isTrigger = true;
			interactionController.gameObject.layer = 2;
			Rigidbody rigidbody = interactionController.gameObject.AddComponent<Rigidbody>();
			rigidbody.useGravity = false;
			rigidbody.isKinematic = true;
			rigidbody.constraints = RigidbodyConstraints.FreezeAll;
			return interactionController;
		}
	}
}
