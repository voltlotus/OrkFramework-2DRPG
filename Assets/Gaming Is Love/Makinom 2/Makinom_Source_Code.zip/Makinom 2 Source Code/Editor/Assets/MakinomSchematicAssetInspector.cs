
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MakinomSchematicAsset))]
public class MakinomSchematicAssetInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		if(GUILayout.Button("Edit Schematic"))
		{
			MakinomEditorWindow.ShowMakinomEditor((GamingIsLove.Makinom.MakinomSchematicAsset)target, null);
		}

		EditorGUILayout.Separator();
		GUILayout.Label("Save Time: " + ((MakinomSchematicAsset)target).SaveTime);
		GUILayout.Label("Version: " + ((MakinomSchematicAsset)target).Version);
	}
}
