
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class VariablesTab : BaseEditorTab
	{
		// replace
		protected string oldKey = "";

		protected string newKey = "";

		protected bool replaceInSettings = true;

		protected bool replaceInScenes = true;

		protected bool replaceOnPrefabs = true;

		protected bool replaceInSchematics = true;


		// schematic
		private string schematicFolder = "";

		public VariablesTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Variables"; }
		}

		public override string HelpText
		{
			get
			{
				return "Show all variable keys defined in your project.\n" +
					"You can also define variable keys to add them to popup lists, but this isn't required to use them.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/variables/"; }
		}

		protected override BaseSettings Settings
		{
			get { return null; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return null; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void ShowTab()
		{
			this.ClearShow();

			EditorGUILayout.BeginHorizontal();

			this.BeforeSettings();

			EditorGUILayout.BeginVertical();
			this.BeforeScrollView();
			this.SettingsScroll = EditorGUILayout.BeginScrollView(this.SettingsScroll);
			this.ShowSettings();
			this.CloseAllFoldouts();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndScrollView();
			this.AfterScrollView();
			EditorGUILayout.EndVertical();

			this.AfterSettings();

			EditorGUILayout.EndHorizontal();
		}

		public override void ShowSettings()
		{
			// replace variables
			if(this.BeginFoldout("Replace Variable Key", "Replace a variable key.", "", true))
			{
				EditorTool.ExpandedTextField("Old Variable Key", ref this.oldKey, "The old variable key that will be replaced.", "");
				EditorTool.ExpandedTextField("New Variable Key", ref this.newKey, "The new variable key that will be used.", "");

				EditorGUILayout.Separator();
				this.replaceInSettings = EditorGUILayout.Toggle("Replace In Settings", this.replaceInSettings);
				this.replaceInScenes = EditorGUILayout.Toggle("Replace In Scenes", this.replaceInScenes);
				this.replaceOnPrefabs = EditorGUILayout.Toggle("Replace On Prefabs", this.replaceOnPrefabs);
				this.replaceInSchematics = EditorGUILayout.Toggle("Replace In Schematics", this.replaceInSchematics);
				if(this.replaceInSchematics)
				{
					EditorTool.ExpandedTextField("Folder (in Assets)", ref this.schematicFolder,
					   "You can optionally only replace in schematics in a defined folder in the Assets path.", "");
				}

				EditorGUILayout.Separator();
				EditorGUI.BeginDisabledGroup(this.oldKey == "" || this.newKey == "" ||
					(!this.replaceInSettings && !this.replaceInScenes &&
						!this.replaceOnPrefabs && !this.replaceInSchematics));
				if(EditorTool.Button(new GUIContent("Replace", EditorContent.Instance.AddIcon),
					"Replaces the variable key in the defined settings.", ""))
				{
					if(!this.replaceInScenes ||
						EditorUtility.DisplayDialog("Replace In All Scenes", "Replaces the variable key in all scenes added to Unity's build settings.\n" +
							"Please save your current scene before replacing, or the changes you made without saving will be lost.",
							"Replace", "Cancel"))
					{
						EditorVariables.Instance.ReplaceVariable(this.oldKey, this.newKey,
							this.replaceInSettings, this.replaceInScenes, this.replaceOnPrefabs,
							this.replaceInSchematics, this.schematicFolder);
						this.Editor.Focus();
					}
				}
				EditorGUI.EndDisabledGroup();

				EditorGUILayout.Separator();
			}
			this.EndFoldout();

			// define variables
			if(this.BeginFoldout("Define Variables", "Define variables.\n" +
				"You can select defined variables in variable fields in the editor.", "", true))
			{
				if(EditorTool.Button(new GUIContent("Add Variable", EditorContent.Instance.AddIcon),
					"Adds a variable to the list.", ""))
				{
					EditorVariables.Instance.defined.Add("new");
				}

				EditorGUILayout.Separator();
				for(int i = 0; i < EditorVariables.Instance.defined.Count; i++)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.SmallButton(new GUIContent("Remove", EditorContent.Instance.RemoveIcon),
						"Removes this defined variable.", ""))
					{
						EditorVariables.Instance.defined.RemoveAt(i--);
						continue;
					}

					EditorVariables.Instance.defined[i] = EditorGUILayout.TextField(
						EditorVariables.Instance.defined[i], EditorTool.WIDTH_DOUBLE);

					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}

				EditorGUILayout.Separator();
			}
			this.EndFoldout();

			// editor variables
			if(this.BeginFoldout("Editor Variables", "Variables defined elsewhere in the Makinom editor.\n" +
				"You can select variables in variable fields in the editor.", "", true))
			{
				if(EditorTool.Button("Scan All Settings",
					"Scans all settings in the Makinom editor for variables.", ""))
				{
					EditorVariables.Instance.UpdateSettings(true);
				}

				EditorGUILayout.Separator();
				for(int i = 0; i < EditorVariables.Instance.foundEditor.Count; i++)
				{
					GUILayout.Label(EditorVariables.Instance.foundEditor[i]);
				}
				EditorGUILayout.Separator();
			}
			this.EndFoldout();

			// scene variables
			if(this.BeginFoldout("Scene Variables", "Variables defined in components in your scenes.\n" +
				"You can select variables in variable fields in the editor.", "", true))
			{
				if(EditorTool.Button("Scan All Scenes",
					"Scans all scenes added to the Unity build settings for variables.", ""))
				{
					if(EditorUtility.DisplayDialog("Scan All Scenes", "Scans all scenes added to Unity's build settings.\n" +
						"This will delete all previously scanned data and replace it with the new data.\n" +
						"Please save your current scene before scanning, or the changes you made without saving will be lost.",
						"Scan", "Cancel"))
					{
						EditorVariables.Instance.UpdateScenes();
					}
					this.Editor.Focus();
				}

				EditorGUILayout.Separator();
				for(int i = 0; i < EditorVariables.Instance.foundScene.Count; i++)
				{
					EditorTool.BoldLabel(EditorVariables.Instance.foundScene[i].sceneName);
					for(int j = 0; j < EditorVariables.Instance.foundScene[i].variables.Count; j++)
					{
						GUILayout.Label(EditorVariables.Instance.foundScene[i].variables[j]);
					}
				}
				EditorGUILayout.Separator();
			}
			this.EndFoldout();

			// prefab variables
			if(this.BeginFoldout("Prefab Variables", "Variables defined in components on your prefabs.\n" +
				"You can select variables in variable fields in the editor.", "", true))
			{
				if(EditorTool.Button("Scan All Prefabs",
					"Scans all prefabs in your project for variables.", ""))
				{
					EditorVariables.Instance.UpdatePrefabs();
				}

				for(int i = 0; i < EditorVariables.Instance.foundPrefab.Count; i++)
				{
					EditorGUILayout.Separator();
					EditorTool.Label(EditorVariables.Instance.foundPrefab[i]);

					List<GameObject> prefabList;
					if(EditorVariables.Instance.keyPrefab.TryGetValue(EditorVariables.Instance.foundPrefab[i], out prefabList))
					{
						int count = 0;
						EditorGUI.BeginDisabledGroup(true);
						EditorGUILayout.BeginHorizontal();
						for(int j = 0; j < prefabList.Count; j++)
						{
							EditorGUILayout.ObjectField("", prefabList[j], typeof(GameObject), false, EditorTool.WIDTH_150);
							if(count == 2)
							{
								EditorGUILayout.EndHorizontal();
								EditorGUILayout.BeginHorizontal();
								count = 0;
							}
							else
							{
								count++;
							}
						}
						EditorGUILayout.EndHorizontal();
						EditorGUI.EndDisabledGroup();
					}
				}
				EditorGUILayout.Separator();
			}
			this.EndFoldout();

			// schematic variables
			if(this.BeginFoldout("Schematic Variables", "Variables defined in schematics.\n" +
				"You can select variables in variable fields in the editor.", "", true))
			{
				EditorTool.ExpandedTextField("Folder (in Assets)", ref this.schematicFolder,
					"You can optionally only scan schematics in a defined folder in the Assets path.", "");
				EditorGUILayout.HelpBox("Use the 'Scan All Schematics' button to list the schematic assets each variable key is used in.",
					MessageType.Info);
				if(EditorTool.Button("Scan All Schematics",
					"Scans all schematic asset files for variables and lists the schematics where a variable key is used.", ""))
				{
					EditorVariables.Instance.UpdateSchematics(this.schematicFolder);
				}

				for(int i = 0; i < EditorVariables.Instance.foundSchematic.Count; i++)
				{
					EditorGUILayout.Separator();
					EditorTool.Label(EditorVariables.Instance.foundSchematic[i]);

					List<MakinomSchematicAsset> assetList;
					if(EditorVariables.Instance.keySchematic.TryGetValue(EditorVariables.Instance.foundSchematic[i], out assetList))
					{
						int count = 0;
						EditorGUI.BeginDisabledGroup(true);
						EditorGUILayout.BeginHorizontal();
						for(int j = 0; j < assetList.Count; j++)
						{
							EditorGUILayout.ObjectField("", assetList[j], typeof(MakinomSchematicAsset), false, EditorTool.WIDTH_150);
							if(count == 2)
							{
								EditorGUILayout.EndHorizontal();
								EditorGUILayout.BeginHorizontal();
								count = 0;
							}
							else
							{
								count++;
							}
						}
						EditorGUILayout.EndHorizontal();
						EditorGUI.EndDisabledGroup();
					}
				}
				EditorGUILayout.Separator();
			}
			this.EndFoldout();
		}
	}
}
