
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class NodeInfo
	{
		public GUIContent content;

		public string info;

		public string[] subMenu;

		public NodeInfo(GUIContent content, string info, string[] subMenu)
		{
			this.content = content;
			this.info = info;
			this.subMenu = subMenu;
		}

		public virtual void ShowSubMenuInfo()
		{
			if(Maki.EditorSettings.showNodeFolderInfo &&
				this.subMenu.Length > 0)
			{
				string subMenus = this.subMenu[0];
				for(int j = 1; j < this.subMenu.Length; j++)
				{
					subMenus += ", " + this.subMenu[j];
				}
				subMenus = subMenus.Replace("/", " > ");
				EditorGUILayout.HelpBox(subMenus, MessageType.None);
			}
		}
	}
}
