
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class SceneObjectTypesTab : GenericAssetListTab<SceneObjectTypeAsset, SceneObjectType>
	{
		public SceneObjectTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Scene Object Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Use scene object types to separate scene objects.\n" +
					"The type content information can be displayed by HUDs or used in dialogues.\n" +
					"You can also change the cursor when it's above a game object of a certain scene object types.\n" +
					"Add a scene object to a game object in your scene using the 'Scene Object' component.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/scene-objects/"; }
		}
	}
}
