
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public class UISettingsTab : BaseEditorTab
	{
		public UISettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "UI Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up basic UI settings."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.UISettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.UISettings; }
		}


		/*
		============================================================================
		Settings functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].UISettings != null)
				{
					EditorAutomation.Automate(EditorContent.Extensions[i].UISettings, this);
				}
			}
		}
	}
}
