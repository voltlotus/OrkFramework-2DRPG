
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class BaseEditorSection
	{
		protected MakinomEditorWindow parent;

		protected List<BaseEditorTab> tabs = new List<BaseEditorTab>();

		protected int index = 0;

		protected Vector2 subScroll = Vector2.zero;

		protected Vector2 jumplistScroll = Vector2.zero;

		protected Vector2 generalJumplistScroll = Vector2.zero;

		public BaseEditorSection()
		{

		}

		public BaseEditorSection(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}

		public BaseEditorSection(MakinomEditorWindow parent, params BaseEditorTab[] tabs)
		{
			this.parent = parent;
			this.tabs.AddRange(tabs);
		}


		/*
		============================================================================
		Getters functions
		============================================================================
		*/
		public MakinomEditorWindow Editor
		{
			get { return this.parent; }
		}

		public virtual List<BaseEditorTab> Tabs
		{
			get { return this.tabs; }
		}

		public virtual BaseEditorTab CurrentTab
		{
			get
			{
				if(this.index < 0)
				{
					this.index = 0;
				}
				else if(this.index >= this.Tabs.Count)
				{
					this.index = this.Tabs.Count - 1;
				}
				return this.Tabs[this.index];
			}
		}

		public virtual int Index
		{
			get { return this.index; }
			set
			{
				this.index = value;
				if(this.index < 0)
				{
					this.index = 0;
				}
				else if(this.index >= this.Tabs.Count)
				{
					this.index = this.Tabs.Count - 1;
				}
			}
		}

		public virtual int TabIndex
		{
			get
			{
				if(this.index >= 0 && this.index < this.Tabs.Count)
				{
					return this.Tabs[this.index].Index;
				}
				return 0;
			}
			set
			{
				this.Tabs[this.index].Index = value;
			}
		}

		public virtual float TabYScroll
		{
			get
			{
				if(this.index >= 0 && this.index < this.Tabs.Count)
				{
					return this.Tabs[this.index].SettingsScroll.y;
				}
				return 0;
			}
			set
			{
				if(this.index >= 0 && this.index < this.Tabs.Count)
				{
					this.Tabs[this.index].SettingsScroll = new Vector2(0, value);
				}
			}
		}

		public virtual string TabFoldoutLimit
		{
			get
			{
				if(this.index >= 0 && this.index < this.Tabs.Count)
				{
					return this.Tabs[this.index].FoldoutLimit;
				}
				return "";
			}
			set
			{
				if(this.index >= 0 && this.index < this.Tabs.Count)
				{
					this.Tabs[this.index].FoldoutLimit = value;
				}
			}
		}


		/*
		============================================================================
		Show functions
		============================================================================
		*/
		public virtual void ShowSubsection()
		{
			this.subScroll = EditorGUILayout.BeginScrollView(this.subScroll);
			GUI.SetNextControlName("SubID");

			EditorTool.SelectionGrid(ref this.index, this.Tabs);

			GUILayout.FlexibleSpace();
			EditorGUILayout.EndScrollView();
		}

		public virtual void ShowTab()
		{
			this.Tabs[this.index].BeforeTab();
			this.Tabs[this.index].ShowTab();
			this.Tabs[this.index].AfterTab();
		}

		public virtual void ShowFoldoutJumpList(float height)
		{
			if(this.Tabs[this.index].IsGeneralSetting)
			{
				this.generalJumplistScroll = EditorGUILayout.BeginScrollView(this.generalJumplistScroll);
			}
			else
			{
				this.jumplistScroll = EditorGUILayout.BeginScrollView(this.jumplistScroll);
			}
			this.Tabs[this.index].ShowFoldoutJumpList(height);
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndScrollView();
		}

		public virtual void ShowAfterEditor()
		{
			if(this.index > 0 &&
				this.index < this.Tabs.Count)
			{
				this.Tabs[this.index].ShowAfterEditor();
			}
		}


		/*
		============================================================================
		Set functions
		============================================================================
		*/
		public virtual void SetIndex(int i, int j, float yScroll)
		{
			if(i >= 0 && i < this.Tabs.Count)
			{
				this.index = i;
				this.Tabs[this.index].Index = j;
				this.Tabs[this.index].SettingsScroll = new Vector2(0, yScroll);
			}
		}

		public virtual void Reloaded()
		{
			for(int i = 0; i < this.Tabs.Count; i++)
			{
				this.Tabs[i].Reloaded();
			}
		}

		public virtual void BeforeSaving()
		{
			for(int i = 0; i < this.Tabs.Count; i++)
			{
				this.Tabs[i].BeforeSaving();
			}
		}
	}
}
