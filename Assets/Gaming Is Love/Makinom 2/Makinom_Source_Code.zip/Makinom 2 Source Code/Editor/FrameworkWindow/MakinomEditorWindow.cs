
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using UnityEngine;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	/// <summary>
	/// Makinom editor window.
	/// Uses MakinomWindow class to open in Unity editor.
	/// </summary>
	public class MakinomEditorWindow : EditorWindow
	{
		protected enum EditorSplashScreenMode { None,
			Initialize, Loading, StartReload, Reloading,
			StartCheckChanges, CheckingChanges,
			StartChangeToSchematicSection, ChangingToSchematicSection,
			StartSave, Saving
		}

		protected static MakinomEditorWindow instance;

		protected bool reinitialize = false;

		protected ProjectSaveHandler saveHandler;

		protected MakinomFullViewEditor fullViewEditor;

		protected static Texture2D logoTexture;

		protected bool registeredChange = false;

		public bool blockScroll = false;

		public double lastClickTime = 0;

		protected EditorSplashScreenMode splashScreenMode = EditorSplashScreenMode.Initialize;


		// special opening opening
		protected MakinomProjectAsset loadProjectAsset;

		protected MakinomSchematicAsset schematicAsset;

		protected Schematic runtimeSchematic;


		// sections
		protected GUIContent[] sectionHeaders;

		protected GUIContent[] sectionHeadersIconOnly;

		protected int index = 0;

		protected int indexShort = -1;

		protected BaseEditorSection[] sections;

		public bool checkBackups = true;

		protected Vector2 helpScroll = Vector2.zero;


		// search
		protected SearchField searchField;

		protected string search = "";

		protected List<SectionChange> searchList = new List<SectionChange>();

		protected Vector2 searchScroll = Vector2.zero;


		/*
		============================================================================
		Call functions
		============================================================================
		*/
		[MenuItem("Window/Gaming Is Love/Makinom %&m", false, 2501)]
		public static void ShowMakinomEditor()
		{
			instance = EditorWindow.GetWindow<MakinomEditorWindow>(false, "Makinom", true);
			instance.minSize = new Vector2(600, 400);
			if(!EditorApplication.isPlaying || !Maki.Initialized)
			{
				instance.InitEditor();
			}
			instance.Show();
		}

		[MenuItem("Window/Gaming Is Love/Makinom (Multi-Window) %&#m", false, 2502)]
		public static void ShowMakinomEditorMulti()
		{
			bool alreadyOpen = MakinomEditorWindow.instance != null;
			instance = EditorWindow.CreateInstance<MakinomEditorWindow>();
			instance.titleContent = new GUIContent("Makinom");
			instance.minSize = new Vector2(600, 400);
			if(!alreadyOpen &&
				(!EditorApplication.isPlaying || !Maki.Initialized))
			{
				instance.InitEditor();
			}
			instance.Show();

		}

		public static void ShowMakinomEditor(MakinomProjectAsset projectAsset)
		{
			instance = EditorWindow.GetWindow<MakinomEditorWindow>(false, "Makinom", true);
			instance.loadProjectAsset = projectAsset;
			instance.minSize = new Vector2(600, 400);
			if(!EditorApplication.isPlaying || !Maki.Initialized)
			{
				instance.InitEditor();
			}
			instance.Show();
		}

		public static void ShowMakinomEditor(GamingIsLove.Makinom.MakinomSchematicAsset schematicAsset, Schematic runtimeSchematic)
		{
			if(instance == null)
			{
				instance = EditorWindow.GetWindow<MakinomEditorWindow>(false, "Makinom", true);
				instance.LoadSchematicAsset(schematicAsset, runtimeSchematic);
				if(!EditorApplication.isPlaying || !Maki.Initialized)
				{
					instance.InitEditor();
				}
				instance.minSize = new Vector2(600, 400);
			}
			else if(instance.IsSchematicSection)
			{
				instance.LoadSchematicAsset(schematicAsset, runtimeSchematic);
				instance.LoadSchematicAsset();
				instance.Repaint();
				instance.Focus();
			}
			else
			{
				ProjectSaveHandler tmpSaveHandler = new ProjectSaveHandler(instance);
				if(tmpSaveHandler.HasChanges)
				{
					if(EditorUtility.DisplayDialog("Save Information",
						"Please save your changes first.", "Ok", "Cancel"))
					{
						instance.saveHandler = tmpSaveHandler;
						instance.Repaint();
					}
					instance.Focus();
				}
				else
				{
					instance.LoadSchematicAsset(schematicAsset, runtimeSchematic);
					instance.LoadSchematicAsset();
					instance.Repaint();
					instance.Focus();
				}
			}
			instance.Show();
		}

		public static MakinomEditorWindow Instance
		{
			get
			{
				if(instance == null)
				{
					MakinomEditorWindow.ShowMakinomEditor();
				}
				return instance;
			}
			set { instance = value; }
		}

		protected void InitEditor()
		{
			this.splashScreenMode = EditorSplashScreenMode.Initialize;
			this.reinitialize = true;
		}


		/*
		============================================================================
		Section change
		============================================================================
		*/
		public bool changeSection = false;

		public SectionChange change = new SectionChange();

		public SectionChange changeWatch;

		public List<SectionChange> changeHistory = new List<SectionChange>();

		public int historyIndex = 0;

		protected virtual T GetTabWithSeparator<T>(T tab) where T : BaseEditorTab
		{
			tab.AddSeparator = true;
			return tab;
		}

		protected virtual T GetTabWithSeparator<T>(T tab, string headerText) where T : BaseEditorTab
		{
			tab.AddSeparator = true;
			return tab;
		}

		public virtual void InitSections()
		{
			if(!Maki.Initialized || this.reinitialize)
			{
				if(!EditorApplication.isPlaying || !Maki.Initialized)
				{
					Maki.Initialize(this.loadProjectAsset != null ? this.loadProjectAsset : MakinomAssetHelper.LoadProjectAsset());
				}
				EditorDataHandler.DataHandlerLoaded();
				this.reinitialize = false;
				this.loadProjectAsset = null;
				this.sections = null;
			}

			if(this.sections == null)
			{
				LanguagesTab languages = new LanguagesTab(this);
				InputKeysTab inputKeys = new InputKeysTab(this);

				List<GUIContent> sectionHeaderList = new List<GUIContent>();
				List<BaseEditorSection> sectionList = new List<BaseEditorSection>();
				Dictionary<string, BaseEditorSection> sectionLookup = new Dictionary<string, BaseEditorSection>();

				// editor section
				sectionHeaderList.Add(new GUIContent("Editor", EditorContent.LoadImage(
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Editor.png", 32, 32)));
				BaseEditorSection tmpSection = new BaseEditorSection(this,
					new AboutTab(this), new EditorSettingsTab(this), new BackupsTab(this),
					new VariablesTab(this), new PluginsTab(this));
				sectionList.Add(tmpSection);
				sectionLookup.Add("Editor", tmpSection);

				// base/control section
				sectionHeaderList.Add(new GUIContent("Base/Control", EditorContent.LoadImage(
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Controls.png", 32, 32)));
				tmpSection = new BaseEditorSection(this,
					new GameControlsTab(this), inputKeys,
					this.GetTabWithSeparator(new SoundTypesTab(this)), new PortraitTypesTab(this), new MachineTypesTab(this),
					this.GetTabWithSeparator(new GlobalMachinesTab(this)), new PoolsTab(this), new PrefabSaversTab(this));
				sectionList.Add(tmpSection);
				sectionLookup.Add("Base/Control", tmpSection);

				// game section
				sectionHeaderList.Add(new GUIContent("Game", EditorContent.LoadImage(
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Game.png", 32, 32)));
				tmpSection = new BaseEditorSection(this,
					new GameSettingsTab(this), new GameStatesTab(this), languages,
					this.GetTabWithSeparator(new FormulaTypesTab(this)), new FormulasTab(this),
					this.GetTabWithSeparator(new CameraPositionsTab(this)), new MusicClipsTab(this),
					this.GetTabWithSeparator(new SceneObjectTypesTab(this)), new SceneObjectsTab(this),
					new SceneConnectionsTab(this));
				sectionList.Add(tmpSection);
				sectionLookup.Add("Game", tmpSection);

				// UI section
				sectionHeaderList.Add(new GUIContent("UI", EditorContent.LoadImage(
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.UI.png", 32, 32)));
				tmpSection = new BaseEditorSection(this,
					new UISystemSettingsTab(this), new UISettingsTab(this), new SaveGameSettingsTab(this),
					this.GetTabWithSeparator(new UILayersTab(this)), new UILayoutsTab(this), new UIBoxesTab(this),
					this.GetTabWithSeparator(new HUDsTab(this)),
					this.GetTabWithSeparator(new TextCodeSettingsTab(this)));
				sectionList.Add(tmpSection);
				sectionLookup.Add("UI", tmpSection);

				// template section
				sectionHeaderList.Add(new GUIContent("Templates", EditorContent.LoadImage(
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Templates.png", 32, 32)));
				tmpSection = new BaseEditorSection(this,
					new AnimationTemplatesTab(this), new SoundTemplatesTab(this), new MachineTemplatesTab(this),
					this.GetTabWithSeparator(new GeneralConditionTemplatesTab(this)), new GameStateConditionTemplatesTab(this),
					this.GetTabWithSeparator(new VariableChangeTemplatesTab(this)), new VariableConditionTemplatesTab(this));
				sectionList.Add(tmpSection);
				sectionLookup.Add("Templates", tmpSection);

				// extensions
				for(int i = 0; i < EditorContent.Extensions.Count; i++)
				{
					EditorContent.Extensions[i].GetSections(this, sectionHeaderList, sectionList, sectionLookup);
				}

				// schematic section
				sectionHeaderList.Add(new GUIContent("Schematics", EditorContent.LoadImage(
					"GamingIsLove.Makinom.Editor.Images.Icons.Sections.Schematics.png", 32, 32)));
				sectionList.Add(new SchematicsSection(this));

				this.sectionHeaders = sectionHeaderList.ToArray();
				this.sections = sectionList.ToArray();

				this.sectionHeadersIconOnly = new GUIContent[this.sectionHeaders.Length];
				for(int i = 0; i < this.sectionHeaders.Length; i++)
				{
					this.sectionHeadersIconOnly[i] = new GUIContent("", this.sectionHeaders[i].image, this.sectionHeaders[i].text);
				}

				this.LoadEditorSettings();
			}
		}


		/*
		============================================================================
		Docked check
		============================================================================
		*/
		public MethodInfo isDockedMethod;

		public virtual bool IsDocked
		{
			get
			{
				if(this.isDockedMethod == null)
				{
					this.isDockedMethod = typeof(MakinomEditorWindow).GetProperty("docked",
						BindingFlags.Public | BindingFlags.NonPublic |
						BindingFlags.Instance | BindingFlags.Static).GetGetMethod(true);
				}
				return (bool)this.isDockedMethod.Invoke(this, null);
			}
		}


		/*
		============================================================================
		Drag bar handling
		============================================================================
		*/
		public EditorDragData helpDrag = new EditorDragData();

		public EditorDragData subSectionDrag = new EditorDragData();

		public EditorDragData tabListDrag = new EditorDragData();

		public EditorDragData formulaDrag = new EditorDragData();

		public EditorDragData schematicDrag = new EditorDragData();

		public EditorDragData jumpListDrag = new EditorDragData();


		/// <summary>
		/// Restores the default drag widths and heights.
		/// </summary>
		public virtual void ResetDrags()
		{
			EditorDataHandler.Instance.EditorAsset.ResetDrags();
		}

		/// <summary>
		/// Displays and performs the tab list drag.
		/// </summary>
		public virtual void TabListDrag()
		{
			if(Maki.EditorSettings.enableDrag)
			{
				EditorTool.DragHorizontal(ref this.tabListDrag, false);
				if(this.tabListDrag.isDragging && this.tabListDrag.lastMove != 0)
				{
					EditorDataHandler.Instance.EditorAsset.TabListDrag += this.tabListDrag.lastMove;
					if(EditorDataHandler.Instance.EditorAsset.TabListDrag < 200)
					{
						EditorDataHandler.Instance.EditorAsset.TabListDrag = 200;
					}
					this.Repaint();
				}
			}
		}

		public virtual void FormulaDrag()
		{
			if(Maki.EditorSettings.enableDrag)
			{
				EditorTool.DragVertical(ref this.formulaDrag, false);
				if(this.formulaDrag.isDragging && this.formulaDrag.lastMove != 0)
				{
					EditorDataHandler.Instance.EditorAsset.FormulaDrag += this.formulaDrag.lastMove;
					if(EditorDataHandler.Instance.EditorAsset.FormulaDrag < 200)
					{
						EditorDataHandler.Instance.EditorAsset.FormulaDrag = 200;
					}
					this.Repaint();
				}
			}
		}

		public virtual void SchematicDrag(bool horizontal, bool inverse)
		{
			if(Maki.EditorSettings.enableDrag)
			{
				if(horizontal)
				{
					EditorTool.DragHorizontal(ref this.schematicDrag, inverse);
				}
				else
				{
					EditorTool.DragVertical(ref this.schematicDrag, inverse);
				}
				if(this.schematicDrag.isDragging && this.schematicDrag.lastMove != 0)
				{
					EditorDataHandler.Instance.EditorAsset.SchematicDrag += this.schematicDrag.lastMove;
					if(EditorDataHandler.Instance.EditorAsset.SchematicDrag < 200)
					{
						EditorDataHandler.Instance.EditorAsset.SchematicDrag = 200;
					}
					this.Repaint();
				}
			}
		}

		public virtual void HelpDrag()
		{
			if(Maki.EditorSettings.enableDrag)
			{
				EditorTool.DragVertical(ref this.helpDrag, false);
				if(this.helpDrag.isDragging && this.helpDrag.lastMove != 0)
				{
					EditorDataHandler.Instance.EditorAsset.HelpDrag += this.helpDrag.lastMove;
					if(EditorDataHandler.Instance.EditorAsset.HelpDrag < 50)
					{
						EditorDataHandler.Instance.EditorAsset.HelpDrag = 50;
					}
					this.Repaint();
				}
			}
		}

		public virtual void SubSectionDrag()
		{
			if(Maki.EditorSettings.enableDrag)
			{
				EditorTool.DragHorizontal(ref this.subSectionDrag, false);
				if(this.subSectionDrag.isDragging && this.subSectionDrag.lastMove != 0)
				{
					EditorDataHandler.Instance.EditorAsset.SubSectionDrag += this.subSectionDrag.lastMove;
					if(EditorDataHandler.Instance.EditorAsset.SubSectionDrag < 150)
					{
						EditorDataHandler.Instance.EditorAsset.SubSectionDrag = 150;
					}
					this.Repaint();
				}
			}
		}

		public virtual void JumpListDrag(bool inverse)
		{
			if(Maki.EditorSettings.enableDrag)
			{
				EditorTool.DragHorizontal(ref this.jumpListDrag, inverse);
				if(this.jumpListDrag.isDragging && this.jumpListDrag.lastMove != 0)
				{
					EditorDataHandler.Instance.EditorAsset.JumpListDrag += this.jumpListDrag.lastMove;
					if(EditorDataHandler.Instance.EditorAsset.JumpListDrag < 50)
					{
						EditorDataHandler.Instance.EditorAsset.JumpListDrag = 50;
					}
					this.Repaint();
				}
			}
		}


		/*
		============================================================================
		Getters/setters handling
		============================================================================
		*/
		public virtual bool ShowLogo()
		{
			if(logoTexture == null)
			{
				logoTexture = EditorContent.LoadImage("GamingIsLove.Makinom.Editor.Images.MakinomLogo.png", 300, 300);
			}
			if(logoTexture != null)
			{
				GUILayout.Label(logoTexture);
				return true;
			}
			return false;
		}


		/*
		============================================================================
		GUI handling
		============================================================================
		*/
		protected virtual void OnGUI()
		{
			if(EditorSplashScreenMode.None != this.splashScreenMode)
			{
				EditorGUILayout.BeginVertical();
				GUILayout.FlexibleSpace();


				EditorGUILayout.BeginHorizontal();
				GUILayout.FlexibleSpace();

				this.ShowLogo();

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();


				EditorTool.Separator(1);


				EditorGUILayout.BeginHorizontal();
				GUILayout.FlexibleSpace();

				if(EditorSplashScreenMode.Initialize == this.splashScreenMode ||
					EditorSplashScreenMode.Loading == this.splashScreenMode)
				{
					EditorTool.BoldLabel("Loading ...");
				}
				else if(EditorSplashScreenMode.StartReload == this.splashScreenMode ||
					EditorSplashScreenMode.Reloading == this.splashScreenMode)
				{
					EditorTool.BoldLabel("Reloading ...");
				}
				else if(EditorSplashScreenMode.StartCheckChanges == this.splashScreenMode ||
					EditorSplashScreenMode.CheckingChanges == this.splashScreenMode ||
					EditorSplashScreenMode.StartChangeToSchematicSection == this.splashScreenMode ||
					EditorSplashScreenMode.ChangingToSchematicSection == this.splashScreenMode)
				{
					EditorTool.BoldLabel("Checking for changes ...");
				}
				else if(EditorSplashScreenMode.StartSave == this.splashScreenMode ||
					EditorSplashScreenMode.Saving == this.splashScreenMode)
				{
					EditorTool.BoldLabel("Saving ...");
				}

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();


				GUILayout.FlexibleSpace();
				EditorGUILayout.EndVertical();

				if(Event.current.type == EventType.Repaint)
				{
					// init
					if(EditorSplashScreenMode.Initialize == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.Loading;
					}
					else if(EditorSplashScreenMode.Loading == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.None;

						this.InitSections();
					}
					// reload
					else if(EditorSplashScreenMode.StartReload == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.Reloading;
					}
					else if(EditorSplashScreenMode.Reloading == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.None;

						this.DoReloadData();
					}
					// check changes
					else if(EditorSplashScreenMode.StartCheckChanges == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.CheckingChanges;
					}
					else if(EditorSplashScreenMode.CheckingChanges == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.None;

						this.DoCheckChanges();
					}
					// check changes switching to schematic
					else if(EditorSplashScreenMode.StartChangeToSchematicSection == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.ChangingToSchematicSection;
					}
					else if(EditorSplashScreenMode.ChangingToSchematicSection == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.None;

						this.DoCheckChangesToSchematic();
					}
					// csave
					else if(EditorSplashScreenMode.StartSave == this.splashScreenMode)
					{
						this.splashScreenMode = this.saveHandler != null ? EditorSplashScreenMode.Saving : EditorSplashScreenMode.None;
					}
					else if(EditorSplashScreenMode.Saving == this.splashScreenMode)
					{
						this.splashScreenMode = EditorSplashScreenMode.None;

						if(this.saveHandler != null &&
							this.saveHandler.DoSave)
						{
							this.saveHandler.SaveData();
							this.saveHandler = null;
						}
					}
					this.Repaint();
				}
				return;
			}
			else if(this.sections == null)
			{
				this.InitSections();
			}

			if(!this.registeredChange)
			{
				this.LoadEditorSettings();

				if(this.schematicAsset != null)
				{
					this.LoadSchematicAsset();
				}
				this.registeredChange = true;
			}

			if(this.changeSection)
			{
				this.PerformSectionChange();
			}

			this.changeWatch = new SectionChange(new int[] {
					this.index,
					this.sections[this.index].Index,
					this.sections[this.index].TabIndex
				}, this.sections[this.index].TabYScroll);


			// custom full view
			if(this.fullViewEditor != null)
			{
				if(this.fullViewEditor.ShowGUI())
				{
					this.fullViewEditor = null;
					this.Repaint();
				}
			}
			// saving
			else if(this.saveHandler != null)
			{
				if(this.saveHandler.ShowGUI())
				{
					if(this.saveHandler.DoSave)
					{
						this.splashScreenMode = EditorSplashScreenMode.StartSave;
					}
					else
					{
						this.saveHandler = null;
					}
					this.Repaint();
				}
			}
			// Makinom editor
			else
			{
				bool doSave = false;
				bool doLoad = false;

				int historyChange = 0;

				int tmpSection = this.index;
				if(this.indexShort > -1)
				{
					this.index = this.indexShort;
					this.indexShort = -1;
				}

				// key handling
				Event e = Event.current;
				if(this.blockScroll &&
					EventType.ScrollWheel == e.type)
				{
					e.Use();
				}
				else if(EventType.KeyDown == e.type &&
					!e.control && !e.command && !e.shift)
				{
					if(e.alt)
					{
						if(e.keyCode == KeyCode.S && Maki.EditorSettings.saveHK)
						{
							doSave = true;
						}
						else if(e.keyCode == KeyCode.L && Maki.EditorSettings.loadHK)
						{
							doLoad = true;
						}
						// sub-section change
						if(Maki.EditorSettings.subHK)
						{
							if(e.keyCode == KeyCode.PageUp)
							{
								GUI.FocusControl("ListID");
								this.sections[this.index].Index -= 1;
								this.Repaint();
								return;
							}
							else if(e.keyCode == KeyCode.PageDown)
							{
								GUI.FocusControl("ListID");
								this.sections[this.index].Index += 1;
								this.Repaint();
								return;
							}
						}
						// navigation history
						if(Maki.EditorSettings.navigationHistoryHK)
						{
							if(e.keyCode == KeyCode.Home && this.historyIndex > 0)
							{
								historyChange = -1;
								this.Repaint();
							}
							else if(e.keyCode == KeyCode.End && this.historyIndex < this.changeHistory.Count)
							{
								historyChange = 1;
								this.Repaint();
							}
						}
					}
					else
					{
						// change tab index
						if(Maki.EditorSettings.tabHK)
						{
							if(e.keyCode == KeyCode.PageUp)
							{
								GUI.FocusControl("ListID");
								this.sections[this.index].TabIndex -= 1;
								this.Repaint();
								return;
							}
							else if(e.keyCode == KeyCode.PageDown)
							{
								GUI.FocusControl("ListID");
								this.sections[this.index].TabIndex += 1;
								this.Repaint();
								return;
							}
						}
						// scroll
						if(Maki.EditorSettings.settingsScrollHK &&
							!EditorGUIUtility.editingTextField)
						{
							if(e.keyCode == KeyCode.Home)
							{
								this.sections[this.index].TabYScroll = 0;
								this.Repaint();
							}
							else if(e.keyCode == KeyCode.End)
							{
								this.sections[this.index].TabYScroll = Mathf.Infinity;
								this.Repaint();
							}
						}
					}
				}
				else if(EditorContent.CTRL_F)
				{
					if(!this.IsSchematicSection &&
						e.mousePosition.x < EditorDataHandler.Instance.EditorAsset.SubSectionDrag)
					{
						this.searchField.SetFocus();
						e.Use();
					}
					else
					{
						if(this.sections[this.index].CurrentTab.FocusSearchField())
						{
							e.Use();
						}
					}
				}

				GUISkin tmpSkin = GUI.skin;
				GUIStyle tmpButtonStyle = GUI.skin.button;
				GUI.skin.button = EditorContent.Instance.ButtonStyle;


				// begin GUI layout
				EditorGUILayout.BeginVertical();

				// begin section selection
				GUI.SetNextControlName("SectionID");
				this.index = GUILayout.Toolbar(this.index, this.position.width / this.sectionHeaders.Length < 100 ? this.sectionHeadersIconOnly : this.sectionHeaders);
				// end section selection
				if(tmpSection != this.index && this.index == this.sectionHeaders.Length - 1)
				{
					this.index = tmpSection;
					this.splashScreenMode = EditorSplashScreenMode.StartChangeToSchematicSection;
					this.Repaint();
				}


				// ----------------------------------------------------

				// begin center part
				EditorGUILayout.BeginHorizontal();

				// schematics section
				if(this.IsSchematicSection)
				{
					((SchematicsSection)this.sections[this.index]).ShowSchematicEditor(ref historyChange);
				}
				// other sections
				else
				{
					// begin subsection list and help text
					EditorGUILayout.BeginVertical(GUILayout.Width(EditorDataHandler.Instance.EditorAsset.SubSectionDrag));

					// sub sections in a box
					EditorGUILayout.BeginVertical();

					EditorGUILayout.BeginVertical(EditorContent.Instance.BoxSlimStyle);

					// navigation
					this.ShowNavigation(ref historyChange);

					// search
					if(this.ShowSearchSubsections())
					{
						this.CreateSearchSubSectionList();
					}

					// sub section list
					if(this.search == "")
					{
						this.sections[this.index].ShowSubsection();
					}
					else
					{
						GUIStyle selected = EditorContent.Instance.SelectionGridSelectedStyle;
						GUIStyle normal = EditorContent.Instance.SelectionGridStyle;

						this.searchScroll = EditorGUILayout.BeginScrollView(this.searchScroll);
						for(int i = 0; i < this.searchList.Count; i++)
						{
							BaseEditorTab tab = this.sections[this.searchList[i].index[0]].Tabs[this.searchList[i].index[1]];
							GUI.SetNextControlName(tab.Name);
							bool pressed = GUILayout.Button(tab.Name,
								this.sections[this.index].CurrentTab == tab ? selected : normal,
								EditorTool.W_EXPAND);
							EditorTool.CheckHelpText(tab.Name, tab.HelpText, tab.HelpInfo);
							if(pressed)
							{
								this.change = this.searchList[i];
								this.changeSection = true;
							}
						}
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndScrollView();

						if(this.changeSection)
						{
							GUI.FocusControl(null);
							this.search = "";
							this.searchList.Clear();
							this.Repaint();
						}
					}
					EditorGUILayout.EndVertical();

					// editor help text
					this.ShowEditorHelp(EditorDataHandler.Instance.EditorAsset.SubSectionDrag, EditorDataHandler.Instance.EditorAsset.HelpDrag);

					EditorGUILayout.EndVertical();
					EditorGUILayout.EndVertical();

					// sub section drag
					this.SubSectionDrag();
					// end sub sections and help text


					// tab
					EditorGUILayout.BeginVertical();
					this.sections[this.index].ShowTab();
					EditorGUILayout.EndVertical();
				}

				EditorGUILayout.EndHorizontal();
				// end center part

				// ----------------------------------------------------

				// begin bottom part
				EditorGUILayout.BeginHorizontal();

				// schematic section
				if(this.IsSchematicSection)
				{
					((SchematicsSection)this.sections[this.index]).ShowSchematicSaveButtons();
				}
				// other sections
				else
				{
					GUI.SetNextControlName("Reload");
					if(EditorTool.ShowButton(EditorContent.Instance.ReloadContent,
						"Reload the project settings from the last save.", "", EditorTool.W_EXPAND) ||
						doLoad)
					{
						GUI.FocusControl("Reload");

						if(EditorUtility.DisplayDialog("Reload Settings", "Reloading the Project settings.\n" +
							"All unsaved changes will be lost!", "Reload", "Cancel"))
						{
							this.SaveEditorSettings();
							this.changeHistory.Clear();
							this.historyIndex = 0;
							this.ReloadData();
						}
						this.Focus();
					}
					GUI.SetNextControlName("Save");
					if(EditorTool.ShowButton(EditorContent.Instance.SaveContent,
						"Save the project settings.", "", EditorTool.W_EXPAND) ||
						doSave)
					{
						GUI.FocusControl("Save");
						for(int i = 0; i < this.sections.Length; i++)
						{
							this.sections[i].BeforeSaving();
						}
						this.CheckChanges();
					}
				}

				EditorGUILayout.EndHorizontal();
				// end bottom part


				EditorGUILayout.EndVertical();

				this.sections[this.index].ShowAfterEditor();

				GUI.skin = tmpSkin;
				GUI.skin.button = tmpButtonStyle;
			}

			// check navigation changes
			if((this.changeWatch.index[0] < this.sections.Length - 1) &&
				(this.changeWatch.index[0] != this.index ||
				this.changeWatch.index[1] != this.sections[this.index].Index ||
				this.changeWatch.index[2] != this.sections[this.index].TabIndex))
			{
				if(this.historyIndex < this.changeHistory.Count)
				{
					this.changeHistory.RemoveRange(this.historyIndex, this.changeHistory.Count - this.historyIndex);
				}

				this.changeHistory.Add(this.changeWatch);
				this.historyIndex = this.changeHistory.Count;
			}
		}

		protected virtual bool IsSchematicSection
		{
			get { return this.index == this.sections.Length - 1; }
		}

		public virtual void ReloadData()
		{
			this.splashScreenMode = EditorSplashScreenMode.StartReload;
			this.Repaint();
		}

		protected void DoReloadData()
		{
			Maki.Initialize(MakinomAssetHelper.LoadProjectAsset());
			EditorDataHandler.DataHandlerLoaded();
			EditorDataHandler.Instance.ClearDataChanges();
			for(int i = 0; i < this.sections.Length; i++)
			{
				this.sections[i].Reloaded();
			}
			this.Repaint();
		}

		public void CheckChanges()
		{
			this.splashScreenMode = EditorSplashScreenMode.StartCheckChanges;
			this.Repaint();
		}

		protected void DoCheckChanges()
		{
			ProjectSaveHandler tmpSaveHandler = new ProjectSaveHandler(this);
			if(tmpSaveHandler.HasChanges)
			{
				this.saveHandler = tmpSaveHandler;
				this.Repaint();
			}
			else
			{
				EditorUtility.DisplayDialog("Save Information",
					"No changes where made.\n" +
					"No data saved!", "Ok");
				this.Focus();
			}
		}

		protected void DoCheckChangesToSchematic()
		{
			ProjectSaveHandler tmpSaveHandler = new ProjectSaveHandler(this);
			if(tmpSaveHandler.HasChanges)
			{
				if(EditorUtility.DisplayDialog("Save Information",
					"Please save your changes first.", "Ok", "Cancel"))
				{
					this.saveHandler = tmpSaveHandler;
					this.Repaint();
				}
				this.Focus();
			}
			else
			{
				this.index = this.sectionHeaders.Length - 1;
			}
		}

		public virtual void ShowNavigation(ref int historyChange)
		{
			EditorGUILayout.Separator();

			EditorGUILayout.BeginHorizontal();
			GUILayout.FlexibleSpace();
			EditorGUI.BeginDisabledGroup(this.historyIndex <= 0);
			if(EditorTool.Button(EditorContent.Instance.NavigateBackIcon))
			{
				historyChange = -1;
			}
			EditorTool.CheckHelpText("Navigate Back", "Undo your previous navigation change.", "");
			EditorGUI.EndDisabledGroup();
			EditorGUI.BeginDisabledGroup(this.historyIndex >= this.changeHistory.Count);
			if(EditorTool.Button(EditorContent.Instance.NavigateForwardIcon))
			{
				historyChange = 1;
			}
			EditorTool.CheckHelpText("Navigate Forward", "Redo your previous navigation change.", "");
			EditorGUI.EndDisabledGroup();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();

			if(historyChange != 0)
			{
				if(historyChange == -1 && this.historyIndex == this.changeHistory.Count)
				{
					this.changeHistory.Add(this.changeWatch);
				}

				if(this.historyIndex >= 0 && this.historyIndex < this.changeHistory.Count)
				{
					this.changeHistory[this.historyIndex].scrollY = this.sections[this.index].TabYScroll;
				}

				this.historyIndex += historyChange;
				if(this.historyIndex < 0)
				{
					this.historyIndex = 0;
				}
				else if(this.historyIndex >= this.changeHistory.Count)
				{
					this.historyIndex = this.changeHistory.Count - 1;
					if(this.historyIndex < 0)
					{
						this.historyIndex = 0;
					}
				}
				if(this.historyIndex < this.changeHistory.Count)
				{
					this.change = this.changeHistory[this.historyIndex];
					this.changeSection = true;
				}
				if(historyChange == 1 && this.historyIndex == this.changeHistory.Count - 1)
				{
					this.changeHistory.RemoveAt(this.historyIndex);
				}
			}
			EditorGUILayout.Separator();
		}

		public virtual void ShowEditorHelp(float width, float height)
		{
			if(EditorHelpType.None != Maki.EditorSettings.editorHelpType)
			{
				// help text drag
				this.HelpDrag();

				EditorTool.ShowEditorHelp(ref this.helpScroll, width, height);
			}
		}

		public virtual void ShowFoldoutJumpList(bool dragLeft)
		{
			if(Maki.EditorSettings.showJumpList)
			{
				// jump list drag
				if(dragLeft)
				{
					this.JumpListDrag(true);
				}

				// foldout quick jump list
				EditorGUILayout.BeginVertical(GUILayout.Width(EditorDataHandler.Instance.EditorAsset.JumpListDrag));
				EditorGUILayout.BeginVertical(EditorContent.Instance.BoxSlimStyle);
				this.sections[this.index].ShowFoldoutJumpList(this.position.height);
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndVertical();

				// jump list drag
				if(!dragLeft)
				{
					this.JumpListDrag(false);
				}
			}
		}

		public virtual void ShowCustomFullView(MakinomFullViewEditor fullViewEditor)
		{
			this.fullViewEditor = fullViewEditor;
			this.Repaint();
		}


		/*
		============================================================================
		Search functions
		============================================================================
		*/

		public virtual bool ShowSearchSubsections()
		{
			if(this.searchField == null)
			{
				this.searchField = new SearchField();
			}
			string tmp = this.search;
			EditorTool.SearchField("Search Sub-Sections", ref this.search,
				"Search the sub-sections of all sections.", "", this.searchField);
			return tmp != this.search;
		}

		public virtual void CreateSearchSubSectionList()
		{
			this.searchList.Clear();
			if(this.search != "")
			{
				for(int i = 0; i < this.sections.Length - 1; i++)
				{
					for(int j = 0; j < this.sections[i].Tabs.Count; j++)
					{
						if(this.sections[i].Tabs[j].Name.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0)
						{
							this.searchList.Add(new SectionChange(
								new int[] { i, j, this.sections[i].Tabs[j].Index },
								this.sections[i].Tabs[j].SettingsScroll.y));
						}
					}
				}
			}
		}


		/*
		============================================================================
		Save handling
		============================================================================
		*/
		public virtual void UpdateEditorSchematic()
		{
			((SchematicsSection)this.sections[this.sections.Length - 1]).ChangeEditorSchematic();
		}


		/*
		============================================================================
		Section changing
		============================================================================
		*/
		public virtual void LoadSchematicAsset(MakinomSchematicAsset schematicAsset, Schematic runtimeSchematic)
		{
			this.schematicAsset = schematicAsset;
			this.runtimeSchematic = runtimeSchematic;
		}

		public virtual void LoadSchematicAsset()
		{
			((SchematicsSection)this.sections[this.sections.Length - 1]).LoadFile(this.schematicAsset, this.runtimeSchematic);
			this.changeSection = true;
			this.change.index = new int[] { this.sections.Length - 1, 0, index };
			this.schematicAsset = null;
			this.runtimeSchematic = null;
		}

		public virtual void EditSetting(System.Type instanceType, IMakinomGenericAsset asset)
		{
			if(instanceType != null)
			{
				this.changeSection = true;
				this.change.index = new int[] { 0, 0, 0 };
				this.change.scrollY = 0;

				bool found = false;
				for(int i = 0; i < this.sections.Length; i++)
				{
					for(int j = 0; j < this.sections[i].Tabs.Count; j++)
					{
						if(this.sections[i].Tabs[j].InstanceType != null &&
							instanceType.Equals(this.sections[i].Tabs[j].InstanceType))
						{
							this.change.index[0] = i;
							this.change.index[1] = j;
							this.change.index[2] = EditorDataHandler.Instance.AssetToIndex(instanceType, asset);

							found = true;
							i = this.sections.Length;
							break;
						}
					}
				}

				if(found)
				{
					if(this.changeWatch != null)
					{
						if(this.historyIndex < this.changeHistory.Count)
						{
							this.changeHistory.RemoveRange(this.historyIndex, this.changeHistory.Count - this.historyIndex);
						}

						this.changeHistory.Add(this.changeWatch);
						this.historyIndex = this.changeHistory.Count;
					}
				}
				else
				{
					this.changeSection = false;
				}
			}
		}

		public virtual void PerformSectionChange()
		{
			this.changeSection = false;
			this.index = this.change.index[0];
			this.sections[this.index].SetIndex(this.change.index[1],
				this.change.index[2], this.change.scrollY);
			if(this.change.foldoutLimit != "")
			{
				this.sections[this.index].TabFoldoutLimit = this.change.foldoutLimit;
				this.change.foldoutLimit = "";
			}
		}


		/*
		============================================================================
		Editor settings functions
		============================================================================
		*/
		public virtual void OnFocus()
		{
			MakinomEditorWindow.Instance = this;
		}

		public virtual void PlayModeStateChanged(PlayModeStateChange state)
		{
			if(PlayModeStateChange.ExitingEditMode == state)
			{
				if(this.sections != null)
				{
					this.SaveEditorSettings();
					((SchematicsSection)this.sections[this.sections.Length - 1]).RememberSchematic();
				}
				this.InitEditor();
			}
			else if(PlayModeStateChange.ExitingPlayMode == state)
			{
				if(this.sections != null)
				{
					this.SaveEditorSettings();
				}
				this.InitEditor();
			}
		}

		protected virtual void OnEnable()
		{
			EditorApplication.playModeStateChanged += this.PlayModeStateChanged;
		}

		protected virtual void OnDestroy()
		{
			EditorApplication.playModeStateChanged -= this.PlayModeStateChanged;
			if(this.sections != null)
			{
				((SchematicsSection)this.sections[this.sections.Length - 1]).UnregisterDebug();
				this.SaveEditorSettings();
			}
			instance = null;
		}

		public virtual void SaveEditorSettings()
		{
			if(Maki.Initialized)
			{
				MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
				if(editorAsset != null)
				{
					editorAsset.LastProject = Maki.Data.ProjectAsset;

					// last sections
					if(Maki.EditorSettings.rememberLastSection)
					{
						if(this.sections != null &&
							this.index >= 0 &&
							this.index < this.sections.Length)
						{
							editorAsset.Section = this.index;
							editorAsset.SubSection = this.sections[this.index].Index;
							editorAsset.TabIndex = this.sections[this.index].TabIndex;
							editorAsset.ScrollY = this.sections[this.index].TabYScroll;
							editorAsset.FoldoutLimit = this.sections[this.index].TabFoldoutLimit;
						}
					}
					else
					{
						editorAsset.ResetSections();
					}

					// foldout states
					if(Maki.EditorSettings.rememberFoldouts ||
						Maki.EditorSettings.useFoldoutColors)
					{
						EditorContent.Instance.StoreFoldoutStates(editorAsset);
					}
					else
					{
						editorAsset.ResetFoldoutStates();
					}

					MakinomAssetHelper.SaveEditorAsset(editorAsset);
				}
			}
		}

		public virtual void LoadEditorSettings()
		{
			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;

			// last sections
			this.change.index = new int[] {editorAsset.Section,
				editorAsset.SubSection, editorAsset.TabIndex};
			this.change.scrollY = editorAsset.ScrollY;
			this.change.foldoutLimit = editorAsset.FoldoutLimit;
			this.changeSection = true;

			// foldout states
			EditorContent.Instance.LoadFoldoutStates(editorAsset);
		}
	}
}
