
using System;

namespace GamingIsLove.Makinom.Editor
{
	public class SectionChange
	{
		public int[] index = new int[] {0, 0, 0};

		public float scrollY = 0;

		public string foldoutLimit = "";
		
		public SectionChange()
		{
			
		}
		
		public SectionChange(int[] index, float scrollY)
		{
			this.index = index;
			this.scrollY = scrollY;
		}
	}
}
