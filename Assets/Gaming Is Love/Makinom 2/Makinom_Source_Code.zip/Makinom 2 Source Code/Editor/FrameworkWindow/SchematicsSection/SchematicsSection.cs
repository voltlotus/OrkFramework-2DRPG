
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class SchematicsSection : BaseEditorSection
	{
		private SchematicsTab tab;

		private int mode = 0;

		private MakinomSchematicAsset schematicAsset;

		private SchematicEditorMenuType lastEditorType = SchematicEditorMenuType.Bottom;

		private Rect nodeRect = new Rect(0, 0, 0, 0);

		private bool firstShow = true;

		public SchematicsSection(MakinomEditorWindow parent)
		{
			this.parent = parent;
			this.tab = new SchematicsTab(parent);
			this.tabs.Add(this.tab);
			this.lastEditorType = Maki.EditorSettings.schematicMenuType;

			Maki.MachineHandler.DebugAdded += this.DebugAdded;
		}

		public void LoadFile(MakinomSchematicAsset file, Schematic runtimeSchematic)
		{
			if(file != null)
			{
				this.tab.LoadFile(file, runtimeSchematic);
			}
		}

		private float SettingsSize
		{
			get { return this.tab.IsShowSettings ? EditorDataHandler.Instance.EditorAsset.SchematicDrag + 5 : 0; }
		}

		private float SettingsSizeWithJumplist
		{
			get
			{
				return this.tab.IsShowSettings ?
					EditorDataHandler.Instance.EditorAsset.SchematicDrag + 17 +
						(Maki.EditorSettings.showJumpList ? EditorDataHandler.Instance.EditorAsset.JumpListDrag + 5 : 0) :
					0;
			}
		}

		public void ShowSchematicEditor(ref int historyChange)
		{
			this.tab.ClearShow();

			if(this.firstShow)
			{
				this.firstShow = false;
				this.tab.FirstShow();
			}

			if(Event.current.type == EventType.Repaint &&
				Maki.EditorSettings.schematicMenuType != this.lastEditorType)
			{
				this.lastEditorType = Maki.EditorSettings.schematicMenuType;
				GUI.changed = true;
			}

			if(SchematicEditorMenuType.Left == Maki.EditorSettings.schematicMenuType)
			{
				this.nodeRect.Set(
					this.SettingsSizeWithJumplist,
					EditorTool.SectionHeight,
					this.Editor.position.width - this.SettingsSizeWithJumplist,
					this.Editor.position.height - EditorTool.SectionHeight - EditorTool.SaveButtonHeight);

				EditorGUILayout.BeginHorizontal();

				if(this.tab.IsShowSettings)
				{
					// menu
					EditorGUILayout.BeginVertical(GUILayout.Width(EditorDataHandler.Instance.EditorAsset.SchematicDrag));
					EditorGUILayout.BeginVertical();
					this.ShowSchematicSelection(false);

					if(this.mode == 0)
					{
						this.tab.ShowNodeSettings(false);

						// editor help text
						this.parent.ShowEditorHelp(
							EditorDataHandler.Instance.EditorAsset.SchematicDrag,
							EditorDataHandler.Instance.EditorAsset.HelpDrag);
					}

					EditorGUILayout.EndVertical();
					EditorGUILayout.EndVertical();

					// drag
					this.parent.SchematicDrag(true, false);

					// foldout jumplist
					this.parent.ShowFoldoutJumpList(false);
				}

				GUILayoutUtility.GetRect(this.nodeRect.width, this.nodeRect.height);

				EditorGUILayout.EndHorizontal();

			}
			else if(SchematicEditorMenuType.Right == Maki.EditorSettings.schematicMenuType)
			{
				this.nodeRect.Set(
					0,
					EditorTool.SectionHeight,
					this.Editor.position.width - this.SettingsSizeWithJumplist,
					this.Editor.position.height - EditorTool.SectionHeight - EditorTool.SaveButtonHeight);

				EditorGUILayout.BeginHorizontal();

				GUILayoutUtility.GetRect(this.nodeRect.width, this.nodeRect.height);

				if(this.tab.IsShowSettings)
				{
					// drag
					this.parent.SchematicDrag(true, true);

					// menu
					EditorGUILayout.BeginVertical(GUILayout.Width(EditorDataHandler.Instance.EditorAsset.SchematicDrag));
					EditorGUILayout.BeginVertical();
					this.ShowSchematicSelection(false);

					if(this.mode == 0)
					{
						this.tab.ShowNodeSettings(false);

						// editor help text
						this.parent.ShowEditorHelp(
							EditorDataHandler.Instance.EditorAsset.SchematicDrag,
							EditorDataHandler.Instance.EditorAsset.HelpDrag);
					}

					EditorGUILayout.EndVertical();
					EditorGUILayout.EndVertical();

					// foldout jumplist
					this.parent.ShowFoldoutJumpList(true);
				}

				EditorGUILayout.EndHorizontal();
			}
			else if(SchematicEditorMenuType.Top == Maki.EditorSettings.schematicMenuType)
			{
				this.nodeRect.Set(
					0,
					EditorTool.SectionHeight + this.SettingsSize,
					this.Editor.position.width,
					this.Editor.position.height - EditorTool.SectionHeight - EditorTool.SaveButtonHeight - this.SettingsSize);

				EditorGUILayout.BeginVertical();

				if(this.tab.IsShowSettings)
				{
					// menu
					EditorGUILayout.BeginHorizontal(GUILayout.Height(EditorDataHandler.Instance.EditorAsset.SchematicDrag));
					EditorGUILayout.BeginVertical(GUILayout.Width(EditorDataHandler.Instance.EditorAsset.SubSectionDrag));
					this.ShowSchematicSelection(true);

					// editor help text
					if(this.mode == 0)
					{
						this.parent.ShowEditorHelp(
							EditorDataHandler.Instance.EditorAsset.SubSectionDrag,
							EditorDataHandler.Instance.EditorAsset.HelpDrag);
					}

					EditorGUILayout.EndVertical();

					this.parent.SubSectionDrag();

					this.tab.ShowNodeSettings(false);

					// foldout jumplist
					this.parent.ShowFoldoutJumpList(true);

					EditorGUILayout.EndHorizontal();

					// drag
					this.parent.SchematicDrag(false, true);
				}

				GUILayoutUtility.GetRect(this.nodeRect.width, this.nodeRect.height);

				EditorGUILayout.EndVertical();
			}
			else if(SchematicEditorMenuType.Bottom == Maki.EditorSettings.schematicMenuType)
			{
				this.nodeRect.Set(
					0,
					EditorTool.SectionHeight,
					this.Editor.position.width,
					this.Editor.position.height - EditorTool.SectionHeight - EditorTool.SaveButtonHeight - this.SettingsSize);

				EditorGUILayout.BeginVertical();

				GUILayoutUtility.GetRect(this.nodeRect.width, this.nodeRect.height);

				if(this.tab.IsShowSettings)
				{
					// drag
					this.parent.SchematicDrag(false, false);

					// menu
					EditorGUILayout.BeginHorizontal(GUILayout.Height(EditorDataHandler.Instance.EditorAsset.SchematicDrag));
					EditorGUILayout.BeginVertical(GUILayout.Width(EditorDataHandler.Instance.EditorAsset.SubSectionDrag));
					this.ShowSchematicSelection(true);

					// editor help text
					if(this.mode == 0)
					{
						this.parent.ShowEditorHelp(
							EditorDataHandler.Instance.EditorAsset.SubSectionDrag,
							EditorDataHandler.Instance.EditorAsset.HelpDrag);
					}

					EditorGUILayout.EndVertical();

					this.parent.SubSectionDrag();

					this.tab.ShowNodeSettings(false);

					// foldout jumplist
					this.parent.ShowFoldoutJumpList(true);

					EditorGUILayout.EndHorizontal();
				}

				EditorGUILayout.EndVertical();
			}

			if(GUI.changed)
			{
				this.parent.Repaint();
			}
		}

		public void ShowSchematicSelection(bool showScroll)
		{
			if(showScroll)
			{
				this.subScroll = EditorGUILayout.BeginScrollView(this.subScroll);
			}

			if(this.mode == 0)
			{
				if(EditorTool.ShowButton("New Schematic", "Creates a new schematic.\n" +
					"Schematics are used in machine components and global machines to create controls, game logic, " +
					"dialogues, cinematics, gameplay and other things.\n" +
					"Schematics aren't saved with the rest of the data - you have to save each schematic " +
					"individually using the 'Save Schematic' button!", "", GUILayout.ExpandWidth(true)))
				{
					if(this.tab.SchematicAsset.Settings.node.Length == 0 ||
						EditorUtility.DisplayDialog("Close Schematic", "Do you really want to close the current schematic?\n" +
							"All unsaved schematic data will be lost!", "Close", "Cancel"))
					{
						this.LoadFile(null, null);
					}
				}

				if(EditorTool.ShowButton("Open Schematic", "Open a schematic asset.", "",
					GUILayout.ExpandWidth(true)))
				{
					this.mode = 1;
					this.schematicAsset = null;
					GUI.changed = true;
				}
				EditorGUILayout.Separator();

				if(this.tab.FileName != "")
				{
					GUIStyle style = new GUIStyle(EditorStyles.boldLabel);
					style.wordWrap = true;
					style.richText = true;
					GUILayout.Label(new GUIContent("File:\n" + this.tab.FileName, "File: " + this.tab.FileName), style);

					if(this.tab.SchematicAsset != null &&
						Maki.MachineHandler.HasDebug)
					{
						List<SchematicDebug> list = Maki.MachineHandler.GetDebug(this.tab.SchematicAsset);
						if(list != null)
						{
							style = new GUIStyle(EditorStyles.label);
							style.wordWrap = true;
							style.richText = true;

							EditorGUILayout.LabelField("Debugging Available", list.Count.ToString());
							for(int i = 0; i < list.Count; i++)
							{
								bool isDebugging = this.tab.RuntimeSchematic == list[i].Schematic;
								Color tmpColor = GUI.backgroundColor;
								if(isDebugging)
								{
									GUI.backgroundColor = Color.yellow;
								}
								EditorGUILayout.BeginVertical(EditorContent.Instance.BoxSlimStyle);
								string text = "<b>" + i + ") ";
								if(list[i].Starter is GlobalMachine)
								{
									text += "Global Machine" +
										(list[i].Schematic.IsPriority ? " (Priority " + list[i].Schematic.Priority + ")" : "");
								}
								else if(list[i].Starter is GameStarter)
								{
									text += "Game Starter" +
										(list[i].Schematic.IsPriority ? " (Priority " + list[i].Schematic.Priority + ")" : "");
								}
								else if(list[i].Starter is BaseMachineComponent ||
									list[i].Starter is AnimationStateMachineComponent)
								{
									text += list[i].Starter.GetType().Name +
										(list[i].Schematic.IsPriority ? " (Priority " + list[i].Schematic.Priority + ")" : "");
								}
								else
								{
									text += "Other" +
										(list[i].Schematic.IsPriority ? " (Priority " + list[i].Schematic.Priority + ")" : "");
								}
								text += "</b> (" + list[i].Schematic.State.ToString() + ")\n";
								GameObject machineObject = list[i].Schematic.MachineObject != null ? list[i].Schematic.MachineObject.FirstAdded : null;
								GameObject startingObject = list[i].Schematic.StartingObject != null ? list[i].Schematic.StartingObject.FirstAdded : null;
								text += "Machine/Starting Object:\t\t" +
									(machineObject != null ? machineObject.name : "-") + "/" +
									(startingObject != null ? startingObject.name : "-");
								GUILayout.Label(text, style);

								if(isDebugging)
								{
									if(EditorTool.ShowButton("Stop Debugging", "Stop debugging this instance.", "",
										GUILayout.ExpandWidth(true)))
									{
										this.tab.RuntimeSchematic = null;
									}
								}
								else
								{
									if(EditorTool.ShowButton("Start Debugging", "Start debugging this instance.", "",
										GUILayout.ExpandWidth(true)))
									{
										this.tab.RuntimeSchematic = list[i].Schematic;
									}
								}

								EditorGUILayout.EndVertical();
								GUI.backgroundColor = tmpColor;
							}
						}
						else
						{
							EditorGUILayout.LabelField("Running", "-");
						}
					}
				}
			}
			// open schematic asset
			else if(this.mode == 1)
			{
				if(EditorTool.ShowButton("Cancel", "Cancels opening a schematic asset.",
					"", GUILayout.ExpandWidth(true)))
				{
					this.mode = 0;
					GUI.changed = true;
				}

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Open Schematic");
				EditorTool.ObjectField("", ref this.schematicAsset, typeof(MakinomSchematicAsset),
					"Select the schematic asset that will be opened.", "", GUILayout.ExpandWidth(true));

				EditorGUI.BeginDisabledGroup(this.schematicAsset == null);
				if(EditorTool.ShowButton("Open", "The selected schematic asset will be opened.",
					"", GUILayout.ExpandWidth(true)))
				{
					this.LoadFile(this.schematicAsset, null);
					this.mode = 0;
					GUI.changed = true;
				}
				EditorGUI.EndDisabledGroup();

				MakinomSchematicAsset tmpAsset = this.tab.ShowLastSchematicsList(typeof(Schematic));
				if(tmpAsset != null)
				{
					this.LoadFile(tmpAsset, null);
					this.mode = 0;
					GUI.changed = true;
				}
			}

			if(showScroll)
			{
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndScrollView();
			}
		}

		private void DebugAdded()
		{
			if(Maki.EditorSettings.schematicAutoStartDebug &&
				this.tab.SchematicAsset != null &&
				this.tab.RuntimeSchematic == null &&
				Maki.MachineHandler.HasDebug)
			{
				List<SchematicDebug> list = Maki.MachineHandler.GetDebug(this.tab.SchematicAsset);
				if(list != null && list.Count > 0)
				{
					this.tab.RuntimeSchematic = list[0].Schematic;
				}
			}
		}

		public override void ShowTab()
		{
			this.tab.BeforeTab();
			this.tab.ShowTab();
			this.tab.AfterTab();
		}

		public override void SetIndex(int i, int j, float yScroll)
		{

		}

		public void RememberSchematic()
		{
			this.tab.RememberSchematic();
		}

		public void ChangeEditorSchematic()
		{
			this.tab.ChangeEditorSchematic();
		}

		public void ShowSchematicSaveButtons()
		{
			this.tab.ShowSchematicSaveButtons();
		}

		public void UnregisterDebug()
		{
			this.tab.UnregisterDebug();
			Maki.MachineHandler.DebugAdded -= this.DebugAdded;
		}

		public override void ShowAfterEditor()
		{
			// node grid
			this.tab.ShowNodeGrid(this.nodeRect);

			if(GUI.changed)
			{
				this.parent.Repaint();
			}
		}
	}
}
