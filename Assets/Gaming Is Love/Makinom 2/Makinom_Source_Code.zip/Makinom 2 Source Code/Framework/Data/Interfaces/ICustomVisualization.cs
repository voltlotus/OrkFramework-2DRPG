﻿
namespace GamingIsLove.Makinom
{
	public interface ICustomVisualization
	{

	}
}
