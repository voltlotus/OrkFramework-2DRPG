
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class HUDsSettings : GenericAssetListSettings<HUDAsset, HUDSetting>
	{
		// HUD settings
		[EditorHelp("HUD Layer Mask", "Select the layers that will be checked for objects in HUDs.\n" +
			"This is used e.g. when a game object's HUD is only displayed while the mouse is above it, " +
			"or the cursor changes of scene objects.", "")]
		[EditorFoldout("HUD Settings", "Base settings regarding HUDs.", "")]
		public LayerMask hudMask = -1;

		[EditorHelp("Raycast Distance", "The distance used by the raycast to determine the current HUD object.", "")]
		[EditorEndFoldout]
		public float hudDistance = 100;


		// schematics
		[EditorFoldout("Default Schematics", "HUDs can start schematics upon certain UI actions (e.g. opening, closing).\n" +
			"This setting can be overridden by each HUD individually.")]
		[EditorEndFoldout]
		public HUDSchematics schematics = new HUDSchematics();

		public HUDsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "HUDs"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}


		/*
		============================================================================
		HUD functions
		============================================================================
		*/
		public void Clear()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				this.assets[i].Settings.Clear();
			}
		}

		public void Create()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.AutoCreate)
				{
					Maki.UI.GetHUD(this.assets[i]);
				}
			}
		}

		public void CheckToggleKeys()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				this.assets[i].Settings.CheckToggleKey();
			}
		}
	}
}

