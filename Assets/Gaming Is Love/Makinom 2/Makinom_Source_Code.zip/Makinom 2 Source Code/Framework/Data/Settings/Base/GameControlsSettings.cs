
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameControlsSettings : BaseSettings
	{
		[EditorHelp("Click Timeout (s)", "The time in seconds to recognize multi-clicks.\n" +
			"If another click/touch happens within the timeout, it will be recognized " +
			"as a multi-click (e.g. double click).", "")]
		[EditorFoldout("Base Key Settings", "Set the base game controls.", "")]
		public float clickTimeout = 0.2f;


		// pause
		[EditorHelp("Pause Time", "The game time (play time) will pause when the game is paused.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Pause Settings")]
		public bool pauseTime = false;

		[EditorHelp("Freeze Pause", "The game freezes in pause, i.e. animations, movements, etc. will stop.", "")]
		public bool freezePause = false;

		[EditorFoldout("Pause Key", "The input key used to pause and unpause the game.", "")]
		public AudioInputSelection pauseKeySettings = new AudioInputSelection();

		[EditorFoldout("Conditions", "Optionally only allow using the pause key when defined conditions are valid.", "")]
		[EditorEndFoldout(3)]
		public GeneralConditionSetting<GameObjectSelection> pauseKeyCondition = new GeneralConditionSetting<GameObjectSelection>();


		// interaction settings
		[EditorFoldout("Interaction Settings", "Define how the player can start 'Interact' type interaction machines.", "")]
		[EditorEndFoldout]
		public InteractionSetting interaction = new InteractionSetting();


		// object selection
		[EditorFoldout("Object Selection", "The player can use input keys and mouse/touch controls to select " +
			"game objects with a 'Selectable Object' component attached. " +
			"The currently selected object can optionally be marked with a cursor.\n" +
			"When using 'Selected Object' interaction control, the player can start " +
			"'Interact' type interaction machines on the currently selected object.", "")]
		[EditorEndFoldout]
		public ObjectSelectionSetting objectSelection = new ObjectSelectionSetting();


		// player settings
		// prefab
		[EditorFoldout("Player Settings", "Player prefab and object variables settings.", "",
			"Prefab Settings", "Select the prefab that will be used to spawn the player.", "")]
		[EditorEndFoldout]
		public PlayerSetting player = new PlayerSetting();

		// player components
		[EditorFoldout("Player Component Settings", "Automatically add components to the player.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Component", "Adds a component to the player.\n" +
			"The component can be automatically added to the player when spawned and change fields/properties on it.", "",
			"Remove", "Removes this component.", "",
			foldout = true, foldoutText = new string[] {
				"Player Component", "The component can be automatically added to the player when spawned and change fields/properties on it.", ""
			})]
		public PlayerComponentSetting[] playerComponent = new PlayerComponentSetting[0];

		// controls
		[EditorEndFoldout]
		public ControlSettings controlSettings = new ControlSettings();

		public GameControlsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("pauseKey"))
			{
				this.pauseKeySettings.inputKey.SetData(data.GetFile("pauseKey"));
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Game Controls"; }
		}


		/*
		============================================================================
		Player components functions
		============================================================================
		*/
		public void AddPlayerComponents(GameObject player, bool addInteractionController)
		{
			if(player != null)
			{
				// controls
				this.controlSettings.Add(player, ControlPlaceType.Player);

				// components
				for(int i = 0; i < this.playerComponent.Length; i++)
				{
					this.playerComponent[i].Add(player);
				}

				// interaction controller
				if(addInteractionController &&
					!this.interaction.IsSelectedObject)
				{
					this.interaction.interactionController.AddInteractionController(player);
				}
			}
		}

		public void RemovePlayerComponents(GameObject player)
		{
			if(player != null)
			{
				// controls
				this.controlSettings.Remove(player, ControlPlaceType.Player);

				// components
				for(int i = 0; i < this.playerComponent.Length; i++)
				{
					this.playerComponent[i].Remove(player);
				}
			}
		}
	}
}

