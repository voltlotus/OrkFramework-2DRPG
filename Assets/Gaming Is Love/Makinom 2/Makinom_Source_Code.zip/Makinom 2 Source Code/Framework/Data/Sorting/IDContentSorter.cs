
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class IDContentSorter<T> : IComparer<T> where T : IContent
	{
		private bool invert = false;

		public IDContentSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(T x, T y)
		{
			if(this.invert)
			{
				return y.ID.CompareTo(x.ID);
			}
			else
			{
				return x.ID.CompareTo(y.ID);
			}
		}
	}

	public class IDSorter<T> : IComparer<T> where T : BaseIndexData
	{
		private bool invert = false;

		public IDSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(T x, T y)
		{
			if(this.invert)
			{
				return y.ID.CompareTo(x.ID);
			}
			else
			{
				return x.ID.CompareTo(y.ID);
			}
		}
	}
}
