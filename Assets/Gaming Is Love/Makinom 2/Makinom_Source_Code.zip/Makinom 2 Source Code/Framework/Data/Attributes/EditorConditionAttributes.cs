﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = true)]
	public class EditorConditionAttribute : System.Attribute
	{
		public string[] checkField;

		public object[] fieldValue;

		public EditorConditionAttribute(string field, object value)
		{
			this.checkField = new string[] { field };
			this.fieldValue = new object[] { value };
		}

		public EditorConditionAttribute(string[] fields, object[] values)
		{
			this.checkField = fields;
			this.fieldValue = values;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = true)]
	public class EditorConditionCallbackAttribute : System.Attribute
	{
		public string callback = "";

		public EditorConditionCallbackAttribute(string callback)
		{
			this.callback = callback;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorElseConditionAttribute : System.Attribute
	{
		public EditorElseConditionAttribute()
		{

		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorEndConditionAttribute : System.Attribute
	{
		public int count = 1;

		public EditorEndConditionAttribute()
		{

		}

		public EditorEndConditionAttribute(int count)
		{
			this.count = count;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorAutoInitAttribute : System.Attribute
	{
		public int autoSize = 0;


		// constructor parameters
		public System.Type[] constTypes = null;

		public object[] constValues = null;

		public EditorAutoInitAttribute()
		{

		}

		public EditorAutoInitAttribute(int autoSize)
		{
			this.autoSize = autoSize;
		}

		public EditorAutoInitAttribute(System.Type[] constTypes, object[] constValues)
		{
			this.constTypes = constTypes;
			this.constValues = constValues;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorDefaultValueAttribute : System.Attribute
	{
		public object value = null;

		public EditorDefaultValueAttribute(object value)
		{
			this.value = value;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorAssetSelectionConditionAttribute : System.Attribute
	{
		public string[] checkField;

		public object[] fieldValue;

		public bool[] fieldCheck;

		public EditorAssetSelectionConditionAttribute(string field, object value, bool check)
		{
			this.checkField = new string[] { field };
			this.fieldValue = new object[] { value };
			this.fieldCheck = new bool[] { check };
		}

		public EditorAssetSelectionConditionAttribute(string[] fields, object[] values, bool[] checks)
		{
			this.checkField = fields;
			this.fieldValue = values;
			this.fieldCheck = checks;
		}
	}
}
