
using GamingIsLove.Makinom.IO;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace GamingIsLove.Makinom
{
	/// <summary>
	/// Handles data serialization of classes using <see cref="GamingIsLove.Makinom.IBaseData"> interface.
	/// The data is stored in a <see cref="GamingIsLove.Makinom.DataObject"/>.
	/// </summary>
	public static class DataSerializer
	{
		/*public static System.Diagnostics.Stopwatch Watch1 = new System.Diagnostics.Stopwatch();
		public static System.Diagnostics.Stopwatch Watch2 = new System.Diagnostics.Stopwatch();
		public static System.Diagnostics.Stopwatch Watch3 = new System.Diagnostics.Stopwatch();
		public static System.Diagnostics.Stopwatch Watch4 = new System.Diagnostics.Stopwatch();*/

		// special data keys
		public static string TYPE = "_type";

		/// <summary>
		/// Gets a <see cref="GamingIsLove.Makinom.DataObject"/> representing a class.
		/// </summary>
		/// <returns>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </returns>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="GamingIsLove.Makinom.IBaseData">.
		/// </typeparam>
		public static DataObject GetDataObject<T>(T instance) where T : IBaseData
		{
			DataObject data = new DataObject();

			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(field[i].FieldType.IsArray)
						{
							if(value is IBaseData[])
							{
								IBaseData[] tmp = (IBaseData[])(System.Array)value;
								DataObject[] file = new DataObject[tmp.Length];
								for(int j = 0; j < tmp.Length; j++)
								{
									if(tmp[j] != null)
									{
										file[j] = tmp[j].GetData();
									}
								}
								data.Set(field[i].Name, file);
							}
							else if(value is string[])
							{
								data.Set(field[i].Name, (string[])(System.Array)value);
							}
							else if(value is int[])
							{
								data.Set(field[i].Name, (int[])(System.Array)value);
							}
							else if(value is bool[])
							{
								data.Set(field[i].Name, (bool[])(System.Array)value);
							}
							else if(value is float[])
							{
								data.Set(field[i].Name, (float[])(System.Array)value);
							}
							else if(value is Vector3[])
							{
								data.Set(field[i].Name, (Vector3[])value);
							}
							// unused?
							else if(value is Vector2[])
							{
								data.Set(field[i].Name, (Vector2[])value);
							}
							else if(value is Vector4[])
							{
								data.Set(field[i].Name, (Vector4[])value);
							}
							else if(value is Rect[])
							{
								data.Set(field[i].Name, (Rect[])value);
							}
							else if(value is Color[])
							{
								data.Set(field[i].Name, (Color[])value);
							}
							else if(value != null)
							{
								Debug.LogWarning("Warning: Data type of field " + field[i].Name + " not supported (" + field[i].FieldType + ")");
							}
						}
						else
						{
							if(value is bool)
							{
								data.Set(field[i].Name, (bool)value);
							}
							else if(value is IBaseData)
							{
								data.Set(field[i].Name, ((IBaseData)value).GetData());
							}
							else if(value is int)
							{
								data.Set(field[i].Name, (int)value);
							}
							else if(value is System.Enum)
							{
								data.SetEnum(field[i].Name, (int)value);
							}
							else if(value is float)
							{
								data.Set(field[i].Name, (float)value);
							}
							else if(value is string)
							{
								data.Set(field[i].Name, (string)value);
							}
							else if(value is UnityEngine.Object)
							{
								data.SetAsset(field[i].Name, (UnityEngine.Object)value);
							}
							else if(value is Vector2)
							{
								data.Set(field[i].Name, (Vector2)value);
							}
							else if(value is Vector3)
							{
								data.Set(field[i].Name, (Vector3)value);
							}
							else if(value is Color)
							{
								data.Set(field[i].Name, (Color)value);
							}
							else if(value is AnimationCurve)
							{
								data.Set(field[i].Name, (AnimationCurve)value);
							}
							else if(value is Vector4)
							{
								data.Set(field[i].Name, (Vector4)value);
							}
							else if(value is Rect)
							{
								data.Set(field[i].Name, (Rect)value);
							}
							else if(value is LayerMask)
							{
								data.Set(field[i].Name, ((LayerMask)value).value);
							}
							else if(value != null)
							{
								Debug.LogWarning("Warning: Data type of field " + field[i].Name + " not supported (" + field[i].FieldType + ")");
							}
						}
					}
				}
			}

			return data;
		}

		/// <summary>
		/// Sets the variables of a class using a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </param>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="GamingIsLove.Makinom.IBaseData">.
		/// </typeparam>
		/*public static void SetDataObjectOld<T>(DataObject data, T instance) where T : IBaseData
		{
			if(data != null && instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					try
					{
						if(field[i].FieldType.IsArray)
						{
							if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
							{
								DataObject[] file = data.GetFileArray(field[i].Name);
								if(file != null)
								{
									field[i].SetValue(instance, DataSerializer.CreateArrayInstance(file,
										field[i].FieldType, field[i].FieldType.GetElementType()));
								}
							}
							else if(typeof(string[]) == field[i].FieldType)
							{
								data.LoadStringArray(field[i], instance);
							}
							else if(typeof(int[]) == field[i].FieldType)
							{
								data.LoadIntArray(field[i], instance);
							}
							else if(typeof(bool[]) == field[i].FieldType)
							{
								data.LoadBoolArray(field[i], instance);
							}
							else if(typeof(float[]) == field[i].FieldType)
							{
								data.LoadFloatArray(field[i], instance);
							}
							else if(field[i].FieldType.GetElementType().IsEnum)
							{
								data.LoadEnumArray(field[i], instance);
							}
							else if(typeof(Vector3[]) == field[i].FieldType)
							{
								data.LoadVector3Array(field[i], instance);
							}
							// unused?
							else if(typeof(Vector2[]) == field[i].FieldType)
							{
								data.LoadVector2Array(field[i], instance);
							}
							else if(typeof(Vector4[]) == field[i].FieldType)
							{
								data.LoadVector4Array(field[i], instance);
							}
							else if(typeof(Rect[]) == field[i].FieldType)
							{
								data.LoadRectArray(field[i], instance);
							}
							else if(typeof(Color[]) == field[i].FieldType)
							{
								data.LoadColorArray(field[i], instance);
							}
						}
						else
						{
							if(typeof(bool) == field[i].FieldType)
							{
								data.LoadBool(field[i], instance);
							}
							else if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
							{
								DataObject file = data.GetFile(field[i].Name);
								if(file != null)
								{
									string typeInfo = "";
									if(file.Get(DataSerializer.TYPE, ref typeInfo) &&
										!string.IsNullOrEmpty(typeInfo))
									{
										field[i].SetValue(instance, DataSerializer.CreateInstance(file, field[i].FieldType, typeInfo));
									}
									else
									{
										object value = field[i].GetValue(instance);
										if(value == null ||
											value.GetType() != field[i].FieldType)
										{
											value = ReflectionTypeHandler.Instance.CreateInstance(field[i].FieldType);
											((IBaseData)value).SetData(file);
											field[i].SetValue(instance, value);
										}
										else
										{
											((IBaseData)value).SetData(file);
											field[i].SetValue(instance, value);
										}
									}
								}
							}
							else if(typeof(int) == field[i].FieldType)
							{
								data.LoadInt(field[i], instance);
							}
							else if(typeof(System.Enum).IsAssignableFrom(field[i].FieldType))
							{
								data.LoadInt(field[i], instance);
							}
							else if(typeof(float) == field[i].FieldType)
							{
								data.LoadFloat(field[i], instance);
							}
							else if(typeof(string) == field[i].FieldType)
							{
								data.LoadString(field[i], instance);
							}
							else if(typeof(UnityEngine.Object).IsAssignableFrom(field[i].FieldType))
							{
								data.LoadAsset(field[i], instance);
							}
							else if(typeof(Vector2) == field[i].FieldType)
							{
								data.LoadVector2(field[i], instance);
							}
							else if(typeof(Vector3) == field[i].FieldType)
							{
								data.LoadVector3(field[i], instance);
							}
							else if(typeof(Color) == field[i].FieldType)
							{
								data.LoadColor(field[i], instance);
							}
							else if(typeof(AnimationCurve).IsAssignableFrom(field[i].FieldType))
							{
								data.LoadAnimationCurve(field[i], instance);
							}
							else if(typeof(Vector4) == field[i].FieldType)
							{
								data.LoadVector4(field[i], instance);
							}
							else if(typeof(Rect) == field[i].FieldType)
							{
								data.LoadRect(field[i], instance);
							}
							else if(typeof(LayerMask) == field[i].FieldType)
							{
								int tmp = 1;
								if(data.Get(field[i].Name, ref tmp))
								{
									LayerMask tmp2 = new LayerMask();
									tmp2.value = tmp;
									field[i].SetValue(instance, tmp2);
								}
							}
						}
					}
					catch(System.Exception ex)
					{
						// silent
					}
				}
			}
		}*/

		/// <summary>
		/// Sets the variables of a class using a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </param>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="GamingIsLove.Makinom.IBaseData">.
		/// </typeparam>
		public static void SetDataObject<T>(DataObject data, T instance) where T : IBaseData
		{
			if(data != null && instance != null)
			{
				LoadDataFromDataObject[] loadDelegate = ReflectionTypeHandler.Instance.GetLoadFieldDelegates(instance.GetType());

				for(int i = 0; i < loadDelegate.Length; i++)
				{
					try
					{
						loadDelegate[i](data, instance);
					}
					catch(System.Exception ex)
					{
						// silent
					}
				}
			}
		}

		public static LoadDataFromDataObject CreateLoadDelegate(FieldInfo field)
		{
			try
			{
				System.Type fieldType = field.FieldType;
				if(fieldType.IsArray)
				{
					if(typeof(IBaseData[]).IsAssignableFrom(fieldType))
					{
						return delegate (DataObject data, object instance)
						{
							DataObject[] file = data.GetFileArray(field.Name);
							if(file != null)
							{
								field.SetValue(instance, DataSerializer.CreateArrayInstance(file,
									fieldType, fieldType.GetElementType()));
							}
						};
					}
					else if(typeof(string[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadStringArray(field, instance);
						};
					}
					else if(typeof(int[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadIntArray(field, instance);
						};
					}
					else if(typeof(bool[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadBoolArray(field, instance);
						};
					}
					else if(typeof(float[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadFloatArray(field, instance);
						};
					}
					else if(fieldType.GetElementType().IsEnum)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadEnumArray(field, instance);
						};
					}
					else if(typeof(Vector3[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadVector3Array(field, instance);
						};
					}
					// unused?
					else if(typeof(Vector2[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadVector2Array(field, instance);
						};
					}
					else if(typeof(Vector4[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadVector4Array(field, instance);
						};
					}
					else if(typeof(Rect[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadRectArray(field, instance);
						};
					}
					else if(typeof(Color[]) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadColorArray(field, instance);
						};
					}
				}
				else
				{
					if(typeof(bool) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadBool(field, instance);
						};
					}
					else if(typeof(IBaseData).IsAssignableFrom(fieldType))
					{
						return delegate (DataObject data, object instance)
						{
							DataObject file = data.GetFile(field.Name);
							if(file != null)
							{
								string typeInfo = "";
								if(file.Get(DataSerializer.TYPE, ref typeInfo) &&
									!string.IsNullOrEmpty(typeInfo))
								{
									field.SetValue(instance, DataSerializer.CreateInstance(file, fieldType, typeInfo));
								}
								else
								{
									object value = field.GetValue(instance);
									if(value == null ||
										value.GetType() != fieldType)
									{
										value = ReflectionTypeHandler.Instance.CreateInstance(fieldType);
										((IBaseData)value).SetData(file);
										field.SetValue(instance, value);
									}
									else
									{
										((IBaseData)value).SetData(file);
										field.SetValue(instance, value);
									}
								}
							}
						};
					}
					else if(typeof(int) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadInt(field, instance);
						};
					}
					else if(typeof(System.Enum).IsAssignableFrom(fieldType))
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadInt(field, instance);
						};
					}
					else if(typeof(float) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadFloat(field, instance);
						};
					}
					else if(typeof(string) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadString(field, instance);
						};
					}
					else if(typeof(UnityEngine.Object).IsAssignableFrom(fieldType))
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadAsset(field, instance);
						};
					}
					else if(typeof(Vector2) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadVector2(field, instance);
						};
					}
					else if(typeof(Vector3) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadVector3(field, instance);
						};
					}
					else if(typeof(Color) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadColor(field, instance);
						};
					}
					else if(typeof(AnimationCurve).IsAssignableFrom(fieldType))
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadAnimationCurve(field, instance);
						};
					}
					else if(typeof(Vector4) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadVector4(field, instance);
						};
					}
					else if(typeof(Rect) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							data.LoadRect(field, instance);
						};
					}
					else if(typeof(LayerMask) == fieldType)
					{
						return delegate (DataObject data, object instance)
						{
							int tmp = 1;
							if(data.Get(field.Name, ref tmp))
							{
								LayerMask tmp2 = new LayerMask();
								tmp2.value = tmp;
								field.SetValue(instance, tmp2);
							}
						};
					}
				}
			}
			catch(System.Exception ex)
			{
				// silent
			}
			return null;
		}


		/*
		============================================================================
		Instance functions
		============================================================================
		*/
		public static object CreateInstance(DataObject data, System.Type type)
		{
			object value = null;
			string typeInfo = "";

			if(!data.Get(DataSerializer.TYPE, ref typeInfo) ||
				string.IsNullOrEmpty(typeInfo))
			{
				value = ReflectionTypeHandler.Instance.CreateInstance(type);
			}
			else if(type.IsGenericType)
			{
				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(typeInfo);
				if(tmpType != null)
				{
					value = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(type.GetGenericArguments()));
				}
			}
			else
			{
				value = ReflectionTypeHandler.Instance.CreateInstance(
					ReflectionTypeHandler.Instance.SerializerGetType(typeInfo));

				if(value == null)
				{
					if(typeof(GamingIsLove.Makinom.Schematics.Nodes.BaseSchematicNode).IsAssignableFrom(type))
					{
						value = ReflectionTypeHandler.Instance.CreateInstance(
							ReflectionTypeHandler.Instance.SerializerGetType("GamingIsLove.Makinom.Schematics.Nodes." + typeInfo));
						if(value == null)
						{
							value = new GamingIsLove.Makinom.Schematics.Nodes.EmptyNode();
						}
					}
					else if(typeof(GamingIsLove.Makinom.Formulas.Nodes.BaseFormulaNode).IsAssignableFrom(type))
					{
						value = ReflectionTypeHandler.Instance.CreateInstance(
							ReflectionTypeHandler.Instance.SerializerGetType("GamingIsLove.Makinom.Formulas.Nodes." + typeInfo));
						if(value == null)
						{
							value = new GamingIsLove.Makinom.Formulas.Nodes.EmptyNode();
						}
					}
				}
			}

			if(value != null)
			{
				((IBaseData)value).SetData(data);
			}
			return value;
		}

		public static object CreateInstance(DataObject data, System.Type type, string typeInfo)
		{
			object value = null;

			if(type.IsGenericType)
			{
				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(typeInfo);
				if(tmpType != null)
				{
					value = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(type.GetGenericArguments()));
				}
			}
			else
			{
				value = ReflectionTypeHandler.Instance.CreateInstance(
					ReflectionTypeHandler.Instance.SerializerGetType(typeInfo));

				if(value == null)
				{
					if(typeof(GamingIsLove.Makinom.Schematics.Nodes.BaseSchematicNode).IsAssignableFrom(type))
					{
						value = ReflectionTypeHandler.Instance.CreateInstance(
							ReflectionTypeHandler.Instance.SerializerGetType("GamingIsLove.Makinom.Schematics.Nodes." + typeInfo));
						if(value == null)
						{
							value = new GamingIsLove.Makinom.Schematics.Nodes.EmptyNode();
						}
					}
					else if(typeof(GamingIsLove.Makinom.Formulas.Nodes.BaseFormulaNode).IsAssignableFrom(type))
					{
						value = ReflectionTypeHandler.Instance.CreateInstance(
							ReflectionTypeHandler.Instance.SerializerGetType("GamingIsLove.Makinom.Formulas.Nodes." + typeInfo));
						if(value == null)
						{
							value = new GamingIsLove.Makinom.Formulas.Nodes.EmptyNode();
						}
					}
				}
			}

			if(value != null)
			{
				((IBaseData)value).SetData(data);
			}
			return value;
		}

		public static object CreateArrayInstance(DataObject[] file, System.Type arrayType, System.Type elementType)
		{
			System.Array tmp = System.Array.CreateInstance(elementType, file.Length);
			for(int j = 0; j < file.Length; j++)
			{
				if(file[j] != null)
				{
					tmp.SetValue(DataSerializer.CreateInstance(file[j], elementType), j);
				}
			}
			return System.Convert.ChangeType(tmp, arrayType);
		}


		/*
		============================================================================
		Variable functions
		============================================================================
		*/
		public static void GetVariables<T>(T instance, ref List<string> variables) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is string)
					{
						string tmpValue = (string)value;
						EditorInfoAttribute info = null;
						object[] tmp = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
						if(tmp.Length > 0)
						{
							info = tmp[0] as EditorInfoAttribute;
						}
						if(info != null && info.isVariableField &&
							tmpValue != "" &&
							!variables.Contains(tmpValue))
						{
							variables.Add(tmpValue);
						}
					}
					else if(value is string[])
					{
						EditorInfoAttribute info = null;
						object[] tmp = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
						if(tmp.Length > 0)
						{
							info = tmp[0] as EditorInfoAttribute;
						}
						if(info != null && info.isVariableField)
						{
							string[] tmpArray = (string[])(System.Array)value;
							for(int j = 0; j < tmpArray.Length; j++)
							{
								if(tmpArray[j] != "" &&
									!variables.Contains(tmpArray[j]))
								{
									variables.Add(tmpArray[j]);
								}
							}
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						DataSerializer.GetVariables((IBaseData)value, ref variables);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								DataSerializer.GetVariables(tmp[j], ref variables);
							}
						}
					}
				}
			}
		}

		public static void GetVariables<T>(T instance, ref List<string> variables, string searchValue) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is string)
					{
						string tmpValue = (string)value;
						EditorInfoAttribute info = null;
						object[] tmp = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
						if(tmp.Length > 0)
						{
							info = tmp[0] as EditorInfoAttribute;
						}
						if(info != null && info.isVariableField &&
							tmpValue != "" &&
							tmpValue.IndexOf(searchValue, System.StringComparison.OrdinalIgnoreCase) >= 0 &&
							!variables.Contains(tmpValue))
						{
							variables.Add(tmpValue);
						}
					}
					else if(value is string[])
					{
						EditorInfoAttribute info = null;
						object[] tmp = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
						if(tmp.Length > 0)
						{
							info = tmp[0] as EditorInfoAttribute;
						}
						if(info != null && info.isVariableField)
						{
							string[] tmpArray = (string[])(System.Array)value;
							for(int j = 0; j < tmpArray.Length; j++)
							{
								if(tmpArray[j] != "" &&
									tmpArray[j].IndexOf(searchValue, System.StringComparison.OrdinalIgnoreCase) >= 0 &&
									!variables.Contains(tmpArray[j]))
								{
									variables.Add(tmpArray[j]);
								}
							}
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						DataSerializer.GetVariables((IBaseData)value, ref variables, searchValue);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								DataSerializer.GetVariables(tmp[j], ref variables, searchValue);
							}
						}
					}
				}
			}
		}

		public static bool ReplaceVariable<T>(T instance, string oldKey, string newKey) where T : IBaseData
		{
			bool changed = false;
			DataSerializer.ReplaceVariable(instance, oldKey, newKey, ref changed);
			return changed;
		}

		public static void ReplaceVariable<T>(T instance, string oldKey, string newKey, ref bool changed) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is string)
					{
						string tmpValue = (string)value;
						EditorInfoAttribute info = null;
						object[] tmp = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
						if(tmp.Length > 0)
						{
							info = tmp[0] as EditorInfoAttribute;
						}
						if(info != null && info.isVariableField &&
							tmpValue == oldKey)
						{
							changed = true;
							field[i].SetValue(instance, newKey);
						}
					}
					else if(value is string[])
					{
						EditorInfoAttribute info = null;
						object[] tmp = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
						if(tmp.Length > 0)
						{
							info = tmp[0] as EditorInfoAttribute;
						}
						if(info != null && info.isVariableField)
						{
							bool isSet = false;
							string[] tmpArray = (string[])(System.Array)value;
							for(int j = 0; j < tmpArray.Length; j++)
							{
								if(tmpArray[j] == oldKey)
								{
									isSet = true;
									tmpArray[j] = newKey;
								}
							}
							if(isSet)
							{
								changed = true;
								field[i].SetValue(instance, tmpArray);
							}
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						DataSerializer.ReplaceVariable((IBaseData)value, oldKey, newKey, ref changed);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								DataSerializer.ReplaceVariable(tmp[j], oldKey, newKey, ref changed);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Language export functions
		============================================================================
		*/
		public static void GetLanguageExport<T>(T instance, bool resetExportIDs, GetInt getExportID, string info, ref List<LanguageData.Export> export) where T : IBaseData
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();
				object[] attribute = System.Attribute.GetCustomAttributes(instanceType, typeof(EditorLanguageExportAttribute));
				if(attribute.Length > 0)
				{
					info = (string.IsNullOrEmpty(info) ? "" : info + ".") + ((EditorLanguageExportAttribute)attribute[0]).info;
				}

				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instanceType);

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is LanguageData)
						{
							LanguageData lang = (LanguageData)value;

							LanguageData.Export data = lang.GetExport();
							if(data != null)
							{
								attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
								if(attribute.Length > 0)
								{
									data.info = (string.IsNullOrEmpty(info) ? "" : info + ".") + ((EditorLanguageExportAttribute)attribute[0]).info;
								}
								else
								{
									data.info = info;
								}

								if(resetExportIDs || lang.exportID == -1)
								{
									lang.exportID = getExportID();
								}
								data.exportID = lang.exportID;

								export.Add(data);
							}
						}
						// other IBaseData classes
						else if(value is IBaseData)
						{
							attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
							if(attribute.Length == 0)
							{
								attribute = field[i].FieldType.GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
							}
							if(attribute.Length > 0)
							{
								DataSerializer.GetLanguageExport((IBaseData)value, resetExportIDs, getExportID,
									(string.IsNullOrEmpty(info) ? "" : info + ".") + ((EditorLanguageExportAttribute)attribute[0]).info,
									ref export);
							}
							else
							{
								DataSerializer.GetLanguageExport((IBaseData)value, resetExportIDs, getExportID, info, ref export);
							}
						}
						else if(value is IBaseData[])
						{
							attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
							if(attribute.Length == 0)
							{
								attribute = field[i].FieldType.GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
							}
							if(attribute.Length > 0)
							{
								IBaseData[] tmp = (IBaseData[])(System.Array)value;
								for(int j = 0; j < tmp.Length; j++)
								{
									if(tmp[j] != null)
									{
										DataSerializer.GetLanguageExport(tmp[j], resetExportIDs, getExportID,
											(string.IsNullOrEmpty(info) ? "" : info + ".") + ((EditorLanguageExportAttribute)attribute[0]).info,
											ref export);
									}
								}
							}
							else
							{
								IBaseData[] tmp = (IBaseData[])(System.Array)value;
								for(int j = 0; j < tmp.Length; j++)
								{
									if(tmp[j] != null)
									{
										DataSerializer.GetLanguageExport(tmp[j], resetExportIDs, getExportID, info, ref export);
									}
								}
							}
						}
					}
				}
			}
		}

		public static void GetLanguageExportTexts<T>(T instance, string info, ref List<string> textInfos, ref List<string> texts) where T : IBaseData
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();
				object[] attribute = System.Attribute.GetCustomAttributes(instanceType, typeof(EditorLanguageExportAttribute));
				if(attribute.Length > 0)
				{
					info = (string.IsNullOrEmpty(info) ? "" : info + ".") + ((EditorLanguageExportAttribute)attribute[0]).info;
				}

				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instanceType);

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is string)
					{
						attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						if(attribute.Length == 0)
						{
							attribute = field[i].FieldType.GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						}
						if(attribute.Length > 0)
						{
							string tmpValue = (string)value;
							if(texts == null)
							{
								textInfos = new List<string>();
								texts = new List<string>();
							}
							textInfos.Add(info);
							texts.Add(tmpValue);
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						if(attribute.Length == 0)
						{
							attribute = field[i].FieldType.GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						}
						if(attribute.Length > 0)
						{
							DataSerializer.GetLanguageExportTexts((IBaseData)value,
								info + "." + ((EditorLanguageExportAttribute)attribute[0]).info,
								ref textInfos, ref texts);
						}
						else
						{
							DataSerializer.GetLanguageExportTexts((IBaseData)value, info, ref textInfos, ref texts);
						}
					}
					else if(value is IBaseData[])
					{
						attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						if(attribute.Length == 0)
						{
							attribute = field[i].FieldType.GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						}
						if(attribute.Length > 0)
						{
							string tmpInfo = info + "." + ((EditorLanguageExportAttribute)attribute[0]).info;

							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								if(tmp[j] != null)
								{
									DataSerializer.GetLanguageExportTexts(tmp[j], tmpInfo, ref textInfos, ref texts);
								}
							}
						}
						else
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								if(tmp[j] != null)
								{
									DataSerializer.GetLanguageExportTexts(tmp[j], info, ref textInfos, ref texts);
								}
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Language import functions
		============================================================================
		*/
		public static void SetLanguageImport<T>(T instance, ref bool hasImported, bool[] importLanguage, LanguageAsset[] languageAsset, Dictionary<int, LanguageData.Import> import) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is LanguageData)
						{
							LanguageData lang = (LanguageData)value;

							LanguageData.Import data;
							if(import.TryGetValue(lang.exportID, out data))
							{
								if(lang.SetImport(importLanguage, languageAsset, data))
								{
									hasImported = true;
								}
							}
						}
						// other IBaseData classes
						else if(value is IBaseData)
						{
							DataSerializer.SetLanguageImport((IBaseData)value, ref hasImported, importLanguage, languageAsset, import);
						}
						else if(value is IBaseData[])
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								if(tmp[j] != null)
								{
									DataSerializer.SetLanguageImport(tmp[j], ref hasImported, importLanguage, languageAsset, import);
								}
							}
						}
					}
				}
			}
		}

		public static void SetLanguageImportTexts<T>(T instance, ref bool any, ref int index, int languageIndex, Dictionary<int, string[]> texts) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is string)
					{
						object[] attribute = field[i].GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						if(attribute.Length == 0)
						{
							attribute = field[i].FieldType.GetCustomAttributes(typeof(EditorLanguageExportAttribute), true);
						}
						if(attribute.Length > 0)
						{
							string[] langText;
							if(texts.TryGetValue(index++, out langText) &&
								languageIndex < langText.Length)
							{
								if(!string.IsNullOrEmpty(langText[languageIndex]))
								{
									any = true;
									field[i].SetValue(instance, langText[languageIndex]);
								}
								else
								{
									field[i].SetValue(instance, "");
								}
							}
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						DataSerializer.SetLanguageImportTexts((IBaseData)value, ref any, ref index, languageIndex, texts);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								DataSerializer.SetLanguageImportTexts(tmp[j], ref any, ref index, languageIndex, texts);
							}
						}
					}
				}
			}
		}
	}
}
