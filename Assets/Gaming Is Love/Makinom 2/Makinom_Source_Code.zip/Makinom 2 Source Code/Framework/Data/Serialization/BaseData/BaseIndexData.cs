
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseIndexData : BaseData
	{
		protected int realID = 0;

		protected string guid = System.Guid.NewGuid().ToString();

		public BaseIndexData()
		{

		}

		public BaseIndexData(string guid)
		{
			if(guid != null &&
				guid != "")
			{
				this.GUID = guid;
			}
		}

		public virtual string GUID
		{
			get { return this.guid; }
			set { this.guid = TextHelper.RemoveAllWhitespaces(value); }
		}

		public virtual void GenerateGUID()
		{
			this.guid = System.Guid.NewGuid().ToString();
		}

		public virtual int ID
		{
			get { return this.realID; }
			set { this.realID = value; }
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			data.Get("realID", ref this.realID);
			data.Get("guid", ref this.guid);
		}

		public override DataObject GetData()
		{
			DataObject data = base.GetData();
			data.Set("realID", this.realID);
			data.Set("guid", this.guid);
			return data;
		}

		public virtual string GetEditorPopupName(bool addType)
		{
			return this.ID + ": " + this.EditorName;
		}

		public abstract string EditorName
		{
			get;
			set;
		}

		public virtual string DataName
		{
			get { return this.EditorName; }
		}
	}
}
