﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Transform", "The transform of a game object.")]
	public class TransformParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Game Object")]
		public T objectOrigin = new T();

		public TransformParameterType()
		{

		}

		public override string ToString()
		{
			return this.objectOrigin.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return true;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Transform);
		}

		public override object GetParameterValue(IDataCall call)
		{
			GameObject tmpObject = this.objectOrigin.GetObject(call);
			return tmpObject != null ? tmpObject.transform : null;
		}
	}
}
