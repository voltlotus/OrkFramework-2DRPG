﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Game Object", "A game object.")]
	public class GameObjectSchematicParameterType : BaseSchematicParameterType
	{
		[EditorTitleLabel("Game Object")]
		public SchematicObjectSelection gameObject = new SchematicObjectSelection();

		public GameObjectSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.gameObject.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return true;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(GameObject);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.gameObject.GetObject(schematic);
		}
	}
}
