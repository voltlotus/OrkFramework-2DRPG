﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Color", "A color value.")]
	public class ColorParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Color", "Select the color that will be used as parameter.", "")]
		public Color color = Color.white;

		public ColorParameterType()
		{

		}

		public override string ToString()
		{
			return "Color";
		}

		public override System.Type GetParameterType()
		{
			return typeof(Color);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.color;
		}
	}
}
