﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Material", "A material.")]
	public class MaterialParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Material", "Select the material that will be used as parameter.", "")]
		public AssetSource<Material> material = new AssetSource<Material>();

		public MaterialParameterType()
		{

		}

		public override string ToString()
		{
			return this.material.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(Material);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.material.StoredAsset;
		}
	}
}
