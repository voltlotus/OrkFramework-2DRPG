﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Enum", "An enumeration value.")]
	public class EnumSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Enum Name", "The name of the enumeration.\n" +
			"An int value will be used as the enum value.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Enum)]
		public string enumName = "";

		[EditorHelp("Int Value", "Define the int value that will be used as parameter (converted to enum).", "")]
		public FloatValue<SchematicObjectSelection> floatValue = new FloatValue<SchematicObjectSelection>();

		public EnumSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.enumName + " " + this.floatValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.floatValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return ReflectionTypeHandler.Instance.GetEnumType(this.enumName);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return (int)this.floatValue.GetValue(schematic);
		}
	}
}
