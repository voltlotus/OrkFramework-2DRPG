﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Vector2", "A Vector2 value (uses a Vector3, but only the X and Y axes).")]
	public class Vector2ParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Vector2 Value")]
		public Vector3Value<T> vector3Value = new Vector3Value<T>();

		public Vector2ParameterType()
		{

		}

		public override string ToString()
		{
			return this.vector3Value.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.vector3Value.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Vector2);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return (Vector2)this.vector3Value.GetValue(call);
		}
	}
}
