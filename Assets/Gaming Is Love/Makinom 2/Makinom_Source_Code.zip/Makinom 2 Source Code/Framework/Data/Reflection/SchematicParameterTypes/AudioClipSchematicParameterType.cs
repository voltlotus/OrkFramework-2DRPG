﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Audio Clip", "An audio clip.")]
	public class AudioClipSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Audio Clip", "Select the audio clip that will be used as parameter.", "")]
		public SchematicAudioClipSelection audioClip = new SchematicAudioClipSelection();

		public AudioClipSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.audioClip.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(AudioClip);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.audioClip.GetAudioClip(schematic);
		}
	}
}
