﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Material", "A material.")]
	public class MaterialSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Material", "Select the material that will be used as parameter.", "")]
		public SchematicMaterialSelection material = new SchematicMaterialSelection();

		public MaterialSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.material.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(Material);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.material.GetMaterial(schematic);
		}
	}
}
