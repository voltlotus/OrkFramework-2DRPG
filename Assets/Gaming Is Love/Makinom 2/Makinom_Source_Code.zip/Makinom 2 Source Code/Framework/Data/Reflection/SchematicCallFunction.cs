
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Text;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicCallFunction : BaseData
	{
		[EditorHelp("Class Name", "The name of the class that contains the function.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";

		[EditorHelp("Function Name", "The name of the function that will be called.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Function, typeof(Component), "className")]
		public string functionName = "";

		// parameters
		[EditorArray("Add Parameter", "Adds a parameter that will be used when calling the function.", "",
			"Remove", "Removes this parameter.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] { "Parameter", "The parameter will be used when calling the function.", "" })]
		public SchematicParameterSetting[] parameters = new SchematicParameterSetting[0];

		public SchematicCallFunction()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.ContainsArray<DataObject>("parameter"))
			{
				DataObject[] tmp = data.GetFileArray("parameter");
				if(tmp.Length > 0)
				{
					this.parameters = new SchematicParameterSetting[tmp.Length];
					for(int i = 0; i < this.parameters.Length; i++)
					{
						this.parameters[i] = SchematicParameterSetting.UpgradeData(tmp[i]);
					}
				}
			}
		}

		public bool Call(object instance, Schematic schematic, bool isStatic)
		{
			if(this.className != "" && this.functionName != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.parameters.Length > 0)
						{
							System.Type[] types = new System.Type[this.parameters.Length];
							object[] values = new object[this.parameters.Length];

							for(int i = 0; i < this.parameters.Length; i++)
							{
								types[i] = this.parameters[i].settings.GetParameterType();
								values[i] = this.parameters[i].settings.GetParameterValue(schematic);
							}

							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, types, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									methodInfo.Invoke(isStatic ? null : instance, values);
									return true;
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
						else
						{
							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, new System.Type[] {}, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									methodInfo.Invoke(isStatic ? null : instance, null);
									return true;
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return false;
		}

		public object GetReturnValue(object instance, Schematic schematic, bool isStatic)
		{
			if(this.className != "" && this.functionName != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.parameters.Length > 0)
						{
							System.Type[] types = new System.Type[this.parameters.Length];
							object[] values = new object[this.parameters.Length];

							for(int i = 0; i < this.parameters.Length; i++)
							{
								types[i] = this.parameters[i].settings.GetParameterType();
								values[i] = this.parameters[i].settings.GetParameterValue(schematic);
							}

							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, types, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									return methodInfo.Invoke(isStatic ? null : instance, values);
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
						else
						{
							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, new System.Type[] {}, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									return methodInfo.Invoke(isStatic ? null : instance, null);
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return null;
		}

		public override string ToString()
		{
			StringBuilder builder = new StringBuilder(this.className).
				Append(".").Append(this.functionName);
			if(this.parameters.Length > 0)
			{
				builder.Append("(");
				for(int i = 0; i < this.parameters.Length; i++)
				{
					if(i > 0)
					{
						builder.Append(", ");
					}
					builder.Append(this.parameters[i].ToString());
				}
				builder.Append(")");
			}
			return builder.ToString();
		}
	}
}
