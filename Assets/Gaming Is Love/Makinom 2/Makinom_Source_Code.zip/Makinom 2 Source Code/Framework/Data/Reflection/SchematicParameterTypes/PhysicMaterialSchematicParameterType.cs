﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Physic Material", "A physic material.")]
	public class PhysicMaterialSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Physic Material", "Select the physic material that will be used as parameter.", "")]
		public SchematicPhysicMaterialSelection physicMaterial = new SchematicPhysicMaterialSelection();

		public PhysicMaterialSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.physicMaterial.ToString();
		}

		public override System.Type GetParameterType()
		{
#if Unity_2019
			return typeof(PhysicMaterial);
#else
			return typeof(PhysicsMaterial);
#endif
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.physicMaterial.GetPhysicMaterial(schematic);
		}
	}
}
