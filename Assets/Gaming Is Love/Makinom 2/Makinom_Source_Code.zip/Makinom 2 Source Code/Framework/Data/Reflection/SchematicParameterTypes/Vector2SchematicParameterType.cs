﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Vector2", "A Vector2 value (uses a Vector3, but only the X and Y axes).")]
	public class Vector2SchematicParameterType : BaseSchematicParameterType
	{
		[EditorTitleLabel("Vector2 Value")]
		public Vector3Value<SchematicObjectSelection> vector3Value = new Vector3Value<SchematicObjectSelection>();

		public Vector2SchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.vector3Value.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.vector3Value.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Vector2);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return (Vector2)this.vector3Value.GetValue(schematic);
		}
	}
}
