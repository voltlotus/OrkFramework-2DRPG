﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Int", "An integer value.")]
	public class IntParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Int Value", "Define the int value that will be used as parameter.", "")]
		public FloatValue<T> floatValue = new FloatValue<T>();

		public IntParameterType()
		{

		}

		public override string ToString()
		{
			return this.floatValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.floatValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(int);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return (int)this.floatValue.GetValue(call);
		}
	}
}
