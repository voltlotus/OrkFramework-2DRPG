﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Game Object", "A game object.")]
	public class GameObjectParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Game Object")]
		public T objectOrigin = new T();

		public GameObjectParameterType()
		{

		}

		public override string ToString()
		{
			return this.objectOrigin.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return true;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(GameObject);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.objectOrigin.GetObject(call);
		}
	}
}
