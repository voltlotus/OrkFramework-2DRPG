﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MakinomSettingsAsset : ScriptableObject
	{
		[HideInInspector]
		[SerializeField]
		protected DataFile data;

		protected virtual void OnEnable()
		{
			if(this.data != null)
			{
				this.data.ClearDataObject();
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public DataFile Data
		{
			get { return this.data; }
			set { this.data = value; }
		}
	}
}
