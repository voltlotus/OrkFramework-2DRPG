
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum MusicPlaySimpleType { Play, FadeIn, FadeTo, FadeOutPlay }

	public class PlayMusicStored : BaseData
	{
		[EditorHelp("Music Channel", "Define the music channel that will be used.\n" +
			"The default channel is 0.", "")]
		[EditorLimit(0, false)]
		public int channel = 0;

		[EditorHelp("Stored ID", "Define the ID used to store the clip.\n" +
			"You can store multiple clips by using different IDs.\n" +
			"The default ID is 0.", "")]
		[EditorLimit(0, false)]
		public int storedID = 0;

		[EditorHelp("Play Type", "Select how the stored music should be played:\n" +
			"- Play: Plays the music clip and stops the currently playing clip.\n" +
			"- Fade In: Fades in the music clip and stops the currently playing clip.\n" +
			"- Fade To: Fades from the currently playing clip to the new one.\n" +
			"- Fade Out Play: Fades out the currently playing music clip and plays the new one after fading out is done.", "")]
		public MusicPlaySimpleType type = MusicPlaySimpleType.Play;

		[EditorHelp("Fade Time (s)", "The time in seconds used to fade the music clip.", "")]
		[EditorCondition("type", MusicPlaySimpleType.FadeIn)]
		[EditorCondition("type", MusicPlaySimpleType.FadeTo)]
		[EditorCondition("type", MusicPlaySimpleType.FadeOutPlay)]
		[EditorLimit(0.0f, false)]
		public float fade = 1;

		[EditorHelp("Interpolation", "The interpolation used for fading.", "")]
		[EditorEndCondition]
		[EditorAutoInit]
		public Interpolation interpolation;

		public PlayMusicStored()
		{

		}

		public void Play()
		{
			if(MusicPlaySimpleType.FadeIn == this.type)
			{
				Maki.Audio.GetMusicChannel(this.channel).FadeInStored(this.storedID, this.fade, this.interpolation);
			}
			else if(MusicPlaySimpleType.FadeTo == this.type)
			{
				Maki.Audio.GetMusicChannel(this.channel).FadeToStored(this.storedID, this.fade, this.interpolation);
			}
			else if(MusicPlaySimpleType.FadeOutPlay == this.type)
			{
				Maki.Audio.GetMusicChannel(this.channel).FadeOutPlayStored(this.storedID, this.fade, this.interpolation);
			}
			else
			{
				Maki.Audio.GetMusicChannel(this.channel).PlayStored(this.storedID);
			}
		}
	}
}
