
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SoundTypeAsset : MakinomGenericAsset<SoundType>
	{
		public SoundTypeAsset()
		{

		}

		public override string DataName
		{
			get { return "Sound Type"; }
		}
	}

	public class SoundType : BaseIndexData
	{
		[EditorHelp("Name", "The name of this sound type.", "")]
		[EditorFoldout("Base Settings", "Set the name of this sound type.", "")]
		[EditorEndFoldout]
		[EditorWidth(true)]
		public string name = "";

		public SoundType()
		{

		}

		public SoundType(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}
