﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MusicChannelSetting : BaseData
	{
		[EditorHelp("Music Channel", "Define the music channel that will be set up.\n" +
			"The default channel is 0.", "")]
		[EditorLimit(0, false)]
		public int channel = 0;

		[EditorHelp("Start Volume (0-1)", "Define the music volume (between 0 and 1) that will be used when Makinom is initialized.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float startMusicVolume = 1;

		[EditorHelp("Audio Mixer Group Asset", "Select the audio mixer group asset that will be used as output of the music channel.", "")]
		public AssetSource<AudioMixerGroup> mixerGroup = new AssetSource<AudioMixerGroup>();

		public MusicChannelSetting()
		{

		}

		public void Initialize()
		{
			MusicChannel tmpChannel = Maki.Audio.GetMusicChannel(this.channel);
			tmpChannel.Volume = this.startMusicVolume;
			tmpChannel.SetOutput(this.mixerGroup);
		}
	}
}
