﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MusicClip
	{
		private MusicClipSetting settings;

		private int currentLoop = 0;

		private float targetVolume = 1;


		// fading
		private Interpolation.FloatInstance interpolation;

		private bool fadeIn = false;

		private bool fadeOut = false;

		public MusicClip(string musicID, float targetVolume)
		{
			this.settings = Maki.MusicClips.Get(musicID);
			this.targetVolume = targetVolume;
		}

		public MusicClip(MusicClipSetting settings, float targetVolume)
		{
			this.settings = settings;
			this.targetVolume = targetVolume;
		}


		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public MusicClipSetting Settings
		{
			get { return this.settings; }
		}

		public bool FadeOut
		{
			get { return this.fadeOut; }
		}

		public float TargetVolume
		{
			get { return this.targetVolume; }
			set { this.targetVolume = value; }
		}

		public float Volume
		{
			get { return this.settings.maxVolume * this.targetVolume; }
		}

		public int CurrentLoop
		{
			get { return this.currentLoop; }
			set { this.currentLoop = value; }
		}

		public AudioClip GetClip()
		{
			return this.settings.clip;
		}


		/*
		============================================================================
		Loop functions
		============================================================================
		*/
		public bool HasLoops()
		{
			return this.settings.clipLoop.Length > 0;
		}

		public MusicClipLoop GetCurrentLoop()
		{
			if(this.settings.clipLoop.Length > 0 &&
				this.currentLoop >= 0 &&
				this.currentLoop < this.settings.clipLoop.Length)
			{
				return this.settings.clipLoop[this.currentLoop];
			}
			return null;
		}

		public void NextLoop()
		{
			if(this.currentLoop >= 0 &&
				this.currentLoop < this.settings.clipLoop.Length &&
				!this.settings.clipLoop[this.currentLoop].keepLooping)
			{
				this.currentLoop++;
				if(this.currentLoop >= this.settings.clipLoop.Length)
				{
					this.currentLoop = 0;
				}
			}
		}


		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public void DoFadeIn(float time, Interpolation interpolation)
		{
			this.fadeOut = false;
			this.interpolation = interpolation.CreateFloat(0, this.settings.maxVolume, time);
			this.fadeIn = true;
		}

		public void DoFadeOut(float time, Interpolation interpolation)
		{
			this.fadeIn = false;
			this.interpolation = interpolation.CreateFloat(this.settings.maxVolume, 0, time);
			this.fadeOut = true;
		}

		public void DoFade(float deltaTime, MusicAudioSource audio, float channelVolume)
		{
			if(this.fadeIn)
			{
				audio.volume = this.interpolation.Tick(deltaTime) *
					channelVolume * Maki.Audio.MusicVolume * this.targetVolume;

				if(this.interpolation.Finished)
				{
					this.fadeIn = false;
				}
			}
			else if(this.fadeOut)
			{
				audio.volume = this.interpolation.Tick(deltaTime) *
					channelVolume * Maki.Audio.MusicVolume * this.targetVolume;

				if(this.interpolation.Finished)
				{
					this.fadeOut = false;
					audio.Stop();
				}
			}
		}
	}
}
