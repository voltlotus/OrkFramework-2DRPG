
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MouseTouchControl : BaseData
	{
		[EditorHelp("Input Type", "Select the mouse/touch input:\n" +
			"- None: No input.\n" +
			"- Mouse: Mouse input only.\n" +
			"- Touch: Touch input only.\n" +
			"- Both: Mouse and touch input.", "")]
		public MouseTouchType type = MouseTouchType.None;

		[EditorHelp("Mouse Button", "Set which mouse button is used as input.\n" +
			"- 0: left mouse button\n" +
			"- 1: right mouse button\n" +
			"- 2: middle mouse button", "")]
		[EditorCondition("type", MouseTouchType.Mouse)]
		[EditorCondition("type", MouseTouchType.Both)]
		[EditorEndCondition]
		public int mouseClick = 0;

		[EditorHelp("Finger Count", "Set the number of fingers used for touch input.\n" +
			"E.g.: 1 is one finger, 2 is two fingers, etc.", "")]
		[EditorLimit(1, false)]
		[EditorCondition("type", MouseTouchType.Touch)]
		[EditorCondition("type", MouseTouchType.Both)]
		[EditorEndCondition]
		public int fingerCount = 1;

		[EditorHelp("Click Count", "The amount of clicks/taps used to trigger the input.\n" +
			"E.g.: 1 is a single click/tap, 2 is a double click/tap.", "")]
		[EditorLimit(1, false)]
		[EditorCondition("type", MouseTouchType.None)]
		[EditorElseCondition]
		public int clickCount = 1;

		[EditorHelp("Timeout (s)", "The time in seconds between two inputs.\n" +
			"Any click/touch during the timeout will not be recognized.", "")]
		[EditorLimit(0, false)]
		public float timeout = 0;

		[EditorHelp("All Modes", "The input will happen at start, move and end of the mouse/touch interaction.", "")]
		public bool allModes = false;

		[EditorHelp("Mode", "Select when the input will happen.\n" +
			"- Start: When the mouse is clicked or the touch first occurs.\n" +
			"- Move: When the mouse/finger(s) is moved.\n" +
			"- End: When the mouse/touch is released.\n" +
			"- Hold: When the mouse/finger(s) is hold down " +
			"(i.e. the whole time between 'Start' and 'End')", "")]
		[EditorCondition("allModes", false)]
		[EditorEndCondition(2)]
		public MouseTouchMode mode = MouseTouchMode.Start;

		[EditorHelp("Pressed Ignore Cursor Over", "Ignore the cursor being over a UI blocking mouse input while the control is already used.", "")]
		public bool pressedCursorOver = false;


		// ingame
		private int count = 0;

		private float lastClickTime = 0;

		private float interactionTimeout = Mathf.NegativeInfinity;

		private Vector3 lastPosition = Vector3.zero;

		private Vector3 lastChange = Vector3.zero;

		private bool isPressed = false;


		// new
		private List<int> fingerIDs = new List<int>();

		public MouseTouchControl()
		{

		}

		public MouseTouchControl(MouseTouchType type)
		{
			this.type = type;
		}

		public MouseTouchControl(MouseTouchType type, int mouseClick, int fingerCount, MouseTouchMode mode)
		{
			this.type = type;
			this.mouseClick = mouseClick;
			this.fingerCount = fingerCount;
			this.mode = mode;
		}

		public void Clear()
		{
			this.fingerIDs.Clear();
			this.isPressed = false;
		}


		/*
		============================================================================
		Control handling functions
		============================================================================
		*/
		public bool Active
		{
			get { return MouseTouchType.None != this.type; }
		}

		public bool UseMouse
		{
			get
			{
				return MouseTouchType.Mouse == this.type ||
					MouseTouchType.Both == this.type;
			}
		}

		public bool UseTouch
		{
			get
			{
				return MouseTouchType.Touch == this.type ||
					MouseTouchType.Both == this.type;
			}
		}


		/*
		============================================================================
		Control handling functions
		============================================================================
		*/
		public Vector3 GetLastChange()
		{
			return this.lastChange;
		}

		public bool Released()
		{
			return !Input.GetMouseButton(this.mouseClick);
		}

		public bool Interacted(ref Vector3 point)
		{
			if((Maki.UI.IsCursorOver || !Maki.Control.IsMouseTouchAllowed(this)) &&
				(!this.isPressed || !this.pressedCursorOver))
			{
				if(this.isPressed)
				{
					this.lastChange = Input.mousePosition - this.lastPosition;
					this.lastPosition = Input.mousePosition;
					this.Ended(ref point);
				}
				return false;
			}

			// click count
			if(this.UseMouse && Input.GetMouseButtonDown(this.mouseClick))
			{
				if((Time.realtimeSinceStartup - this.lastClickTime) > Maki.GameControls.clickTimeout)
				{
					this.count = 0;
				}
				this.count++;
				this.lastClickTime = Time.realtimeSinceStartup;
			}
			else if(this.UseTouch && this.fingerCount > 0 &&
				Maki.Control.Touch.CanStart(this.fingerCount))
			{
				if((Time.realtimeSinceStartup - this.lastClickTime) > Maki.GameControls.clickTimeout)
				{
					this.count = 0;
				}
				this.count++;
				this.lastClickTime = Time.realtimeSinceStartup;
			}

			if(this.allModes)
			{
				if(this.Started(ref point))
				{
					return true;
				}
				else if(this.isPressed)
				{
					if(this.Ended(ref point))
					{
						return true;
					}
					else if(MouseTouchMode.Hold == this.mode)
					{
						this.Moved(ref point);
						return this.isPressed;
					}
					else
					{
						return this.Moved(ref point);
					}
				}
			}
			else if(MouseTouchMode.Start == this.mode)
			{
				return this.Started(ref point);
			}
			else if(MouseTouchMode.Move == this.mode)
			{
				this.Started(ref point);
				this.Ended(ref point);
				return this.Moved(ref point);
			}
			else if(MouseTouchMode.End == this.mode)
			{
				return this.Ended(ref point);
			}
			else if(MouseTouchMode.Hold == this.mode)
			{
				this.Started(ref point);
				this.Ended(ref point);
				this.Moved(ref point);
				return this.isPressed;
			}
			return false;
		}

		private bool Started(ref Vector3 point)
		{
			bool started = false;

			if(this.UseMouse &&
				Input.GetMouseButtonDown(this.mouseClick))
			{
				point = Input.mousePosition;
				started = true;
			}
			else if(this.UseTouch && this.fingerCount > 0 &&
				Maki.Control.Touch.CanStart(this.fingerCount))
			{
				Maki.Control.Touch.GetStarted(true, ref this.fingerIDs);
				point = Vector2.zero;
				for(int i = 0; i < this.fingerIDs.Count; i++)
				{
					Vector2 tmp = Maki.Control.Touch.GetPosition(this.fingerIDs[i]);
					point.x += tmp.x;
					point.y += tmp.y;
				}
				point /= this.fingerCount;
				started = true;
			}

			if(started &&
				this.clickCount != this.count)
			{
				started = false;
			}

			if(started)
			{
				if(this.interactionTimeout > Time.realtimeSinceStartup)
				{
					started = false;
				}
				if(started)
				{
					this.lastPosition = point;
					if(this.allModes ||
						MouseTouchMode.Start != this.mode)
					{
						this.isPressed = true;
					}
					this.interactionTimeout = Time.realtimeSinceStartup + this.timeout;
				}
			}
			return started;
		}

		private bool Moved(ref Vector3 point)
		{
			bool moved = false;

			if(this.isPressed)
			{
				if(this.UseMouse && Input.GetMouseButton(this.mouseClick))
				{
					point = Input.mousePosition;
					this.lastChange = Input.mousePosition - this.lastPosition;
					this.lastPosition = Input.mousePosition;
					moved = true;
				}
				else if(this.UseTouch && this.fingerCount == this.fingerIDs.Count &&
					Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Hold))
				{
					point = Vector2.zero;
					for(int i = 0; i < this.fingerIDs.Count; i++)
					{
						Vector2 tmp = Maki.Control.Touch.GetPosition(this.fingerIDs[i]);
						point.x += tmp.x;
						point.y += tmp.y;
					}
					point /= this.fingerCount;
					this.lastChange = point - this.lastPosition;
					this.lastPosition = point;
					moved = true;
				}

				if(moved && this.lastChange == Vector3.zero)
				{
					moved = false;
				}
			}

			if(moved &&
				this.clickCount != this.count)
			{
				moved = false;
			}

			if(moved)
			{
				if(this.interactionTimeout > Time.realtimeSinceStartup)
				{
					moved = false;
				}
				if(moved)
				{
					this.interactionTimeout = Time.realtimeSinceStartup + this.timeout;
				}
			}

			return moved;
		}

		private bool Ended(ref Vector3 point)
		{
			bool ended = false;

			if(this.UseMouse && Input.GetMouseButtonUp(this.mouseClick))
			{
				point = Input.mousePosition;
				ended = true;
			}
			else if(this.UseTouch && this.fingerCount == this.fingerIDs.Count &&
				Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
			{
				point = Vector2.zero;
				for(int i = 0; i < this.fingerIDs.Count; i++)
				{
					Vector2 tmp = Maki.Control.Touch.GetPosition(this.fingerIDs[i]);
					point.x += tmp.x;
					point.y += tmp.y;
				}
				point /= this.fingerCount;
				ended = true;
			}

			if(ended &&
				this.clickCount != this.count)
			{
				ended = false;
			}

			if(ended)
			{
				if(this.interactionTimeout > Time.realtimeSinceStartup)
				{
					ended = false;
				}
				if(ended)
				{
					this.fingerIDs.Clear();
					this.isPressed = false;
					this.interactionTimeout = Time.realtimeSinceStartup + this.timeout;
				}
			}
			return ended;
		}
	}
}
