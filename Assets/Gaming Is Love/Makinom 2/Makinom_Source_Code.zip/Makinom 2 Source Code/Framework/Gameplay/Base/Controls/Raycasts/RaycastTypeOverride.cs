﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum RaycastType { Only3D, Only2D, First3D, First2D }
	public enum RaycastTypeOverrideType { Default, Only3D, Only2D, First3D, First2D }

	public class RaycastTypeOverride : BaseData
	{
		[EditorHelp("Raycast Type", "Select the type of raycast that is used:\n" +
			"- Default: The default horizontal plane defined in 'Game > Game Settings'.\n" +
			"- Only 3D: Only 3D raycasts are used.\n" +
			"- Only 2D: Only 2D raycasts are used.\n" +
			"- First 3D: Uses a 3D raycast first, if no object is found, a 2D raycast are used.\n" +
			"- First 2D: Uses a 2D raycast first, if no object is found, a 3D raycast is used.")]
		public RaycastTypeOverrideType type = RaycastTypeOverrideType.Default;

		public RaycastTypeOverride()
		{

		}

		public static implicit operator RaycastType(RaycastTypeOverride type)
		{
			if(type == null ||
				RaycastTypeOverrideType.Default == type.type)
			{
				return Maki.GameSettings.raycastType;
			}
			else if(RaycastTypeOverrideType.Only3D == type.type)
			{
				return RaycastType.Only3D;
			}
			else if(RaycastTypeOverrideType.Only2D == type.type)
			{
				return RaycastType.Only2D;
			}
			else if(RaycastTypeOverrideType.First3D == type.type)
			{
				return RaycastType.First3D;
			}
			else if(RaycastTypeOverrideType.First2D == type.type)
			{
				return RaycastType.First2D;
			}
			return Maki.GameSettings.raycastType;
		}
	}
}
