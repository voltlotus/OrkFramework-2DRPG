﻿
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ControlBehaviour : BaseData, IFoldoutInfo
	{
		[EditorHelp("Blocked By", "Select when this custom control will be blocked:\n" +
			"- None: This control won't be blocked.\n" +
			"- Player: When the player control is blocked.\n" +
			"- Camera: When the camera control is blocked.\n" +
			"- Both: When the player or camera control is blocked.", "")]
		public ControlBlockType blockType = ControlBlockType.None;

		[EditorHelp("Placed On", "Select on which object this custom control will be added/searched:\n" +
			"- Player: On the player's game object.\n" +
			"- Camera: On the main camera's game object.\n" +
			"- Game: On the persistant game object managing Makinom (alive in all scenes and at all times).", "")]
		public ControlPlaceType placeType = ControlPlaceType.Player;

		[EditorHelp("From Root", "Searching/adding the behaviour component will start from the root of the game object.\n" +
			"Use this option if the game object isn't the real root.", "")]
		[EditorSeparator]
		public bool fromRoot = false;

		[EditorHelp("On Child Object", "Search the behaviour component on child object's of the game object.", "")]
		public bool onChild = false;

		[EditorHelp("On Parent Object", "Search the behaviour component on parent object's of the game object.", "")]
		public bool onParent = false;

		[EditorHelp("Add Component", "The component will be added by Makinom if it isn't yet attached.\n" +
			"If disabled, the component must already attached when the scene loads or the game object is instantiated.\n" +
			"If the component is already attached to the game object, Makinom won't add it.", "")]
		public bool add = false;

		[EditorHelp("On Child", "The component will be added to a a child object of the game object.", "")]
		[EditorCondition("add", true)]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Add Only", "Only change the values if the component has been added by Makinom.\n" +
			"If disabled, the fields will be changed also when the component has already been attached.", "")]
		[EditorEndCondition]
		public bool changeOnlyAdd = false;

		[EditorSeparator]
		public ChangeFields<GameObjectSelection> component = new ChangeFields<GameObjectSelection>();

		public ControlBehaviour()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "childName");
		}

		public virtual string GetFoldoutInfo()
		{
			return this.component.className;
		}

		public void Add(GameObject gameObject)
		{
			if(gameObject != null)
			{
				if(this.fromRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}

				bool added = false;
				System.Type type = Maki.ReflectionHandler.GetType(this.component.className, typeof(Component));
				Behaviour comp = (this.onChild ?
					gameObject.GetComponentInChildren(type) :
					gameObject.GetComponent(type)) as Behaviour;
				if(comp == null &&
					this.onParent)
				{
					comp = gameObject.GetComponentInParent(type) as Behaviour;
				}

				if(this.add && comp == null)
				{
					comp = this.childObject.GetChild(gameObject).AddComponent(type) as Behaviour;
					added = true;
				}

				if(comp != null)
				{
					if(!this.changeOnlyAdd || added)
					{
						this.component.Change(comp, type, new DataCall(), false);
					}

					if(ControlBlockType.Player == this.blockType)
					{
						Maki.Control.AddPlayerControl(comp);
					}
					else if(ControlBlockType.Camera == this.blockType)
					{
						Maki.Control.AddCameraControl(comp);
					}
					else if(ControlBlockType.Both == this.blockType)
					{
						Maki.Control.AddPlayerControl(comp);
						Maki.Control.AddCameraControl(comp);
					}
				}
			}
		}

		public void Remove(GameObject gameObject)
		{
			if(gameObject != null)
			{
				System.Type type = Maki.ReflectionHandler.GetType(this.component.className, typeof(Component));
				Behaviour comp = (this.onChild ?
					gameObject.GetComponentInChildren(type) :
					gameObject.GetComponent(type)) as Behaviour;
				if(comp == null &&
					this.onParent)
				{
					comp = gameObject.GetComponentInParent(type) as Behaviour;
				}

				if(comp != null)
				{
					if(ControlBlockType.Player == this.blockType)
					{
						Maki.Control.RemovePlayerControl(comp);
					}
					else if(ControlBlockType.Camera == this.blockType)
					{
						Maki.Control.RemoveCameraControl(comp);
					}
					else if(ControlBlockType.Both == this.blockType)
					{
						Maki.Control.RemovePlayerControl(comp);
						Maki.Control.RemoveCameraControl(comp);
					}

					if(this.add)
					{
						GameObject.Destroy(comp);
					}
				}
			}
		}
	}
}

