﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace GamingIsLove.Makinom
{
	public delegate void MakinomProjectLoaded(MakinomProjectAsset projectAsset);

	[System.Serializable]
	public class MakinomProjectAssetBundleLoader : BaseData
	{
		[EditorHelp("Asset Name", "Define the name of the asset in the asset bundle.")]
		[EditorWidth(true)]
		public string assetName = "";

		[EditorHelp("Asset Bundle Name", "Define the name of the asset bundle.")]
		[EditorWidth(true)]
		public string assetBundleName = "";

		[EditorHelp("Path Origin", "Select where the path is located:\n" +
			"- None: Only uses the defined path.\n" +
			"- Data Path: Uses 'Application.dataPath'.\n" +
			"- Persistent Data Path: Uses 'Application.persistentDataPath'.\n" +
			"- Streaming Asset Path: Uses 'Application.streamingAssetsPath', " +
			"usually located at 'Assets/StreamingAssets/' in your Unity project.\n" +
			"- Temporary Cache Path: Uses 'Application.temporaryCachePath'.")]
		public ApplicationPathType pathOrigin = ApplicationPathType.DataPath;

		[EditorHelp("Path", "Define the path within the path origin.")]
		public string path = "";

		[EditorHelp("Load Type", "Select the way this asset bundle will be loaded:\n" +
			"- Load From File: Uses 'AssetBundle.LoadFromFile'.\n" +
			"- Load From Memory: Uses 'AssetBundle.LoadFromMemory' after loading the bundle's data via 'File.ReadAllBytes'.")]
		public AssetBundleLoadType loadType = AssetBundleLoadType.LoadFromFile;

		[EditorHelp("Load Async", "Load the asset using an async operation.")]
		public bool loadAsync = false;


		// in-game
		protected float progress = 0;

		protected AsyncOperation loadRequest;

		public MakinomProjectAssetBundleLoader()
		{

		}

		public MakinomProjectAsset GetProjectAsset()
		{
			return AssetSourceCache.Instance.GetFromAssetBundle<MakinomProjectAsset>(
				System.IO.Path.Combine(
					ApplicationPath.GetPath(this.pathOrigin, this.path),
					this.assetBundleName),
				this.assetName,
				this.loadType);
		}

		public float Progress
		{
			get { return this.progress + (this.loadRequest != null ? this.loadRequest.progress / 2 : 0); }
		}

		public IEnumerator GetProjectAssetAsync(MakinomProjectLoaded loaded)
		{
			MakinomProjectAsset asset = null;

			string bundlePath = System.IO.Path.Combine(
				ApplicationPath.GetPath(this.pathOrigin, this.path),
				this.assetBundleName);

			AssetBundleCreateRequest bundleRequest = null;
			if(AssetBundleLoadType.LoadFromFile == this.loadType)
			{
				bundleRequest = AssetBundle.LoadFromFileAsync(bundlePath);
			}
			else if(AssetBundleLoadType.LoadFromMemory == this.loadType)
			{
				byte[] data = System.IO.File.ReadAllBytes(bundlePath);
				if(data != null)
				{
					bundleRequest = AssetBundle.LoadFromMemoryAsync(data);
				}
			}
			if(bundleRequest == null)
			{
				yield return null;
			}
			else
			{
				this.loadRequest = bundleRequest;
				yield return bundleRequest;

				this.progress = bundleRequest.progress / 2;
				this.loadRequest = null;

				AssetBundle bundle = bundleRequest.assetBundle;
				if(bundle != null)
				{
					AssetSourceCache.Instance.AddBundleToCache(bundlePath, bundle);
					AssetBundleRequest assetRequest = bundle.LoadAssetAsync<MakinomProjectAsset>(this.assetName);
					if(assetRequest != null)
					{
						this.loadRequest = assetRequest;
						yield return assetRequest;

						this.progress = bundleRequest.progress;
						this.loadRequest = null;

						asset = assetRequest.asset as MakinomProjectAsset;
					}
				}
			}

			loaded(asset);
		}
	}
}
