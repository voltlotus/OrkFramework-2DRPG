﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Mouse", "A mouse button is used (uses mouse cursor position change as axis).\n" +
		"Please note that the axis is based on mouse cursor movement, i.e. it'll not work during locked cursor.")]
	public class MouseInputIDKeySetting : BaseInputIDKeySetting
	{
		// mouse
		[EditorHelp("Mouse Button", "Define which mouse button will be used, e.g.:\n" +
			"0 = left button\n" +
			"1 = right button\n" +
			"2 = middle button", "")]
		[EditorLimit(0, false)]
		public int mouseButton = 0;

		[EditorHelp("Click Count", "The amount of clicks used to trigger the input, e.g.:\n" +
			"1 = single click\n" +
			"2 = double click", "")]
		[EditorLimit(0, false)]
		public int clickCount = 1;

		[EditorHelp("Click Timeout (s)", "The time in seconds to recognize multi-clicks.\n" +
			"If another click happens within the timeout, it will be recognized " +
			"as a multi-click (e.g. double click).", "")]
		public float clickTimeout = 0.2f;

		[EditorHelp("Mouse Axis", "Select which axis of the mouse position change will be used for the input's axis.", "")]
		[EditorSeparator]
		public Axis2Type mouseAxis = Axis2Type.X;

		[EditorHelp("Axis Without Input", "The mouse axis input will be set without mouse button input, i.e. the axis is available at all times.")]
		public bool axisWithoutInput = false;

		[EditorHelp("Min Axis Range", "The minimum mouse position change (distance) that " +
			"will trigger the axis.", "")]
		[EditorLimit(0.001f, false)]
		public float mouseAxisMinRange = 1;

		[EditorHelp("Max Axis Range", "The maximum mouse position change (dinstance) that " +
			"will be used as full axis value (i.e. 1).", "")]
		[EditorLimit(1.0f, false)]
		public float mouseAxisMaxRange = 1;


		// input handling
		[EditorHelp("Input Handling", "Select when the input will be recognized:\n" +
			"- Down: When the key is pressed down.\n" +
			"- Hold: While the key is held down.\n" +
			"- Up: When the key is released.\n" +
			"- Any: When the key is pressed down, held down or released.", "")]
		[EditorSeparator]
		public InputHandling handling = InputHandling.Down;

		[EditorHelp("Timeout (s)", "The time in seconds between recognizing two inputs.\n" +
			"Set to 0 to recognize the input every frame.", "")]
		[EditorLimit(0.0f, false)]
		public float inputTimeout = 0;

		[EditorHelp("Hold Time (s)", "The time in seconds the input has to be held to recognize the input.\n" +
			"Set to 0 to recognize the input immediately.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("handling", InputHandling.Down)]
		[EditorElseCondition]
		[EditorDefaultValue(0.0f)]
		public float inputHoldTime = 0;

		[EditorHelp("Max Hold Time (s)", "The maximum time in seconds the input can be held to recognize the input.\n" +
			"Holding the input for longer will stop recognizing it as input.\n" +
			"Set to 0 to not use a maximum hold time.")]
		[EditorLimit(0.0f, false)]
		[EditorEndCondition]
		[EditorDefaultValue(0.0f)]
		public float inputMaxHoldTime = 0;


		// in-game
		private float releaseTime = 0;

		private int count = 0;

		public MouseInputIDKeySetting()
		{

		}

		public override void Clear()
		{
			this.releaseTime = 0;
			this.count = 0;
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override float InputTimeout
		{
			get { return this.inputTimeout; }
		}

		public override float InputHoldTime
		{
			get { return this.inputHoldTime; }
		}

		public override float InputMaxHoldTime
		{
			get { return this.inputMaxHoldTime; }
		}

		public override InputHandling Handling
		{
			get { return this.handling; }
		}

		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(this.inputHoldTime > 0 ||
				this.inputMaxHoldTime > 0)
			{
				if(Input.GetMouseButtonUp(this.mouseButton))
				{
					inputKey.ReleaseDownTime();
					this.count = 0;
				}
				else if(Input.GetMouseButton(this.mouseButton))
				{
					this.releaseTime = Time.time + this.clickTimeout;
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			// click count
			if(Input.GetMouseButtonDown(this.mouseButton))
			{
				if(this.releaseTime <= Time.time)
				{
					this.count = 0;
				}
				this.count++;
				this.releaseTime = Time.time + this.clickTimeout;
			}

			if(this.clickCount == this.count)
			{
				// set input down time
				if(this.inputHoldTime > 0 ||
					this.inputMaxHoldTime > 0)
				{
					if(Input.GetMouseButtonDown(this.mouseButton))
					{
						inputKey.SetDownTime();
						return;
					}
					else if(Input.GetMouseButtonUp(this.mouseButton))
					{
						inputKey.ReleaseDownTime();
						this.count = 0;
						if(InputHandling.Hold == this.handling)
						{
							return;
						}
					}
				}

				if((InputHandling.Down == this.handling && Input.GetMouseButtonDown(this.mouseButton)) ||
					(InputHandling.Hold == this.handling && Input.GetMouseButton(this.mouseButton)) ||
					(InputHandling.Up == this.handling && Input.GetMouseButtonUp(this.mouseButton)) ||
					(InputHandling.Any == this.handling &&
						(Input.GetMouseButtonDown(this.mouseButton) ||
						Input.GetMouseButton(this.mouseButton) ||
						Input.GetMouseButtonUp(this.mouseButton))))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + this.inputTimeout;
					inputKey.InputReceived = true;

					this.SetAxis(inputKey);

					if(InputHandling.Up == this.handling)
					{
						this.count = 0;
					}
				}
				else
				{
					if(this.axisWithoutInput)
					{
						this.SetAxis(inputKey);
					}
					if(Input.GetMouseButtonUp(this.mouseButton))
					{
						this.count = 0;
					}
				}
			}
		}

		protected virtual void SetAxis(InputIDKey inputKey)
		{
			float tmpAxis = VectorHelper.GetAxis2Value(Maki.Control.MouseDelta, this.mouseAxis);
			if(Mathf.Abs(tmpAxis) >= this.mouseAxisMinRange)
			{
				tmpAxis /= this.mouseAxisMaxRange;
				inputKey.UpdateAxis = tmpAxis;
			}
			else
			{
				inputKey.UpdateAxis = 0;
			}
		}
	}
}
