﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseInterpolation : BaseTypeData
	{
		public virtual float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			return 0;
		}


		/*
		============================================================================
		Float functions
		============================================================================
		*/
		public virtual Interpolation.FloatInstance CreateFloat()
		{
			return this.CreateFloatInternal(this);
		}

		protected virtual Interpolation.FloatInstance CreateFloatInternal<T>(T settings) where T : BaseInterpolation
		{
			return new Float<T>(settings);
		}

		public class Float<T> : Interpolation.FloatInstance where T : BaseInterpolation
		{
			protected T settings;

			protected float distance = 0;

			public Float(T settings)
			{
				this.settings = settings;
			}

			public override void Init(float start, float end, float duration)
			{
				base.Init(start, end, duration);
				this.UpdateDistance();
			}

			public override void UpdateDistance()
			{
				this.distance = this.target - this.start;
			}

			public override float Tick(float deltaTime)
			{
				this.elapsedTime += deltaTime;
				return this.settings.UpdateFloat(this.start, this.distance, this.elapsedTime, this.duration);
			}
		}


		/*
		============================================================================
		Vector2 functions
		============================================================================
		*/
		public virtual Interpolation.Vector2Instance CreateVector2()
		{
			return this.CreateVector2Internal(this);
		}

		protected virtual Interpolation.Vector2Instance CreateVector2Internal<T>(T settings) where T : BaseInterpolation
		{
			return new Vector2<T>(settings);
		}

		public class Vector2<T> : Interpolation.Vector2Instance where T : BaseInterpolation
		{
			protected T settings;

			protected Vector2 distance = Vector2.zero;

			public Vector2(T settings)
			{
				this.settings = settings;
			}

			public override void Init(Vector2 start, Vector2 end, float duration)
			{
				base.Init(start, end, duration);
				this.UpdateDistance();
			}

			public override void UpdateDistance()
			{
				this.distance = this.target - this.start;
			}

			public override Vector2 Tick(float deltaTime)
			{
				this.elapsedTime += deltaTime;
				return new Vector2(
					this.settings.UpdateFloat(this.start.x, this.distance.x, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.start.y, this.distance.y, this.elapsedTime, this.duration));
			}
		}


		/*
		============================================================================
		Vector3 functions
		============================================================================
		*/
		public virtual Interpolation.Vector3Instance CreateVector3()
		{
			return this.CreateVector3Internal(this);
		}

		protected virtual Interpolation.Vector3Instance CreateVector3Internal<T>(T settings) where T : BaseInterpolation
		{
			return new Vector3<T>(settings);
		}

		public class Vector3<T> : Interpolation.Vector3Instance where T : BaseInterpolation
		{
			protected T settings;

			protected Vector3 distance = Vector3.zero;

			public Vector3(T settings)
			{
				this.settings = settings;
			}

			public override void Init(Vector3 start, Vector3 end, float duration)
			{
				base.Init(start, end, duration);
				this.UpdateDistance();
			}

			public override void UpdateDistance()
			{
				this.distance = this.target - this.start;
			}

			public override Vector3 Tick(float deltaTime)
			{
				this.elapsedTime += deltaTime;
				return new Vector3(
					this.settings.UpdateFloat(this.start.x, this.distance.x, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.start.y, this.distance.y, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.start.z, this.distance.z, this.elapsedTime, this.duration));
			}
		}


		/*
		============================================================================
		Quaternion functions
		============================================================================
		*/
		public virtual Interpolation.QuaternionInstance CreateQuaternion()
		{
			return this.CreateQuaternionInternal(this);
		}

		protected virtual Interpolation.QuaternionInstance CreateQuaternionInternal<T>(T settings) where T : BaseInterpolation
		{
			return new Quaternion<T>(settings);
		}

		public class Quaternion<T> : Interpolation.QuaternionInstance where T : BaseInterpolation
		{
			protected T settings;

			protected Vector3 startEuler = Vector3.zero;

			protected Vector3 distance = Vector3.zero;

			public Quaternion(T settings)
			{
				this.settings = settings;
			}

			public override void Init(Quaternion start, Quaternion end, float duration)
			{
				base.Init(start, end, duration);
				this.startEuler = this.start.eulerAngles;
				this.UpdateDistance();
			}

			public override Quaternion Start
			{
				get { return this.start; }
				set
				{
					this.start = value;
					this.startEuler = this.start.eulerAngles;
					this.UpdateDistance();
				}
			}

			public override void UpdateDistance()
			{
				this.distance = this.target.eulerAngles - this.startEuler;
				if(this.distance.x < -190)
				{
					this.distance.x += 360;
				}
				else if(this.distance.x >= 190)
				{
					this.distance.x -= 360;
				}
				if(this.distance.y < -190)
				{
					this.distance.y += 360;
				}
				else if(this.distance.y >= 190)
				{
					this.distance.y -= 360;
				}
				if(this.distance.z < -190)
				{
					this.distance.z += 360;
				}
				else if(this.distance.z >= 190)
				{
					this.distance.z -= 360;
				}
			}

			public override Quaternion Tick(float deltaTime)
			{
				this.elapsedTime += deltaTime;
				return Quaternion.Euler(
					this.settings.UpdateFloat(this.startEuler.x, this.distance.x, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.startEuler.y, this.distance.y, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.startEuler.z, this.distance.z, this.elapsedTime, this.duration));
			}

			public override void Revert()
			{
				this.startEuler = this.target.eulerAngles;
				base.Revert();
			}
		}


		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public virtual Interpolation.ColorInstance CreateColor()
		{
			return this.CreateColorInternal(this);
		}

		protected virtual Interpolation.ColorInstance CreateColorInternal<T>(T settings) where T : BaseInterpolation
		{
			return new Color<T>(settings);
		}

		public class Color<T> : Interpolation.ColorInstance where T : BaseInterpolation
		{
			protected T settings;

			protected Color distance;

			public Color(T settings)
			{
				this.settings = settings;
			}

			public override void Init(Color start, Color end, float duration)
			{
				base.Init(start, end, duration);
				this.UpdateDistance();
			}

			public override void UpdateDistance()
			{
				this.distance = this.target - this.start;
			}

			public override Color Tick(float deltaTime)
			{
				this.elapsedTime += deltaTime;
				return new Color(
					this.settings.UpdateFloat(this.start.r, this.distance.r, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.start.g, this.distance.g, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.start.b, this.distance.b, this.elapsedTime, this.duration),
					this.settings.UpdateFloat(this.start.a, this.distance.a, this.elapsedTime, this.duration));
			}

			public override void Tick(ref Color value, float deltaTime, bool fadeRed, bool fadeGreen, bool fadeBlue, bool fadeAlpha)
			{
				this.elapsedTime += deltaTime;
				if(fadeRed)
				{
					value.r = this.settings.UpdateFloat(this.start.r, this.distance.r, this.elapsedTime, this.duration);
				}
				if(fadeGreen)
				{
					value.g = this.settings.UpdateFloat(this.start.g, this.distance.g, this.elapsedTime, this.duration);
				}
				if(fadeBlue)
				{
					value.b = this.settings.UpdateFloat(this.start.b, this.distance.b, this.elapsedTime, this.duration);
				}
				if(fadeAlpha)
				{
					value.a = this.settings.UpdateFloat(this.start.a, this.distance.a, this.elapsedTime, this.duration);
				}
			}
		}
	}
}
