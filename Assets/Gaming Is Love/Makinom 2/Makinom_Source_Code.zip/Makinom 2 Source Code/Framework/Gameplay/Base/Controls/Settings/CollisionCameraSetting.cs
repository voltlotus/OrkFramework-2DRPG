
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class CollisionCameraSetting : BaseData
	{
		[EditorHelp("Enable Collision Camera", "Enable using the collision camera.\n" +
			"The collision camera uses raycasts to determine if an object is between the player and the screen.\n" +
			"If an object is found, the camera will be placed at the collision point.\n" +
			"The 'CollisionCamera' component is added to the scene's camera automatically, " +
			"unless the component is already attached " +
			"(i.e. you can add the component to scene cameras to use different settings).\n" +
			"The collision camera can also be used with custom controls and with schematics/machines " +
			"(i.e. even when the camera controls are blocked)", "")]
		public bool enable = false;


		// camera settings
		[EditorCondition("enable", true)]
		[EditorEndCondition]
		public CollisionCamera.Settings settings = new CollisionCamera.Settings();

		public CollisionCameraSetting()
		{

		}

		public void Add(GameObject gameObject)
		{
			if(this.enable)
			{
				CollisionCamera comp = gameObject.GetComponent<CollisionCamera>();
				if(comp == null)
				{
					comp = gameObject.AddComponent<CollisionCamera>();

					comp.settings.SetData(this.settings.GetData());
				}
			}
		}

		public void Remove(GameObject gameObject)
		{
			if(this.enable)
			{
				CollisionCamera comp = gameObject.GetComponent<CollisionCamera>();
				if(comp != null)
				{
					GameObject.Destroy(comp);
				}
			}
		}
	}
}
