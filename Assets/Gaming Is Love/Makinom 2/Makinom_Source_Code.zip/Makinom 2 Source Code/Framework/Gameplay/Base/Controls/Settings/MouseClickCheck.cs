﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MouseClickCheck : BaseData
	{
		[EditorHelp("Click Count", "Define the number of clicks needed.", "")]
		[EditorLimit(1, false)]
		public int clickCount = 1;

		[EditorHelp("Click Timeout (s)", "The time in seconds to recognize multi-clicks.\n" +
			"If another click happens within the timeout, it will be recognized " +
			"as a multi-click (e.g. double click).", "")]
		public float clickTimeout = 0.2f;

		[EditorHelp("Left Click", "Use clicking with the left mouse button.", "")]
		[EditorSeparator]
		public bool leftClick = false;

		[EditorHelp("Middle Click", "Use clicking with the middle mouse button.", "")]
		public bool middleClick = false;

		[EditorHelp("Right Click", "Use clicking with the right mouse button.", "")]
		public bool rightClick = false;


		// in-game
		private float releaseTime = 0;

		private int count = 0;

		public MouseClickCheck()
		{

		}

		public MouseClickCheck(bool leftClick, bool middleClick, bool rightClick)
		{
			this.leftClick = leftClick;
			this.middleClick = middleClick;
			this.rightClick = rightClick;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.Clear();
		}

		public virtual void Clear()
		{
			this.releaseTime = 0;
			this.count = 0;
		}

		public virtual bool Check()
		{
			if((this.leftClick && Input.GetMouseButtonDown(0)) ||
				(this.rightClick && Input.GetMouseButtonDown(1)) ||
				(this.middleClick && Input.GetMouseButtonDown(2)))
			{
				if(this.releaseTime <= Time.time)
				{
					this.count = 0;
				}
				this.count++;
				this.releaseTime = Time.time + this.clickTimeout;

				if(this.clickCount == this.count)
				{
					this.count = 0;
					return true;
				}
			}
			return false;
		}
	}
}
