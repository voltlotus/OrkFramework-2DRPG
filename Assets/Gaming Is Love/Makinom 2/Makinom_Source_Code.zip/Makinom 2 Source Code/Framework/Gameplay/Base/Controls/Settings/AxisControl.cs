﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class AxisControl : BaseData
	{
		[EditorHelp("Use Axis", "Use an input key as an axis.\n" +
			"Enable this setting if you want to e.g. use a mouse wheel or a set up input key axis.\n" +
			"If disabled, you can define independent plus and minus input keys.")]
		public bool useAxis = false;

		// axis
		[EditorHelp("Axis Key", "Select the input key (used as axis) that will be used.")]
		[EditorCondition("useAxis", true)]
		public AssetSelection<InputKeyAsset> axisKey = new AssetSelection<InputKeyAsset>();


		// separate
		[EditorHelp("Plus Key", "Select the input key used as plus/positive key.")]
		[EditorElseCondition]
		public AssetSelection<InputKeyAsset> plusKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Minus Key", "Select the input key used as minus/negative key.")]
		public AssetSelection<InputKeyAsset> minusKey = new AssetSelection<InputKeyAsset>();


		// audio settings
		[EditorHelp("Audio Clip", "Select the audio clip that will be played when using the input keys.")]
		[EditorAutoInit]
		public AssetSource<AudioClip> audioClip;

		[EditorHelp("Sound Channel", "Define the sound channel that will be used.\n" +
			"The default channel is 0.")]
		[EditorLimit(0, false)]
		[EditorIndent]
		[EditorCondition("audioClip.HasAsset", true)]
		public int channel = 0;

		[EditorHelp("Volume", "The volume used to play the audio clip (between 0 and 1).")]
		[EditorIndent]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorEndCondition(2)]
		public float volume = 1;

		public AxisControl()
		{

		}

		public virtual bool HasInput()
		{
			return this.HasInput(Maki.Control.InputID);
		}

		public virtual bool HasInput(int inputID)
		{
			if(this.useAxis)
			{
				return InputKey.GetAxis(this.axisKey.StoredAsset, inputID) != 0;
			}
			else
			{
				return InputKey.GetButton(this.plusKey.StoredAsset, inputID) ||
					InputKey.GetButton(this.minusKey.StoredAsset, inputID);
			}
		}

		public virtual float GetAxis(bool negatePlusMinus)
		{
			return this.GetAxis(Maki.Control.InputID, negatePlusMinus);
		}

		public virtual float GetAxis(int inputID, bool negatePlusMinus)
		{
			if(this.useAxis)
			{
				return InputKey.GetAxis(this.axisKey.StoredAsset, inputID);
			}
			else
			{
				if(InputKey.GetButton(this.plusKey.StoredAsset, inputID))
				{
					this.PlayClip();
					return negatePlusMinus ?
						InputKey.GetAxis(this.plusKey.StoredAsset, inputID) * -1 :
						InputKey.GetAxis(this.plusKey.StoredAsset, inputID);
				}
				else if(InputKey.GetButton(this.minusKey.StoredAsset, inputID))
				{
					this.PlayClip();
					return negatePlusMinus ?
						InputKey.GetAxis(this.minusKey.StoredAsset, inputID) :
						InputKey.GetAxis(this.minusKey.StoredAsset, inputID) * -1;
				}
			}
			return 0;
		}

		public virtual void PlayClip()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.audioClip, this.volume);
		}
	}
}
