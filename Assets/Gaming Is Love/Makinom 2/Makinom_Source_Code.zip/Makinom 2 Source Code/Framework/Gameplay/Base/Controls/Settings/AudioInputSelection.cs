﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public class AudioInputSelection : BaseData
	{
		[EditorHelp("Input Key", "Select the input key that will be used.", "")]
		public AssetSelection<InputKeyAsset> inputKey = new AssetSelection<InputKeyAsset>();

		[EditorCondition("inputKey.HasAsset", true)]
		[EditorEndCondition]
		public UIAudioSelection audio = new UIAudioSelection();

		public AudioInputSelection()
		{

		}

		public AudioInputSelection(UIBoxAudioType audioType)
		{
			this.audio = new UIAudioSelection(audioType);
		}

		public virtual void ResetInput()
		{
			if(this.inputKey.StoredAsset != null)
			{
				this.inputKey.StoredAsset.Settings.Reset();
			}
		}


		/*
		============================================================================
		Button functions
		============================================================================
		*/
		public virtual bool GetButton()
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset))
			{
				this.PlayClip();
				return true;
			}
			return false;
		}

		public virtual bool GetButton(IUIBox uiBox)
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset))
			{
				this.PlayClip(uiBox);
				return true;
			}
			return false;
		}

		public virtual bool GetButton(UIBoxSetting uiBox)
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset))
			{
				this.PlayClip(uiBox);
				return true;
			}
			return false;
		}

		public virtual bool GetButton(int inputID)
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset, inputID))
			{
				this.PlayClip();
				return true;
			}
			return false;
		}

		public virtual bool GetButton(IUIBox uiBox, int inputID)
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset, inputID))
			{
				this.PlayClip(uiBox);
				return true;
			}
			return false;
		}

		public virtual bool GetButton(UIBoxSetting uiBox, int inputID)
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset, inputID))
			{
				this.PlayClip(uiBox);
				return true;
			}
			return false;
		}

		public virtual bool GetButtonSilent()
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset))
			{
				return true;
			}
			return false;
		}

		public virtual bool GetButtonSilent(int inputID)
		{
			if(InputKey.GetButton(this.inputKey.StoredAsset, inputID))
			{
				return true;
			}
			return false;
		}

		public virtual int GetAnyButtonInputID()
		{
			if(this.inputKey.StoredAsset != null)
			{
				return this.inputKey.StoredAsset.Settings.GetAnyButtonInputID();
			}
			return -1;
		}


		/*
		============================================================================
		Axis functions
		============================================================================
		*/
		public virtual float GetAxis()
		{
			float axis = InputKey.GetAxis(this.inputKey.StoredAsset);
			if(axis != 0.0f)
			{
				this.PlayClip();
			}
			return axis;
		}

		public virtual float GetAxis(IUIBox uiBox)
		{
			float axis = InputKey.GetAxis(this.inputKey.StoredAsset);
			if(axis != 0.0f)
			{
				this.PlayClip(uiBox);
			}
			return axis;
		}

		public virtual float GetAxis(UIBoxSetting uiBox)
		{
			float axis = InputKey.GetAxis(this.inputKey.StoredAsset);
			if(axis != 0.0f)
			{
				this.PlayClip(uiBox);
			}
			return axis;
		}

		public virtual float GetAxis(int inputID)
		{
			float axis = InputKey.GetAxis(this.inputKey.StoredAsset, inputID);
			if(axis != 0.0f)
			{
				this.PlayClip();
			}
			return axis;
		}

		public virtual float GetAxis(IUIBox uiBox, int inputID)
		{
			float axis = InputKey.GetAxis(this.inputKey.StoredAsset, inputID);
			if(axis != 0.0f)
			{
				this.PlayClip(uiBox);
			}
			return axis;
		}

		public virtual float GetAxis(UIBoxSetting uiBox, int inputID)
		{
			float axis = InputKey.GetAxis(this.inputKey.StoredAsset, inputID);
			if(axis != 0.0f)
			{
				this.PlayClip(uiBox);
			}
			return axis;
		}

		public virtual float GetAxisSilent()
		{
			return InputKey.GetAxis(this.inputKey.StoredAsset);
		}

		public virtual float GetAxisSilent(int inputID)
		{
			return InputKey.GetAxis(this.inputKey.StoredAsset, inputID);
		}

		public virtual int GetAnyAxisInputID()
		{
			if(this.inputKey.StoredAsset != null)
			{
				return this.inputKey.StoredAsset.Settings.GetAnyAxisInputID();
			}
			return -1;
		}


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public virtual void PlayClip()
		{
			if(this.audio != null)
			{
				this.audio.PlayClip();
			}
		}

		public virtual void PlayClip(IUIBox uiBox)
		{
			if(this.audio != null)
			{
				this.audio.PlayClip(uiBox);
			}
		}

		public virtual void PlayClip(UIBoxSetting uiBox)
		{
			if(this.audio != null)
			{
				this.audio.PlayClip(uiBox);
			}
		}
	}
}
