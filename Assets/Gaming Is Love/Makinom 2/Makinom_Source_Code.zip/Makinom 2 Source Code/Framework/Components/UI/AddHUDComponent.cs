﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/UI/HUD/Add HUD (to Game Object)")]
	public class AddHUDComponent : SerializedBehaviour<AddHUDComponent.Settings>
	{
		// in-game
		protected bool isAdded = false;

		protected virtual void OnEnable()
		{
			if(Maki.Initialized)
			{
				this.AddToHUD();
			}
		}

		protected virtual void Start()
		{
			this.AddToHUD();
		}

		protected virtual void OnDisable()
		{
			if(this.settings.removeOnDisable)
			{
				this.RemoveFromHUD();
			}
		}


		/*
		============================================================================
		HUD functions
		============================================================================
		*/
		public virtual void AddToHUD()
		{
			if(!this.isAdded)
			{
				this.isAdded = true;

				HUDInstance hud = Maki.UI.GetHUD(this.settings.hud.StoredAsset);
				if(hud != null)
				{
					hud.ChangeUsers(this.gameObject, ListChangeType.Add);
				}
			}
		}

		public virtual void RemoveFromHUD()
		{
			if(this.isAdded)
			{
				this.isAdded = false;

				HUDInstance hud = Maki.UI.GetHUD(this.settings.hud.StoredAsset);
				if(hud != null)
				{
					hud.ChangeUsers(this.gameObject, ListChangeType.Remove);
				}
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("HUD", "Select the HUD that will be used.", "")]
			[EditorLabel("Adds this game object as a user for the defined HUD.")]
			public AssetSelection<HUDAsset> hud = new AssetSelection<HUDAsset>();

			[EditorHelp("Remove On Disable", "Remove the user from the HUD when this game object is disabled/destroyed.")]
			public bool removeOnDisable = true;

			public Settings()
			{

			}
		}
	}
}
