﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[AddComponentMenu("")]
	public class MakinomLateFixedTick : MonoBehaviour
	{
		protected virtual void FixedUpdate()
		{
			Maki.Instance.FireLateFixedTick();
		}
	}
}
