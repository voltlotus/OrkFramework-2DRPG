
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public abstract class BaseConditionComponent : MonoBehaviour, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public ComponentConditionSetting conditionSetting = new ComponentConditionSetting();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_conditionSetting;


		// ingame
		protected bool isInvoking = false;


		/*
		============================================================================
		Auto check functions
		============================================================================
		*/
		protected virtual void Start()
		{
			if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
			{
				this.CheckAutoDestroy();
			}
		}

		protected virtual void OnEnable()
		{
			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				this.CheckAutoDestroy();
			}
		}


		/*
		============================================================================
		Condition functions
		============================================================================
		*/
		public virtual bool CheckConditions(GameObject startingObject, bool isAutoCheck)
		{
			if(this.conditionSetting.HasConditions)
			{
				return this.conditionSetting.Check(
					new DataCall(this.gameObject, startingObject),
					isAutoCheck);
			}
			return true;
		}

		protected virtual void EndCheck()
		{
			if(this.conditionSetting.repeatCheck)
			{
				this.CheckAutoDestroy();
			}
		}


		/*
		============================================================================
		Auto destroy functions
		============================================================================
		*/
		protected virtual bool CheckAutoDestroy()
		{
			if(ConditionAutoCheckType.None != this.conditionSetting.autoCheckType &&
				MachineConditionFailType.None != this.conditionSetting.conditionFail)
			{
				if(!this.CheckConditions(Maki.Game.Player.GameObject, true))
				{
					if(MachineConditionFailType.Disable == this.conditionSetting.conditionFail)
					{
						this.gameObject.SetActive(false);
					}
					else if(MachineConditionFailType.Destroy == this.conditionSetting.conditionFail)
					{
						TransformHelper.Destroy(this.gameObject);
					}
					return true;
				}
				else if(this.conditionSetting.repeatCheck && !this.isInvoking)
				{
					this.isInvoking = true;
					this.InvokeRepeating("AutoDestroy",
						this.conditionSetting.destroyCheckDelay,
						this.conditionSetting.destroyCheckDelay);
				}
			}
			return false;
		}

		protected virtual void AutoDestroy()
		{
			if(this.CheckAutoDestroy())
			{
				TransformHelper.Destroy(this.gameObject);
				this.CancelAutoDestroy();
			}
		}

		protected virtual void CancelAutoDestroy()
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_conditionSetting = this.conditionSetting.GetData().GetComponentDataFile("conditionSetting", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_conditionSetting != null)
			{
				this.conditionSetting.SetData(this.serialize_conditionSetting.ToDataObject());
				this.serialize_conditionSetting = null;
			}
		}
	}
}
