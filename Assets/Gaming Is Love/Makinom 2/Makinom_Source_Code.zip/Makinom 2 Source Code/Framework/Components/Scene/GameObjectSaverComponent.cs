﻿
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Game Object Saver")]
	public class GameObjectSaverComponent : SerializedBehaviour<GameObjectSaverComponent.Settings>, ISceneGUID, ISaveData
	{
		// in-game
		protected string sceneName = "";

		public static List<GameObjectSaverComponent> Registered = new List<GameObjectSaverComponent>();

		public virtual bool UseSceneGUID
		{
			get { return true; }
			set { }
		}

		public virtual string SceneGUID
		{
			get { return this.settings.sceneGUID; }
			set { this.settings.sceneGUID = value; }
		}

		protected virtual void Awake()
		{
			GameObjectSaverComponent.Registered.Add(this);
			this.sceneName = SceneManager.GetActiveScene().name;
		}

		protected virtual void Start()
		{
			if(Maki.Initialized &&
				Maki.Game.Running)
			{
				this.Load();
			}
		}

		protected virtual void OnDestroy()
		{
			if(Maki.Initialized &&
				Maki.Game.Running &&
				Maki.SaveGame != null &&
				!Maki.SaveGame.IsLoading)
			{
				this.Save();
			}
			GameObjectSaverComponent.Registered.Remove(this);
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual void Save()
		{
			Maki.Game.Scene.SetGameObjectSaverData(this.sceneName, this.SceneGUID, this.SaveGame());
		}

		public virtual void Load()
		{
			this.LoadGame(Maki.Game.Scene.GetGameObjectSaverData(this.sceneName, this.SceneGUID));
		}

		public virtual DataObject SaveGame()
		{
			return this.settings.saveSettings.SaveGame(this.gameObject);
		}

		public virtual void LoadGame(DataObject data)
		{
			this.settings.saveSettings.LoadGame(this.gameObject, data);
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHide]
			public string sceneGUID = "";

			public SaveGameObjectSettings saveSettings = new SaveGameObjectSettings();

			public Settings()
			{

			}
		}
	}
}
